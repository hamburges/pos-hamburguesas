# Sistema de Gestión para "JQ Q Berraquera"

## Descripción
Sistema integral para administrar "JQ Q Berraquera", una hamburguesería con múltiples sucursales que ofrece hamburguesas, perros calientes, choriperros, arepas con chorizo, choripan y bebidas. El sistema incluye gestión de inventario, ventas con productos personalizables (adición o eliminación de ingredientes), manejo de combos y control de caja con tres roles de usuario diferenciados: administrador, cajero y cocinero.

## Instalación
Instrucciones sobre cómo instalar y configurar el proyecto.

```bash
# Clonar el repositorio
git clone https://github.com/tu_usuario/tu_proyecto.git

# Navegar al directorio del proyecto
cd tu_proyecto

# Instalar dependencias
npm install
```

## Uso
Instrucciones sobre cómo usar el proyecto.

```bash
# Comando para iniciar el proyecto
npm start
```

## Contribución
Guía para contribuir al proyecto.

1. Haz un fork del proyecto.
2. Crea una nueva rama (`git checkout -b feature/nueva-funcionalidad`).
3. Realiza tus cambios y haz commit (`git commit -am 'Añadir nueva funcionalidad'`).
4. Sube tus cambios (`git push origin feature/nueva-funcionalidad`).
5. Abre un Pull Request.

## Licencia
Información sobre la licencia del proyecto.
