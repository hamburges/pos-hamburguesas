Funcionalidades del Sistema
Este documento detalla las funcionalidades implementadas en el Sistema de Gestión para "JQ Q Berraquera".
Módulo de Autenticación
El sistema cuenta con un sólido mecanismo de autenticación basado en JWT (JSON Web Tokens).
Componentes Implementados

Sistema de Login

Validación de credenciales contra la base de datos
Generación de tokens JWT con información del usuario
Almacenamiento seguro del token en localStorage
Verificación automática de la autenticación al iniciar la aplicación


Verificación de Tokens

Middleware en el backend para validar tokens
Interceptor en Axios para incluir el token en todas las peticiones
Renovación automática de sesión mientras el token sea válido
Cierre de sesión automático al expirar el token


Protección de Rutas

Componente PrivateRoute que restringe el acceso según rol
Redirección a login cuando no hay usuario autenticado
Redirección a página de no autorizado cuando el rol es incorrecto
Estado de carga mientras se verifica la autenticación


Persistencia de Sesión

Mantenimiento de la sesión entre recargas de página
Verificación periódica de la validez del token
Almacenamiento seguro de la información del usuario



Endpoints Relacionados
MétodoRutaDescripciónParámetrosRespuestaPOST/api/auth/loginInicio de sesión{ usuario, contrasena }{ success, message, data: { token, usuario } }GET/api/auth/verifyVerificación de tokenToken en header{ success, message, data: { usuario } }
Ejemplo de Uso
javascriptCopiar// Iniciar sesión
const login = async (credentials) => {
  try {
    const response = await api.post('/auth/login', credentials);
    
    if (response.data.success) {
      const { token, usuario } = response.data.data;
      localStorage.setItem('token', token);
      
      // Configurar token para futuras peticiones
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      
      // Guardar la información del usuario
      setUser(usuario);
      
      return { success: true };
    }
    
    return { success: false, message: 'Credenciales inválidas' };
  } catch (error) {
    return { 
      success: false, 
      message: error.response?.data?.message || 'Error en el servidor' 
    };
  }
};
Módulo de Sucursales
Este módulo permite la gestión completa de las sucursales del negocio.
Componentes Implementados

Listado de Sucursales

Visualización en formato de tabla con opciones de ordenamiento
Indicador visual del estado de cada sucursal (activa/inactiva)
Filtrado por nombre y estado
Paginación para manejo eficiente de grandes listas


Formulario de Creación

Validación completa de datos mediante Formik y Yup
Asignación opcional de administrador principal
Código de autorización para restringir la creación indebida
Feedback visual del resultado de la operación


Formulario de Edición

Carga automática de datos de la sucursal seleccionada
Validación de campos con Formik y Yup
Opciones para cambiar el administrador principal
Botón para activar/desactivar la sucursal


Sistema de Desactivación

Implementación de desactivación lógica en lugar de eliminación física
Confirmación antes de desactivar una sucursal
Validación para evitar desactivar sucursales ya inactivas
Actualización inmediata del estado en la interfaz



Endpoints Relacionados
MétodoRutaDescripciónParámetrosRespuestaGET/api/sucursalesObtener lista de sucursalesQuery params opcionales{ success, data: [sucursales] }GET/api/sucursales/:idObtener una sucursal específicaID en URL{ success, data: sucursal }POST/api/sucursalesCrear nueva sucursalDatos de sucursal{ success, message, data: sucursal }PUT/api/sucursales/:idActualizar sucursalID en URL, datos en body{ success, message, data: sucursal }DELETE/api/sucursales/:idDesactivar sucursalID en URL{ success, message }
Ejemplo de Implementación de Servicio
javascriptCopiar// Servicio para gestión de sucursales
const sucursalService = {
  // Obtener todas las sucursales
  obtenerTodas: async () => {
    try {
      const response = await api.get('/sucursales');
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Obtener sucursal por ID
  obtenerPorId: async (id) => {
    try {
      const response = await api.get(`/sucursales/${id}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Crear nueva sucursal
  crear: async (datos) => {
    try {
      const response = await api.post('/sucursales', datos);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Actualizar sucursal existente
  actualizar: async (id, datos) => {
    try {
      const response = await api.put(`/sucursales/${id}`, datos);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Eliminar/desactivar sucursal
  eliminar: async (id) => {
    try {
      const response = await api.delete(`/sucursales/${id}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }
};
Módulo de Usuarios
Este módulo permite la gestión completa de usuarios del sistema con diferentes roles.
Componentes Implementados

Listado de Usuarios

Interfaz de tabla con datos principales de usuarios
Filtrado avanzado por rol, sucursal, estado y búsqueda por texto
Indicadores visuales de estado y rol
Botones de acción para editar y desactivar usuarios


Formulario de Creación

Generación segura de contraseñas iniciales
Selección de rol con validación de permisos
Asignación a sucursal específica
Validación completa con Formik y Yup


Formulario de Edición

Carga automática de datos del usuario
Opción para cambiar contraseña
Restricciones según el rol del usuario actual
Bloqueo de cambios no permitidos


Sistema de Autorización

Códigos especiales para operaciones sensibles
Modal de verificación para acciones críticas
Registro de intentos de autorización
Protección contra cambios no autorizados


Gestión de Roles

Implementación de tres roles: administrador, cajero, cocinero
Diferentes permisos y accesos según rol
Validación para evitar asignación de roles no permitidos
Protección del usuario administrador principal



Endpoints Relacionados
MétodoRutaDescripciónParámetrosRespuestaGET/api/usuariosObtener lista de usuariosQuery params para filtrado{ success, data: [usuarios] }GET/api/usuarios/:idObtener un usuario específicoID en URL{ success, data: usuario }POST/api/usuariosCrear nuevo usuarioDatos de usuario{ success, message, data: usuario }PUT/api/usuarios/:idActualizar usuarioID en URL, datos en body{ success, message, data: usuario }DELETE/api/usuarios/:idDesactivar usuarioID en URL{ success, message }POST/api/usuarios/autorizarVerificar código de autorización{ codigo }{ success, authorized }
Filtrado Avanzado
El controlador de usuarios implementa un sistema de filtrado avanzado:
javascriptCopiarobtenerTodos: async (req, res) => {
  try {
    let consulta = {};
    
    // Si el usuario no es administrador, solo puede ver usuarios de su sucursal
    if (req.usuario.rol !== 'administrador') {
      consulta.sucursal = req.usuario.sucursal;
    }
    
    // Aplicar filtros de búsqueda
    const { rol, sucursal, estado, buscar } = req.query;
    
    // Si se especifica una sucursal en la consulta y el usuario es administrador
    if (sucursal && req.usuario.rol === 'administrador') {
      consulta.sucursal = sucursal;
    }
    
    // Filtrar por rol si se especifica
    if (rol) {
      consulta.rol = rol;
    }
    
    // Filtrar por estado si se especifica
    if (estado) {
      consulta.estado = estado;
    }
    
    // Buscar por nombre o usuario
    if (buscar) {
      consulta.$or = [
        { nombre: { $regex: buscar, $options: 'i' } },
        { usuario: { $regex: buscar, $options: 'i' } }
      ];
    }
    
    const usuarios = await Usuario.find(consulta)
      .select('-contrasena')
      .populate('sucursal', 'nombre direccion');

    return res.status(200).json({
      success: true,
      data: usuarios
    });
  } catch (error) {
    console.error('Error en obtenerTodos:', error);
    return res.status(500).json({ 
      success: false, 
      message: 'Error al obtener usuarios', 
      error: error.message 
    });
  }
}
Módulo de Categorías
Este módulo permite la gestión completa de categorías para la organización de productos.
Componentes Implementados

Listado de Categorías

Visualización en formato de tabla con opciones de acción
Indicador visual del estado de cada categoría
Botones para editar y eliminar categorías
Layout estandarizado con ListLayout


Formulario de Categorías

Validación completa de datos mediante Formik y Yup
Interfaz intuitiva para crear y editar categorías
Campos optimizados para la experiencia de usuario
Manejo de feedback visual tras operaciones exitosas



Endpoints Relacionados
MétodoRutaDescripciónParámetrosRespuestaGET/api/categoriasObtener lista de categoríasQuery params opcionales{ success, data: [categorias] }GET/api/categorias/:idObtener una categoría específicaID en URL{ success, data: categoria }POST/api/categoriasCrear nueva categoríaDatos de categoría{ success, message, data: categoria }PUT/api/categorias/:idActualizar categoríaID en URL, datos en body{ success, message, data: categoria }DELETE/api/categorias/:idEliminar categoríaID en URL{ success, message }
Problemas Resueltos:

Error con la pluralización de categorías con tildes - Resuelto mediante un mapeo explícito de entidades en ListLayout.

Módulo de Ingredientes
Este módulo permite la gestión completa de ingredientes con control de stock.
Componentes Implementados

Listado de Ingredientes

Visualización tabular con datos principales
Indicadores visuales de stock y disponibilidad
Filtrado por disponibilidad y stock
Botones de acción para editar y eliminar


Formulario de Ingredientes

Configuración de precio adicional para extras
Unidades de medida personalizables
Control de stock con niveles mínimos
Gestión de disponibilidad
Validación completa con feedback visual


Sistema de Stock

Alertas por stock bajo de ingredientes
Indicadores visuales del estado del stock
Controles para actualizar cantidades



Endpoints Relacionados
MétodoRutaDescripciónParámetrosRespuestaGET/api/ingredientesObtener lista de ingredientesQuery params para filtrado{ success, data: [ingredientes] }GET/api/ingredientes/:idObtener un ingrediente específicoID en URL{ success, data: ingrediente }POST/api/ingredientesCrear nuevo ingredienteDatos de ingrediente{ success, message, data: ingrediente }PUT/api/ingredientes/:idActualizar ingredienteID en URL, datos en body{ success, message, data: ingrediente }DELETE/api/ingredientes/:idEliminar ingredienteID en URL{ success, message }POST/api/ingredientes/:id/stockActualizar stockID en URL, { cantidad, operacion }{ success, message, data: { stock_actual } }
Ejemplo de Implementación de Servicio
javascriptCopiar// Servicio para gestión de ingredientes
const ingredienteService = {
  // Obtener todos los ingredientes
  obtenerTodos: async (filtros = {}) => {
    try {
      let queryParams = new URLSearchParams();
      
      // Añadir filtros a los parámetros de consulta
      if (filtros.disponible !== undefined) {
        queryParams.append('disponible', filtros.disponible);
      }
      
      if (filtros.stockBajo !== undefined) {
        queryParams.append('stockBajo', filtros.stockBajo);
      }
      
      if (filtros.buscar) {
        queryParams.append('buscar', filtros.buscar);
      }
      
      const response = await api.get(`/ingredientes?${queryParams.toString()}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Crear nuevo ingrediente
  crear: async (datos) => {
    try {
      const response = await api.post('/ingredientes', datos);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Actualizar stock de ingrediente
  actualizarStock: async (id, cantidad, operacion = 'agregar') => {
    try {
      const response = await api.post(`/ingredientes/${id}/stock`, {
        cantidad,
        operacion // 'agregar' o 'establecer'
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  }
};
Módulo de Productos
Este módulo permite la gestión completa del catálogo de productos que ofrece el negocio.
Componentes Implementados

Listado de Productos

Visualización en formato tabla con datos principales
Filtrado por categoría, disponibilidad y nombre
Visualización de imágenes de productos
Interruptor para cambio rápido de disponibilidad
Botones de acción para editar, configurar opciones y eliminar


Formulario de Productos

Creación de nuevos productos con validación
Edición de productos existentes
Asignación a categorías
Configuración de precio base
Ingreso de URL de imagen
Configuración de modalidad (para llevar/local/ambos)


Gestión de Opciones de Productos

Asignación de ingredientes a productos
Configuración de ingredientes predeterminados
Configuración de ingredientes removibles
Especificación de cantidades predeterminadas
Interfaz visual para añadir/eliminar opciones



Endpoints Relacionados
MétodoRutaDescripciónRoles PermitidosGET/api/productosObtener todos los productos (con filtros)Todos (autenticados)GET/api/productos/:idObtener un producto con sus opcionesTodos (autenticados)GET/api/productos/categoria/:categoriaIdObtener productos por categoríaTodos (autenticados)POST/api/productosCrear un nuevo productoAdministradorPUT/api/productos/:idActualizar un productoAdministradorDELETE/api/productos/:idEliminar un productoAdministradorPUT/api/productos/:id/opcionesActualizar opciones de ingredientesAdministradorPATCH/api/productos/:id/disponibilidadCambiar disponibilidadAdministrador, Cocinero
Filtrado Avanzado
El controlador de productos implementa un sistema de filtrado avanzado que permite:
javascriptCopiar// Ejemplo de filtrado en obtenerTodos
obtenerTodos: async (req, res) => {
  try {
    // Construir filtro basado en query params
    const filtro = {};
    
    // Filtrar por disponibilidad
    if (req.query.disponible !== undefined) {
      filtro.disponible = req.query.disponible === 'true';
    }
    
    // Filtrar por categoría
    if (req.query.categoria) {
      filtro.categoria = req.query.categoria;
    }
    
    // Filtrar por para_llevar
    if (req.query.para_llevar) {
      filtro.para_llevar = req.query.para_llevar;
    }
    
    const productos = await Producto.find(filtro)
      .populate('categoria', 'nombre descripcion');
    
    return res.status(200).json({
      success: true,
      data: productos
    });
  } catch (error) {
    // Manejo de errores...
  }
}
Gestión de Opciones de Producto
El sistema permite configurar qué ingredientes pueden añadirse a cada producto, con opciones para definir:

Ingredientes predeterminados: Aquellos que vienen por defecto con el producto
Ingredientes removibles: Aquellos que el cliente puede quitar
Cantidad predeterminada: Número de unidades que vienen por defecto

Esta configuración es esencial para el módulo de ventas, donde los clientes pueden personalizar sus pedidos añadiendo o quitando ingredientes específicos.
Problemas Resueltos:

Corrección de filtrado para mostrar correctamente todos los productos
Mejora en la búsqueda por nombre mediante filtrado en el cliente
Solución al problema de CORS con métodos PATCH
Adaptaciones para mejorar la visualización en diferentes dispositivos

Módulo de Ciclos de Caja
Este módulo implementa un sistema completo de ciclos de caja con autorización administrativa, permitiendo un control financiero exhaustivo de las operaciones.
Componentes Implementados

Utilidad de Autorización

Servicio centralizado para verificar códigos de autorización de administradores
Validación de PIN administrativo contra base de datos
Gestión de autorizaciones temporales para operaciones sensibles
Protección robusta para operaciones financieras


Gestión de Ciclos

Apertura de ciclos con monto inicial verificado
Consulta de ciclo activo para la sucursal del usuario
Cierre de ciclo con autorización administrativa obligatoria
Cálculo automático de montos y diferencias
Historial de ciclos con filtrado y paginación


Visualización Condicionada

Protección de información financiera sensible
Administradores pueden ver todos los ciclos con información completa
Cajeros solo pueden ver ciclos de su propia sucursal
Autorización temporal para acceder a información detallada


Integración con Ventas

Asociación automática de ventas al ciclo activo
Actualización en tiempo real de montos acumulados
Verificación de ciclo activo antes de permitir ventas
Consulta de ventas por ciclo específico



Endpoints Relacionados
MétodoRutaDescripciónRoles PermitidosPOST/api/ciclos-caja/abrirAbrir un nuevo ciclo de cajaAdministrador, CajeroGET/api/ciclos-caja/activoObtener ciclo activo para la sucursalAdministrador, CajeroPOST/api/ciclos-caja/:id/cerrarCerrar un ciclo de cajaAdministrador, Cajero*GET/api/ciclos-cajaObtener historial de ciclosAdministrador, Cajero**GET/api/ciclos-caja/:idObtener detalles de un ciclo específicoAdministrador, Cajero**
*Requiere autorización administrativa
**Cajeros solo ven ciclos de su sucursal
Modelo de Datos
javascriptCopiarconst cicloCajaSchema = new Schema({
  sucursal: {
    type: Schema.Types.ObjectId,
    ref: 'Sucursal',
    required: true
  },
  usuario_apertura: {
    type: Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true
  },
  usuario_cierre: {
    type: Schema.Types.ObjectId,
    ref: 'Usuario'
  },
  fecha_apertura: {
    type: Date,
    default: Date.now,
    required: true
  },
  fecha_cierre: {
    type: Date
  },
  monto_inicial: {
    type: Number,
    required: true,
    min: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  monto_ventas: {
    type: Number,
    default: 0,
    min: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  monto_final: {
    type: Number,
    min: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  monto_diferencia: {
    type: Number,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  estado: {
    type: String,
    enum: ['abierto', 'cerrado'],
    default: 'abierto'
  },
  notas: {
    type: String,
    trim: true
  },
  admin_autorizacion: {
    type: Schema.Types.ObjectId,
    ref: 'Usuario'
  }
}, {
  timestamps: {
    createdAt: 'fecha_creacion',
    updatedAt: 'fecha_actualizacion'
  }
});
Ejemplo de Implementación de Servicio
javascriptCopiar// Servicio para gestión de ciclos de caja
const cicloCajaService = {
  // Abrir un nuevo ciclo de caja
  abrirCiclo: async (datos) => {
    try {
      const response = await api.post('/ciclos-caja/abrir', datos);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Obtener ciclo activo para la sucursal actual
  obtenerCicloActivo: async () => {
    try {
      const response = await api.get('/ciclos-caja/activo');
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Cerrar un ciclo de caja existente (requiere autorización)
  cerrarCiclo: async (id, datos) => {
    try {
      const response = await api.post(`/ciclos-caja/${id}/cerrar`, datos);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Obtener historial de ciclos con paginación y filtros
  obtenerHistorial: async (parametros = {}) => {
    try {
      const queryParams = new URLSearchParams();
      
      // Parámetros de paginación
      if (parametros.pagina) {
        queryParams.append('pagina', parametros.pagina);
      }
      
      if (parametros.limite) {
        queryParams.append('limite', parametros.limite);
      }
      
      // Filtros específicos
      if (parametros.fechaInicio) {
        queryParams.append('fechaInicio', parametros.fechaInicio);
      }
      
      if (parametros.fechaFin) {
        queryParams.append('fechaFin', parametros.fechaFin);
      }
      
      if (parametros.estado) {
        queryParams.append('estado', parametros.estado);
      }
      
      if (parametros.sucursal) {
        queryParams.append('sucursal', parametros.sucursal);
      }
      
      const response = await api.get(`/ciclos-caja?${queryParams.toString()}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Verificar autorización administrativa
  verificarAutorizacion: async (codigo) => {
    try {
      const response = await api.post('/usuarios/autorizar', { codigo });
      return response.data;
    } catch (error) {
      throw error;
    }
  }
};
Modelo de Seguridad
El sistema implementa un modelo de seguridad por capas:

Nivel de Sucursal: Cajeros solo pueden ver y operar con ciclos de su propia sucursal
Nivel de Autorización: Información sensible (montos finales, diferencias) protegida por autorización administrativa
Nivel de Operación: Operaciones críticas (cierre de caja) requieren PIN de administrador
Nivel de Auditoría: Registro completo de quién autorizó cada operación

Flujo de Trabajo:

Al iniciar el día, un cajero (con autorización de administrador) abre el ciclo de caja registrando el monto inicial
Durante el día, todas las ventas se asocian automáticamente al ciclo activo, actualizando el monto acumulado
Al finalizar el día, un cajero (con autorización de administrador) cierra el ciclo, registrando el monto final
El sistema calcula automáticamente si hay diferencias entre lo esperado y lo reportado
Los administradores pueden consultar el historial completo de ciclos con información detallada

Módulo de Ventas
Este módulo permite realizar el proceso completo de ventas, desde la selección de productos, personalización, hasta la generación de facturas y el mantenimiento de un historial de ventas.
Componentes Implementados

Punto de Venta

Interfaz optimizada para cajeros
Catálogo visual de productos organizados por categorías
Sistema de carrito de compras en tiempo real
Indicadores visuales de disponibilidad
Sección para aplicar descuentos o promociones
Verificación de ciclo de caja activo


Sistema de Personalización de Productos

Interfaz para añadir o quitar ingredientes
Cálculo automático de precios según personalización
Visualización clara de cambios aplicados
Opciones para guardar personalizaciones frecuentes


Proceso de Pago

Selección de método de pago (efectivo, Nequi, Daviplata, etc.)
Resumen de venta antes de confirmar
Opción para generar factura
Registro automático en el sistema
Asociación al ciclo de caja activo


Historial de Ventas

Filtrado por fecha, método de pago y ciclo de caja
Búsqueda avanzada de ventas
Visualización del estado (completada/anulada)
Acceso a detalles de cada venta


Detalles de Venta

Visualización completa de productos y personalizaciones
Información de precios desglosada
Datos del cajero y sucursal
Botón para anular ventas (con autorización)
Referencia al ciclo de caja correspondiente


Impresión de Facturas

Generación de facturas en formato de ticket
Impresión directa desde el navegador
Diseño optimizado para impresoras térmicas
Opción para reimpresión de facturas anteriores



Endpoints Relacionados
MétodoRutaDescripciónRoles PermitidosGET/api/ventasObtener todas las ventas (con filtros)Administrador, CajeroGET/api/ventas/:idObtener una venta específica con detallesAdministrador, CajeroPOST/api/ventasCrear una nueva ventaCajeroPATCH/api/ventas/:id/anularAnular una venta existenteAdministrador, CajeroGET/api/ventas/reporte/diarioObtener reporte diarioAdministradorGET/api/ventas/reporte/fechasObtener reporte por rango de fechasAdministradorGET/api/ventas/ciclo/:idObtener ventas de un ciclo específicoAdministrador, Cajero
Ejemplo de Implementación del Servicio de Ventas
javascriptCopiar// Servicio para gestión de ventas
const ventaService = {
  // Obtener todas las ventas con filtros opcionales
  obtenerTodas: async (filtros = {}) => {
    try {
      let queryParams = new URLSearchParams();
      
      if (filtros.fechaInicio) {
        queryParams.append('fechaInicio', filtros.fechaInicio);
      }
      
      if (filtros.fechaFin) {
        queryParams.append('fechaFin', filtros.fechaFin);
      }
      
      if (filtros.metodoPago) {
        queryParams.append('metodoPago', filtros.metodoPago);
      }
      
      if (filtros.estado) {
        queryParams.append('estado', filtros.estado);
      }
      
      if (filtros.cicloCaja) {
        queryParams.append('cicloCaja', filtros.cicloCaja);
      }
      
      const response = await api.get(`/ventas?${queryParams.toString()}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Obtener venta por ID
  obtenerPorId: async (id) => {
    try {
      const response = await api.get(`/ventas/${id}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Crear nueva venta
  crear: async (datos) => {
    try {
      const response = await api.post('/ventas', datos);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Anular venta
  anular: async (id, motivo) => {
    try {
      const response = await api.patch(`/ventas/${id}/anular`, { motivo });
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Obtener reporte diario
  obtenerReporteDiario: async (fecha, cicloCaja) => {
    try {
      const queryParams = new URLSearchParams();
      if (fecha) {
        queryParams.append('fecha', fecha);
      }
      if (cicloCaja) {
        queryParams.append('cicloCaja', cicloCaja);
      }
      
      const response = await api.get(`/ventas/reporte/diario?${queryParams.toString()}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Obtener ventas por ciclo de caja
  obtenerPorCiclo: async (cicloId) => {
    try {
      const response = await api.get(`/ventas/ciclo/${cicloId}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }
};
Problemas Resueltos

Error de Cálculo de Precios

Se identificó un error en el cálculo de precios de productos personalizados
Se modificó el controlador para evitar el doble cálculo del precio
Se mejoró la precisión de los cálculos utilizando técnicas de formato numérico


Error en ObjectId de Mongoose

Se corrigió el uso de mongoose.Types.ObjectId() añadiendo la palabra clave new
Se solucionó el error en el filtrado por sucursal y ciclo_caja
Se restauró la funcionalidad de reportes de ventas y el historial


Actualización del Modelo de Venta

Se añadió el campo ciclo_caja al modelo Venta para asociar ventas a ciclos
Se creó un índice para optimizar consultas por ciclo_caja
Se implementó el populate correcto para cargar datos del ciclo asociado


Mejora de la Experiencia de Usuario

Se optimizó la interfaz para pantallas táctiles
Se implementaron teclas de acceso rápido para operaciones frecuentes
Se mejoró el flujo de trabajo para reducir clics innecesarios
Se añadió verificación de ciclo activo en el punto de venta



Funcionalidades Pendientes

Descuento automático de inventario

Implementación del descuento automático de ingredientes al realizar ventas
Actualización en tiempo real del stock disponible
Alertas cuando algún ingrediente alcanza nivel crítico


Reportes avanzados

Análisis detallado de ventas por producto y período
Gráficos interactivos para visualización de tendencias
Exportación a formatos Excel y PDF



Última actualización: 28 de marzo de 2025