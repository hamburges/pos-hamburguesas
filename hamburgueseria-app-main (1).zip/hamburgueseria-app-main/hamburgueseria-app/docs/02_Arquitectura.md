# Arquitectura del Sistema

## Tecnologías Utilizadas

El Sistema de Gestión para "JQ Q Berraquera" está construido utilizando un stack de tecnologías modernas que permiten un desarrollo escalable, mantenible y con buen rendimiento.

### Backend

- **Lenguaje**: Node.js
- **Framework**: Express.js
- **Base de Datos**: MongoDB
- **ODM**: Mongoose
- **Autenticación**: JWT (JSON Web Tokens)

### Frontend

- **Framework**: React.js
- **Estilo**: Bootstrap 5
- **Gestión de estado**: Context API
- **Peticiones HTTP**: Axios
- **Enrutamiento**: React Router Dom v6
- **Validación de formularios**: Formik + Yup
- **Impresión**: react-to-print

## Estructura del Proyecto

La estructura del proyecto sigue un patrón de organización modular que separa claramente las responsabilidades entre el backend y el frontend.
C:\Users\david.DESKTOP-JC0UQP0\OneDrive\Desktop\Nueva carpeta\hamburgueseria-app\  # Directorio raíz
├── backend\                               # Servidor y lógica de negocio
│   ├── config\                            # Configuración de la aplicación y BD
│   │   └── database.js                    # Configuración de conexión a MongoDB
│   ├── controllers\                       # Controladores para cada entidad
│   │   ├── auth.controller.js             # Controlador de autenticación
│   │   ├── usuario.controller.js          # Controlador de usuarios
│   │   ├── sucursal.controller.js         # Controlador de sucursales
│   │   ├── categoria.controller.js        # Controlador de categorías
│   │   ├── ingrediente.controller.js      # Controlador de ingredientes
│   │   ├── producto.controller.js         # Controlador de productos
│   │   ├── opcion-producto.controller.js  # Controlador de opciones de producto
│   │   └── venta.controller.js            # Controlador de ventas
│   ├── models\                            # Modelos de datos
│   │   ├── Sucursal.js                    # Modelo para sucursales
│   │   ├── Usuario.js                     # Modelo para usuarios
│   │   ├── Categoria.js                   # Modelo para categorías
│   │   ├── Producto.js                    # Modelo para productos
│   │   ├── Ingrediente.js                 # Modelo para ingredientes
│   │   ├── OpcionProducto.js              # Modelo para opciones de producto
│   │   ├── Venta.js                       # Modelo para ventas
│   │   └── index.js                       # Exportación centralizada de modelos
│   ├── routes\                            # Rutas de la API
│   │   ├── index.js                       # Configuración central de rutas
│   │   ├── auth.routes.js                 # Rutas de autenticación
│   │   ├── usuario.routes.js              # Rutas de usuarios
│   │   ├── sucursal.routes.js             # Rutas de sucursales
│   │   ├── categoria.routes.js            # Rutas de categorías
│   │   ├── ingrediente.routes.js          # Rutas de ingredientes
│   │   ├── producto.routes.js             # Rutas de productos
│   │   ├── opcion-producto.routes.js      # Rutas de opciones de producto
│   │   └── venta.routes.js                # Rutas de ventas
│   ├── middleware\                        # Middleware
│   │   └── auth.middleware.js             # Middleware de autenticación
│   ├── utils\                             # Funciones auxiliares
│   │   └── auth.utils.js                  # Utilidades para autenticación
│   ├── scripts\                           # Scripts de utilidad
│   │   └── setup-admin.js                 # Script para crear usuario administrador inicial
│   ├── server.js                          # Archivo principal del servidor
│   ├── .env                               # Variables de entorno
│   └── package.json                       # Dependencias backend
├── frontend\                              # Interfaz de usuario (React)
│   ├── public\                            # Archivos estáticos
│   │   └── index.html                     # Plantilla HTML principal
│   ├── src\                               # Código fuente
│   │   ├── components\                    # Componentes reutilizables
│   │   │   ├── forms\                     # Componentes de formularios
│   │   │   ├── layout\                    # Componentes de estructura
│   │   │   │   ├── MainLayout.js          # Layout principal con menú
│   │   │   │   ├── ListLayout.js          # Layout para listas
│   │   │   │   └── CajeroLayout.js        # Layout para vista de cajero
│   │   │   ├── ui\                        # Componentes de interfaz
│   │   │   └── PrivateRoute.js            # Protección de rutas por rol
│   │   ├── pages\                         # Páginas por módulo
│   │   │   ├── admin\                     # Páginas de administrador
│   │   │   │   ├── categorias\            # Gestión de categorías
│   │   │   │   ├── ingredientes\          # Gestión de ingredientes
│   │   │   │   ├── productos\             # Gestión de productos
│   │   │   │   ├── reportes\              # Reportes y estadísticas
│   │   │   │   ├── sucursales\            # Gestión de sucursales
│   │   │   │   ├── usuarios\              # Gestión de usuarios
│   │   │   │   └── Dashboard.js           # Dashboard del administrador
│   │   │   ├── auth\                      # Páginas de autenticación
│   │   │   │   └── Login.js               # Página de inicio de sesión
│   │   │   ├── cajero\                    # Páginas para rol de cajero
│   │   │   │   └── ventas\                # Módulo de ventas
│   │   │   │       ├── PuntoVenta.js      # Interfaz de punto de venta
│   │   │   │       ├── PersonalizarProducto.js # Personalización de productos
│   │   │   │       ├── ProcesarPago.js    # Procesamiento de pago
│   │   │   │       ├── HistorialVentas.js # Historial de ventas
│   │   │   │       ├── DetalleVenta.js    # Detalle de venta
│   │   │   │       └── FacturaVenta.js    # Generación de factura
│   │   │   └── cocinero\                  # Páginas para rol de cocinero
│   │   ├── services\                      # Servicios y peticiones API
│   │   │   ├── api.js                     # Configuración de Axios
│   │   │   ├── sucursalService.js         # Servicio para sucursales
│   │   │   ├── usuarioService.js          # Servicio para usuarios
│   │   │   ├── categoriaService.js        # Servicio para categorías
│   │   │   ├── ingredienteService.js      # Servicio para ingredientes
│   │   │   ├── productoService.js         # Servicio para productos
│   │   │   ├── opcionProductoService.js   # Servicio para opciones de producto
│   │   │   ├── ventaService.js            # Servicio para ventas
│   │   │   └── dashboardService.js        # Servicio para dashboard
│   │   ├── context\                       # Contextos para gestión de estado
│   │   │   └── AuthContext.js             # Contexto de autenticación
│   │   ├── utils\                         # Utilidades
│   │   │   ├── logger.js                  # Utilidad para registro de logs
│   │   │   ├── formatters.js              # Utilidades para formateo de datos
│   │   │   └── iconos.js                  # Iconos utilizados en la aplicación
│   │   ├── assets\                        # Recursos estáticos
│   │   │   ├── css\                       # Estilos CSS personalizados
│   │   │   │   └── styles.css             # Estilos personalizados
│   │   │   └── images\                    # Imágenes e iconos
│   │   ├── App.js                         # Componente principal y rutas
│   │   └── index.js                       # Punto de entrada
│   └── package.json                       # Dependencias frontend
├── docs\                                  # Documentación adicional
├── .gitignore                             # Archivos ignorados en todo el proyecto
└── README.md                              # Documentación general
Copy
## Explicación de la Estructura

### Backend

- **config**: Contiene archivos de configuración del sistema, como la conexión a la base de datos.
- **controllers**: Implementa la lógica de negocio para cada entidad del sistema.
- **models**: Define los esquemas de Mongoose para interactuar con MongoDB.
- **routes**: Establece los endpoints de la API REST para cada entidad.
- **middleware**: Contiene funciones intermedias para autenticación y autorización.
- **utils**: Proporciona funciones auxiliares reutilizables.
- **scripts**: Contiene scripts de utilidad, como la creación del usuario administrador inicial.

### Frontend

- **components**: Componentes React reutilizables organizados por funcionalidad.
- **pages**: Implementaciones específicas de páginas para cada módulo y rol.
- **services**: Funciones para comunicación con el backend mediante Axios.
- **context**: Implementación de Context API para gestión de estado global.
- **utils**: Funciones auxiliares para el frontend.
- **assets**: Recursos estáticos como imágenes y estilos CSS.

## Modelo de Datos

El sistema utiliza MongoDB como base de datos, implementando los siguientes esquemas de Mongoose:

### Esquemas Principales

#### 1. Sucursal

```javascript
const sucursalSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  direccion: {
    type: String,
    required: true,
    trim: true
  },
  telefono: {
    type: String,
    required: true,
    trim: true
  },
  administrador_principal: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Usuario'
  },
  estado: {
    type: String,
    enum: ['activa', 'inactiva'],
    default: 'activa'
  }
}, { timestamps: { createdAt: 'fecha_creacion', updatedAt: 'fecha_actualizacion' } });
2. Usuario
javascriptCopyconst usuarioSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: true,
    trim: true
  },
  usuario: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  contrasena: {
    type: String,
    required: true
  },
  rol: {
    type: String,
    enum: ['administrador', 'cajero', 'cocinero'],
    required: true
  },
  sucursal: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sucursal',
    required: true
  },
  estado: {
    type: String,
    enum: ['activo', 'inactivo'],
    default: 'activo'
  },
  codigo_autorizacion: {
    type: String
  }
}, { timestamps: { createdAt: 'fecha_creacion', updatedAt: 'fecha_actualizacion' } });
3. Categoría
javascriptCopyconst categoriaSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  descripcion: {
    type: String,
    trim: true
  }
}, { timestamps: { createdAt: 'fecha_creacion', updatedAt: 'fecha_actualizacion' } });
4. Producto
javascriptCopyconst productoSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: true,
    trim: true
  },
  descripcion: {
    type: String,
    trim: true
  },
  precio_base: {
    type: Number,
    required: true,
    min: 0,
    get: v => Math.round(v * 100) / 100
  },
  categoria: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Categoria',
    required: true
  },
  imagen: {
    type: String
  },
  disponible: {
    type: Boolean,
    default: true
  },
  para_llevar: {
    type: String,
    enum: ['sí', 'no', 'ambos'],
    default: 'ambos'
  }
}, { timestamps: { createdAt: 'fecha_creacion', updatedAt: 'fecha_actualizacion' } });
5. Ingrediente
javascriptCopyconst ingredienteSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  precio_adicional: {
    type: Number,
    default: 0,
    min: 0,
    get: v => Math.round(v * 100) / 100
  },
  disponible: {
    type: Boolean,
    default: true
  },
  stock: {
    type: Number,
    default: 0,
    min: 0
  },
  stock_minimo: {
    type: Number,
    default: 10,
    min: 0
  },
  unidad_medida: {
    type: String
  }
}, { timestamps: { createdAt: 'fecha_creacion', updatedAt: 'fecha_actualizacion' } });
6. OpcionProducto
javascriptCopyconst opcionProductoSchema = new mongoose.Schema({
  producto: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Producto',
    required: true
  },
  ingrediente: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Ingrediente',
    required: true
  },
  es_predeterminado: {
    type: Boolean,
    default: true
  },
  es_removible: {
    type: Boolean,
    default: true
  },
  cantidad_predeterminada: {
    type: Number,
    default: 1,
    min: 0
  }
}, { timestamps: { createdAt: 'fecha_creacion', updatedAt: 'fecha_actualizacion' } });

// Índice compuesto para prevenir duplicados
opcionProductoSchema.index({ producto: 1, ingrediente: 1 }, { unique: true });
7. Venta
javascriptCopyconst ventaSchema = new mongoose.Schema({
  fecha: {
    type: Date,
    required: true,
    default: Date.now
  },
  cajero: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true
  },
  sucursal: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sucursal',
    required: true
  },
  estado: {
    type: String,
    enum: ['completada', 'anulada'],
    default: 'completada'
  },
  metodo_pago: {
    type: String,
    enum: ['efectivo', 'nequi', 'daviplata', 'combinado', 'transferencia'],
    required: true
  },
  total_sin_impuestos: {
    type: Number,
    required: true,
    min: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  total_impuestos: {
    type: Number,
    required: true,
    min: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  total: {
    type: Number,
    required: true,
    min: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  para_llevar: {
    type: Boolean,
    default: false
  },
  productos: [{
    producto: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Producto',
      required: true
    },
    nombre_producto: {
      type: String,
      required: true
    },
    precio_unitario: {
      type: Number,
      required: true,
      min: 0
    },
    cantidad: {
      type: Number,
      required: true,
      min: 1,
      default: 1
    },
    subtotal: {
      type: Number,
      required: true,
      min: 0
    },
    personalizaciones: [{
      ingrediente: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Ingrediente'
      },
      nombre_ingrediente: {
        type: String
      },
      accion: {
        type: String,
        enum: ['agregar', 'quitar'],
        required: true
      },
      cantidad: {
        type: Number,
        min: 1,
        default: 1
      },
      precio_adicional: {
        type: Number,
        default: 0
      }
    }]
  }],
  notas: {
    type: String,
    trim: true
  }
}, { timestamps: { createdAt: 'fecha_creacion', updatedAt: 'fecha_actualizacion' } });
Relaciones entre Modelos
Las relaciones entre los modelos de datos se implementan mediante referencias a ObjectIds en MongoDB. A continuación se muestra un diagrama que ilustra estas relaciones:
┌───────────┐     ┌──────────┐     ┌─────────────┐
│  Sucursal │◄────┤  Usuario │────►│    Venta    │
└───────────┘     └──────────┘     └─────────────┘
     ▲                                    ▲
     │                                    │
     │                                    │
┌────┴────────┐      ┌─────────────────┐  │
│ Producto    │◄─────┤ OpcionProducto  │  │
└─────────────┘      └─────────────────┘  │
     ▲                       ▲            │
     │                       │            │
     │                       │            │
┌────┴────────┐      ┌───────┴─────────┐  │
│ Categoría   │      │ Ingrediente     │◄─┘
└─────────────┘      └─────────────────┘
Explicación de Relaciones

Usuario - Sucursal: Cada usuario pertenece a una sucursal específica. Una sucursal puede tener múltiples usuarios.
Producto - Categoría: Cada producto pertenece a una categoría. Una categoría puede tener múltiples productos.
Producto - OpcionProducto - Ingrediente: Relación muchos a muchos entre productos e ingredientes, implementada mediante la entidad OpcionProducto, que permite definir opciones personalizables para cada producto.
Sucursal - Administrador Principal: Una sucursal puede tener un administrador principal designado, que es una referencia a un usuario.
Venta - Usuario (Cajero): Cada venta está asociada al cajero que la procesó.
Venta - Sucursal: Cada venta está asociada a la sucursal donde se realizó.
Venta - Producto - Ingrediente: Las ventas incluyen productos, que pueden tener personalizaciones de ingredientes.

Implementación de la Autenticación
El sistema utiliza JSON Web Tokens (JWT) para la autenticación y autorización de usuarios. El flujo de autenticación implementado es el siguiente:

El usuario envía sus credenciales (usuario y contraseña) al endpoint /auth/login.
El backend verifica las credenciales contra la base de datos.
Si son válidas, genera un token JWT que contiene información del usuario (ID, rol, sucursal).
El token se envía al frontend, que lo almacena en localStorage.
Para peticiones posteriores, el frontend envía el token en el header Authorization.
El middleware de autenticación verifica la validez del token en cada petición a rutas protegidas.

Middleware de Autenticación
Se han implementado varios middlewares para garantizar la seguridad del sistema:

verificarToken: Comprueba que el token JWT es válido y no ha expirado.
verificarRol: Restringe el acceso basado en roles de usuario.
verificarUsuarioActivo: Asegura que solo los usuarios activos puedan acceder al sistema.
verificarAccesoSucursal: Limita el acceso a datos de sucursales según el rol y asignación del usuario.

Arquitectura del Frontend
El frontend está implementado con React y sigue un patrón de arquitectura basado en componentes, con separación clara de responsabilidades:

Componentes: Unidades visuales reutilizables.
Páginas: Combinación de componentes para crear vistas completas.
Servicios: Lógica de comunicación con el backend.
Contextos: Gestión del estado global de la aplicación.
Utilidades: Funciones auxiliares compartidas.

Gestión del Estado
El estado se gestiona principalmente mediante Context API de React, implementando los siguientes contextos:

AuthContext: Maneja el estado de autenticación, incluyendo el usuario actual y sus permisos.

Protección de Rutas
Se implementa un sistema de protección de rutas basado en roles mediante el componente PrivateRoute, que verifica:

Si el usuario está autenticado.
Si el usuario tiene el rol adecuado para acceder a la ruta.
Si el usuario está activo en el sistema.

Comunicación Frontend-Backend
La comunicación entre frontend y backend se realiza mediante peticiones HTTP utilizando Axios. Se ha implementado una instancia configurada en api.js que:

Establece la URL base para todas las peticiones.
Configura interceptores para incluir automáticamente el token JWT en cada petición.
Maneja errores de forma centralizada, incluyendo la redirección a login cuando el token expira.

Consideraciones de Seguridad
La arquitectura implementa varias medidas de seguridad:

Autenticación con JWT: Tokens con tiempo de expiración.
Autorización por roles: Restricción de acceso según el rol del usuario.
Validación de datos: Tanto en frontend (Formik+Yup) como en backend (Mongoose).
Protección contra CORS: Configuración adecuada para prevenir solicitudes no autorizadas.
Encriptación de contraseñas: Almacenamiento seguro mediante hash.

Escalabilidad
La arquitectura está diseñada para ser escalable:

Separación de responsabilidades: Facilita el crecimiento del sistema sin afectar componentes existentes.
Modularidad: Permite añadir nuevas funcionalidades como módulos independientes.
Base de datos NoSQL: MongoDB permite evolucionar el esquema sin migraciones complejas.
Middleware reutilizable: Facilita la aplicación consistente de reglas de negocio.

Módulos Implementados y Pendientes
Módulos Implementados

Autenticación: Sistema completo de login y protección de rutas.
Usuarios: Gestión de usuarios con diferentes roles.
Sucursales: Administración de múltiples sucursales.
Categorías: Organización de productos por categorías.
Ingredientes: Gestión de ingredientes con control de stock.
Productos: Catálogo completo con opciones de personalización.
Ventas (Parcial): Punto de venta con carrito, personalización, historial y facturas.

Módulos Pendientes

Ventas (Completar):

Cierre de caja y arqueo
Cálculo de vueltas
Descuento automático de inventario


Caja:

Apertura y cierre de caja
Registro de movimientos
Cuadre de caja
Reportes diarios/semanales


Inventario Avanzado:

Gestión avanzada de stock
Alertas automáticas
Registro de ingresos/egresos
Reportes de consumo


Reportes y Estadísticas:

Dashboard avanzado
Análisis de ventas y rentabilidad
Exportación de datos
4. **Reportes y Estadísticas**:
   - Dashboard avanzado
   - Análisis de ventas y rentabilidad
   - Exportación de datos
   - Visualizaciones gráficas

## Flujos de Trabajo Principales

### Flujo de Autenticación
1. El usuario accede a la aplicación
2. Introduce credenciales en la pantalla de login
3. El backend verifica las credenciales y genera un token JWT
4. El frontend almacena el token y redirige según el rol del usuario
5. El sistema verifica el token en cada operación protegida

### Flujo de Venta
1. El cajero selecciona la categoría y productos
2. Personaliza cada producto según las preferencias del cliente
3. Revisa el carrito con todos los productos seleccionados
4. Procesa el pago seleccionando el método adecuado
5. Confirma la venta y genera la factura
6. El sistema registra la venta en la base de datos

### Flujo de Gestión de Inventario
1. El administrador o cocinero verifica el stock actual
2. Recibe alertas de ingredientes con stock bajo
3. Actualiza las cantidades al recibir nuevos suministros
4. El sistema registra todos los movimientos de inventario

## Integraciones Futuras

La arquitectura está preparada para integraciones con:

1. **Sistemas de Pago Electrónico**: Integración directa con APIs de Nequi, Daviplata, etc.
2. **Sistemas Fiscales**: Facturación electrónica según requisitos regulatorios
3. **Aplicaciones Móviles**: Desarrollo de apps para clientes y/o personal
4. **Sistemas de Lealtad**: Programas de fidelización de clientes
5. **Servicios de Delivery**: Integración con plataformas de entrega a domicilio

## Conclusiones y Recomendaciones Técnicas

La arquitectura implementada proporciona una base sólida para el Sistema de Gestión para "JQ Q Berraquera", permitiendo la escalabilidad y mantenibilidad a medida que el negocio crece. Las principales recomendaciones técnicas para el desarrollo futuro incluyen:

1. **Optimización de Rendimiento**: Implementar estrategias de caché y optimización de consultas a medida que el volumen de datos crezca.
2. **Integración Continua**: Adoptar prácticas de CI/CD para asegurar la calidad del código y facilitar el despliegue.
3. **Pruebas Automatizadas**: Aumentar la cobertura de pruebas automatizadas para garantizar la estabilidad del sistema.
4. **Monitoreo**: Implementar soluciones de monitoreo para detectar problemas proactivamente.
5. **Copias de Seguridad**: Establecer un sistema robusto de copias de seguridad de la base de datos.

---

*Última actualización: 12 de marzo de 2025*