# Índice - Sistema de Gestión para "JQ Q Berraquera"

## Documentación Completa del Sistema

Este índice organiza toda la documentación del Sistema de Gestión para "JQ Q Berraquera", dividida en archivos independientes para facilitar su mantenimiento y actualización.

## Documentos

1. [Introducción](./01_Introducción.md)
   - Información general del proyecto
   - Descripción del sistema
   - Productos y características principales
   - Estado actual del desarrollo

2. [Arquitectura](./02_Arquitectura.md)
   - Tecnologías utilizadas (Backend y Frontend)
   - Estructura del proyecto
   - Diagrama de directorios y archivos
   - Modelo de datos
   - Relaciones entre modelos

3. [Instalación](./03_Instalación.md)
   - Requisitos previos
   - Proceso de instalación
   - Configuración del entorno
   - Variables de entorno
   - Creación de usuario administrador
   - Ejecución del sistema

4. [Funcionalidades](./04_Funcionalidades.md)
   - Módulos implementados
   - Sistema de autenticación
   - Gestión de usuarios
   - Gestión de sucursales
   - API Endpoints
   - Módulo de productos e ingredientes

5. [Problemas y Soluciones](./05_Problemas_y_Soluciones.md)
   - Problemas del backend
   - Problemas del frontend 
   - Estrategias para resolución de problemas
   - Casos de prueba reproducibles

6. [Integración de Bibliotecas](./06_Integración_de_Bibliotecas.md)
   - Bibliotecas del backend
   - Bibliotecas del frontend
   - Propósito y uso de cada biblioteca
   - Dependencias principales

7. [Actualizaciones](./07_Actualizaciones.md)
   - Historial de cambios
   - Versiones pasadas
   - Próximas versiones planificadas
   - Mejoras futuras
   
8. [Módulo de Productos](./08_Módulo_de_Productos.md)
   - Descripción del módulo
   - Funcionalidades implementadas
   - Estructura de archivos
   - API Endpoints específicos
   - Modelo de datos
   - Casos de uso
   - Soluciones a problemas específicos

9. [Módulo de Ventas](./09_Módulo_de_Ventas.md)
   - Descripción del módulo de ventas
   - Punto de venta para cajeros
   - Sistema de personalización de productos
   - Historial y detalles de ventas
   - Generación e impresión de facturas
   - Funcionalidades pendientes
   - Problemas resueltos

10. [Sistema de Gestión de Pagos](./10_Sistema_de_Gestión_de_Pagos.md)
    - Análisis arquitectónico
    - Reconciliación financiera
    - Sistema de confirmación de cambio
    - Validación desacoplada
    - Mecanismos de extensión y eventos
    - Integración con Módulo de Ventas

## Metodología de actualización de la documentación

Para mantener esta documentación actualizada:

1. **Actualizaciones regulares**: Cada vez que se complete una funcionalidad o módulo.
2. **Control de versiones**: Documentar cada cambio en `07_Actualizaciones.md`.
3. **Independencia de archivos**: Modificar sólo el documento correspondiente a la sección actualizada.
4. **Consistencia en enlaces**: Mantener la estructura de enlaces entre documentos.
5. **Formato estándar**: Mantener el formato Markdown para facilitar la edición y compatibilidad.

## Acceso al Sistema

- URL del Backend: http://localhost:3001/api
- URL del Frontend: http://localhost:3000
- Usuario administrador por defecto: admin / admin123

---

*Última actualización: 7 de abril de 2025*