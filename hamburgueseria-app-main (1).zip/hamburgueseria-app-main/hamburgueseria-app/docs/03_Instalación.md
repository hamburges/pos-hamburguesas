El documento 03_Instalación.md no necesita actualizaciones significativas, ya que los pasos de instalación siguen siendo básicamente los mismos. Sin embargo, podemos actualizar algunas referencias para incluir las nuevas dependencias y consideraciones para el módulo de ventas.
Aquí tienes la versión actualizada:
markdownCopy# Guía de Instalación y Configuración

Esta guía proporciona los pasos detallados para instalar, configurar y ejecutar el Sistema de Gestión para "JQ Q Berraquera".

## Requisitos Previos

Antes de comenzar con la instalación, asegúrese de tener instalados los siguientes requisitos:

- **Node.js**: versión 14.0.0 o superior
- **MongoDB**: versión 4.4.0 o superior
- **NPM**: versión 6.0.0 o superior (o Yarn como alternativa)
- **Git**: para clonar el repositorio (opcional)

Puede verificar las versiones instaladas mediante los siguientes comandos:

```bash
# Verificar versión de Node.js
node -v

# Verificar versión de NPM
npm -v

# Verificar versión de MongoDB
mongod --version
Pasos de Instalación
1. Clonar el Repositorio
Si está utilizando Git, puede clonar el repositorio directamente. Si recibió el código fuente por otros medios, puede omitir este paso.
bashCopy# Clonar el repositorio
git clone [URL del repositorio]

# Navegar al directorio del proyecto
cd hamburgueseria-app
2. Instalar Dependencias del Backend
bashCopy# Navegar al directorio del backend
cd backend

# Instalar dependencias
npm install
Esto instalará todas las dependencias necesarias para el backend, incluyendo:

express
mongoose
jsonwebtoken
bcrypt
cors
dotenv
y otras bibliotecas auxiliares

3. Instalar Dependencias del Frontend
bashCopy# Navegar al directorio del frontend
cd ../frontend

# Instalar dependencias
npm install
Esto instalará todas las dependencias necesarias para el frontend, incluyendo:

react
react-dom
react-router-dom
axios
bootstrap
formik
yup
jwt-decode
react-to-print (para impresión de facturas)
y otras bibliotecas auxiliares

Configuración del Entorno
1. Variables de Entorno para el Backend
Cree un archivo .env en la carpeta backend con las siguientes variables:
CopyPORT=3001
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/hamburgueseria
JWT_SECRET=tu_secreto_seguro
JWT_EXPIRES_IN=24h
CORS_ORIGIN=http://localhost:3000
Ajuste estas variables según sea necesario para su entorno específico:

PORT: Puerto donde se ejecutará el servidor backend
NODE_ENV: Entorno de ejecución (development, production, test)
MONGODB_URI: URI de conexión a MongoDB
JWT_SECRET: Clave secreta para firmar tokens JWT (cámbiela por una cadena segura)
JWT_EXPIRES_IN: Tiempo de expiración de los tokens JWT
CORS_ORIGIN: URL del frontend para configurar CORS

2. Configuración de MongoDB
Asegúrese de que MongoDB esté en ejecución en su sistema. Si está utilizando la configuración por defecto, no necesita realizar acciones adicionales.
Si tiene una configuración personalizada de MongoDB, modifique la variable MONGODB_URI en el archivo .env para reflejar su configuración.
bashCopy# Iniciar MongoDB (si no está configurado como servicio)
mongod --dbpath=/ruta/a/data
3. Creación de Usuario Administrador Inicial
El sistema incluye un script para crear un usuario administrador inicial. Ejecute el siguiente comando desde la carpeta backend:
bashCopy# Ejecutar el script de configuración
node scripts/setup-admin.js
Este script creará:

Usuario: admin
Contraseña: admin123
Rol: administrador
Sucursal: Sucursal principal (se crea automáticamente)

IMPORTANTE: Por seguridad, cambie esta contraseña después del primer inicio de sesión.
Ejecución del Sistema
1. Iniciar el Backend
bashCopy# Navegar al directorio del backend
cd "C:\Users\david.DESKTOP-JC0UQP0\OneDrive\Desktop\Nueva carpeta\hamburgueseria-app\backend"

# Iniciar el servidor en modo desarrollo
npm run dev

# O para iniciarlo en modo normal
node server.js
El servidor estará disponible en: http://localhost:3001/api
2. Iniciar el Frontend
bashCopy# Navegar al directorio del frontend
cd "C:\Users\david.DESKTOP-JC0UQP0\OneDrive\Desktop\Nueva carpeta\hamburgueseria-app\frontend"

# Iniciar el servidor de desarrollo de React
npm start
La aplicación web estará disponible en: http://localhost:3000
Verificación de la Instalación
Para verificar que el sistema se ha instalado correctamente:

Abra su navegador y acceda a http://localhost:3000
Debería ver la pantalla de inicio de sesión
Inicie sesión con las credenciales del administrador (admin / admin123)
Si puede acceder al dashboard de administrador, la instalación se ha completado con éxito

Prueba del Módulo de Ventas
Para verificar que el módulo de ventas está funcionando correctamente:

Inicie sesión con un usuario con rol de cajero
Navegue a la sección de punto de venta
Seleccione productos y añádalos al carrito
Personalice algún producto para verificar que funciona correctamente
Procese un pago simulado
Verifique que la venta aparece en el historial

Solución de Problemas Comunes
Problemas de Conexión a MongoDB
Si encuentra problemas al conectar con MongoDB, verifique:

Que MongoDB esté en ejecución
Que la URI de conexión en el archivo .env sea correcta
Que no haya restricciones de red que bloqueen la conexión

bashCopy# Verificar si MongoDB está en ejecución
mongod --version
Errores de CORS
Si encuentra errores de CORS al intentar conectar el frontend con el backend:

Verifique que la variable CORS_ORIGIN en el archivo .env coincida exactamente con la URL donde se ejecuta el frontend
Asegúrese de que no haya múltiples configuraciones de CORS en server.js
Verifique que se permitan todos los métodos HTTP necesarios, especialmente PATCH que es necesario para operaciones del módulo de ventas

Problemas con Dependencias
Si hay errores relacionados con dependencias faltantes:
bashCopy# Reinstalar dependencias del backend
cd backend
rm -rf node_modules
npm install

# Reinstalar dependencias del frontend
cd ../frontend
rm -rf node_modules
npm install
Problemas con el Módulo de Ventas
Si encuentra problemas específicos con el módulo de ventas:

Verifique que todas las rutas API están correctamente definidas en venta.routes.js
Asegúrese de que el modelo de datos Venta.js está correctamente implementado
Revise la consola del navegador para errores de JavaScript
Verifique los registros del servidor para errores en el backend

Configuración para Producción
Para un entorno de producción, realice los siguientes ajustes:

Variables de Entorno:
CopyNODE_ENV=production
MONGODB_URI=[URI de producción]
JWT_SECRET=[Clave segura diferente]
CORS_ORIGIN=[URL del frontend en producción]

Construcción del Frontend:
bashCopycd frontend
npm run build

Servir el Frontend:
Configurar un servidor web (como Nginx o Apache) para servir los archivos estáticos generados en la carpeta build.
Seguridad Adicional:

Utilizar HTTPS para todas las comunicaciones
Configurar límites de tasa (rate limiting)
Implementar logs de seguridad
Configurar respaldos automáticos de la base de datos



Actualización del Sistema
Para actualizar el sistema a una nueva versión:

Hacer una copia de seguridad de la base de datos
Obtener el nuevo código fuente
Instalar nuevas dependencias si las hay
Aplicar actualizaciones a la base de datos si son necesarias
Reiniciar los servicios

Configuración de Impresoras (Nuevo)
Para la funcionalidad de impresión de facturas del módulo de ventas:

Configuración de Impresora Térmica:

Asegúrese de que su impresora térmica esté correctamente instalada y configurada en su sistema operativo
La impresora debe estar compartida y accesible desde el navegador
Recomendamos usar impresoras compatibles con ESC/POS para mejor rendimiento


Configuración de react-to-print:

La biblioteca react-to-print utiliza la función de impresión nativa del navegador
Asegúrese de que su navegador tenga permisos para imprimir
Configure las opciones de impresión para adaptarse al tamaño del papel de su impresora térmica



Acceso al Sistema

URL del Backend: http://localhost:3001/api
URL del Frontend: http://localhost:3000
Credenciales de Administrador:

Usuario: admin
Contraseña: admin123




Última actualización: 12 de marzo de 2025