# Integración de Bibliotecas

Este documento detalla las bibliotecas utilizadas en el Sistema de Gestión para "JQ Q Berraquera", explicando su propósito y cómo se integran dentro del proyecto.

## Bibliotecas del Backend

El backend utiliza diversas bibliotecas de Node.js para implementar su funcionalidad.

### Express

**Propósito**: Framework web para Node.js que simplifica la creación de APIs REST y aplicaciones web.

**Uso en el proyecto**:
- Definición de rutas API para todos los recursos (usuarios, sucursales, etc.)
- Middleware para procesar peticiones HTTP
- Manejo de errores centralizado
- Configuración de CORS y parseo de datos

**Ejemplo de implementación**:
```javascript
// En server.js
const express = require('express');
const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rutas
app.use('/api/auth', require('./routes/auth.routes'));
app.use('/api/usuarios', require('./routes/usuario.routes'));
app.use('/api/sucursales', require('./routes/sucursal.routes'));
app.use('/api/ventas', require('./routes/venta.routes'));

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en puerto ${PORT}`);
});
Mongoose
Propósito: ODM (Object Document Mapper) para MongoDB que proporciona una solución basada en esquemas para modelar datos y realizar operaciones con la base de datos.
Uso en el proyecto:

Definición de esquemas para todos los modelos (Usuario, Sucursal, etc.)
Validación de datos basada en esquemas
Consultas a la base de datos con operaciones CRUD
Relaciones entre colecciones mediante referencias
Manejo de índices para optimización

Ejemplo de implementación:
javascriptCopy// En models/Usuario.js
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const usuarioSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: true,
    trim: true
  },
  usuario: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  contrasena: {
    type: String,
    required: true
  },
  rol: {
    type: String,
    enum: ['administrador', 'cajero', 'cocinero'],
    required: true
  },
  sucursal: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Sucursal',
    required: true
  },
  estado: {
    type: String,
    enum: ['activo', 'inactivo'],
    default: 'activo'
  }
}, { timestamps: { createdAt: 'fecha_creacion', updatedAt: 'fecha_actualizacion' } });

// Método para encriptar contraseña
usuarioSchema.pre('save', async function(next) {
  if (!this.isModified('contrasena')) return next();
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.contrasena = await bcrypt.hash(this.contrasena, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Método para verificar contraseña
usuarioSchema.methods.verificarContrasena = async function(contrasena) {
  return await bcrypt.compare(contrasena, this.contrasena);
};

module.exports = mongoose.model('Usuario', usuarioSchema);
JSON Web Token (jsonwebtoken)
Propósito: Implementación de tokens JWT para autenticación y autorización segura.
Uso en el proyecto:

Generación de tokens de autenticación
Verificación de tokens en middleware de autenticación
Almacenamiento de información del usuario en el token

Ejemplo de implementación:
javascriptCopy// En utils/auth.utils.js
const jwt = require('jsonwebtoken');

// Generar token JWT
const generarToken = (usuario) => {
  return jwt.sign(
    {
      id: usuario._id,
      usuario: usuario.usuario,
      rol: usuario.rol,
      sucursalId: usuario.sucursal
    },
    process.env.JWT_SECRET || 'tu_secreto_seguro',
    { expiresIn: process.env.JWT_EXPIRES_IN || '24h' }
  );
};

// Verificar token JWT
const verificarToken = (token) => {
  try {
    return jwt.verify(token, process.env.JWT_SECRET || 'tu_secreto_seguro');
  } catch (error) {
    throw error;
  }
};

module.exports = { generarToken, verificarToken };
bcrypt
Propósito: Biblioteca para hash seguro de contraseñas.
Uso en el proyecto:

Encriptación de contraseñas antes de guardarlas en la base de datos
Verificación segura de contraseñas durante el login
Implementación de salt para mayor seguridad

Ejemplo de implementación:
javascriptCopy// En el modelo de Usuario (pre-save hook)
usuarioSchema.pre('save', async function(next) {
  if (!this.isModified('contrasena')) return next();
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.contrasena = await bcrypt.hash(this.contrasena, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Verificación en el controlador de autenticación
const loginUsuario = async (req, res) => {
  try {
    const { usuario, contrasena } = req.body;
    
    const usuarioEncontrado = await Usuario.findOne({ usuario });
    
    if (!usuarioEncontrado) {
      return res.status(401).json({
        success: false,
        message: 'Credenciales inválidas'
      });
    }
    
    const contrasenaValida = await usuarioEncontrado.verificarContrasena(contrasena);
    
    if (!contrasenaValida) {
      return res.status(401).json({
        success: false,
        message: 'Credenciales inválidas'
      });
    }
    
    // Continuar con el proceso de login...
  } catch (error) {
    // Manejo de errores...
  }
};
cors
Propósito: Middleware para habilitar CORS (Cross-Origin Resource Sharing) en el servidor Express.
Uso en el proyecto:

Permitir peticiones desde el frontend (en localhost:3000)
Configuración de opciones de CORS para mejorar la seguridad
Manejo de cookies entre dominios (credentials: true)

Ejemplo de implementación:
javascriptCopy// En server.js
const cors = require('cors');

// Configuración de CORS
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:3000',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS']
}));
dotenv
Propósito: Carga variables de entorno desde un archivo .env a process.env.
Uso en el proyecto:

Configuración segura de parámetros sensibles
Separación de configuración entre entornos (desarrollo, producción)
Almacenamiento de credenciales de base de datos y claves secretas

Ejemplo de implementación:
javascriptCopy// En server.js
require('dotenv').config();

const PORT = process.env.PORT || 3001;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/hamburgueseria';
const JWT_SECRET = process.env.JWT_SECRET || 'tu_secreto_seguro';

// Uso en la conexión a MongoDB
mongoose.connect(MONGODB_URI, { ... })
Bibliotecas del Frontend
React
Propósito: Biblioteca JavaScript para construir interfaces de usuario basadas en componentes.
Uso en el proyecto:

Estructura de componentes reutilizables
Gestión del estado de la aplicación
Renderizado eficiente mediante virtual DOM
Implementación de hooks para lógica de componentes

Ejemplo de implementación:
jsxCopy// Componente funcional con hooks
import React, { useState, useEffect } from 'react';
import sucursalService from '../services/sucursalService';

const SucursalesList = () => {
  const [sucursales, setSucursales] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const cargarSucursales = async () => {
      try {
        setLoading(true);
        const respuesta = await sucursalService.obtenerTodas();
        setSucursales(respuesta.data);
        setError(null);
      } catch (error) {
        setError('Error al cargar sucursales');
        console.error(error);
      } finally {
        setLoading(false);
      }
    };

    cargarSucursales();
  }, []);

  // Renderizado condicional
  if (loading) return <div>Cargando sucursales...</div>;
  if (error) return <div className="alert alert-danger">{error}</div>;

  return (
    <div className="sucursales-list">
      <h2>Listado de Sucursales</h2>
      <table className="table">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Dirección</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {sucursales.map(sucursal => (
            <tr key={sucursal._id}>
              <td>{sucursal.nombre}</td>
              <td>{sucursal.direccion}</td>
              <td>{sucursal.estado}</td>
              <td>
                {/* Botones de acción */}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default SucursalesList;
React Router Dom
Propósito: Biblioteca de enrutamiento para aplicaciones React.
Uso en el proyecto:

Navegación entre páginas sin recarga completa
Rutas protegidas según rol de usuario
Rutas anidadas para diferentes secciones
Redirecciones condicionales

Ejemplo de implementación:
jsxCopy// En App.js
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import PrivateRoute from './components/PrivateRoute';
import Login from './pages/auth/Login';
import Dashboard from './pages/admin/Dashboard';
import SucursalesList from './pages/admin/SucursalesList';
import PuntoVenta from './pages/cajero/ventas/PuntoVenta';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Rutas públicas */}
        <Route path="/login" element={<Login />} />
        
        {/* Rutas protegidas para administradores */}
        <Route element={<PrivateRoute allowedRoles={['administrador']} />}>
          <Route path="/admin/dashboard" element={<Dashboard />} />
          <Route path="/admin/sucursales" element={<SucursalesList />} />
        </Route>
        
        {/* Rutas protegidas para cajeros */}
        <Route element={<PrivateRoute allowedRoles={['administrador', 'cajero']} />}>
          <Route path="/cajero/ventas" element={<PuntoVenta />} />
          <Route path="/cajero/ventas/historial" element={<HistorialVentas />} />
          <Route path="/cajero/ventas/detalle/:id" element={<DetalleVenta />} />
        </Route>
        
        {/* Redirección por defecto */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
Axios
Propósito: Cliente HTTP basado en promesas para realizar peticiones a la API.
Uso en el proyecto:

Comunicación con el backend mediante peticiones HTTP
Configuración centralizada con interceptores
Manejo de tokens de autenticación
Gestión de errores en respuestas

Ejemplo de implementación:
javascriptCopy// En services/api.js
import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:3001/api',
  headers: {
    'Content-Type': 'application/json'
  }
});

// Interceptor para agregar token a todas las peticiones
api.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

// Interceptor para manejar respuestas y errores
api.interceptors.response.use(
  response => response,
  error => {
    // Manejo de errores de autenticación
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;
Bootstrap y React-Bootstrap
Propósito: Framework CSS y componentes React para Bootstrap, facilitando el diseño responsive.
Uso en el proyecto:

Diseño responsive de la interfaz
Componentes prediseñados (modal, tablas, formularios)
Sistema de grid para layout
Estilización consistente de la aplicación

Ejemplo de implementación:
jsxCopy// Componente con React-Bootstrap
import React, { useState } from 'react';
import { Modal, Button, Form, Alert } from 'react-bootstrap';

const AutorizacionModal = ({ show, onClose, onConfirm }) => {
  const [codigo, setCodigo] = useState('');
  const [error, setError] = useState('');
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (codigo === 'ADMIN123') {
      onConfirm();
    } else {
      setError('Código de autorización incorrecto');
    }
  };
  
  return (
    <Modal show={show} onHide={onClose}>
      <Modal.Header closeButton>
        <Modal.Title>Autorización Requerida</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p>Esta acción requiere autorización especial.</p>
        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3">
            <Form.Label>Código de Autorización</Form.Label>
            <Form.Control
              type="password"
              value={codigo}
              onChange={(e) => setCodigo(e.target.value)}
              autoFocus
              required
            />
          </Form.Group>
          {error && <Alert variant="danger">{error}</Alert>}
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>
          Cancelar
        </Button>
        <Button variant="primary" onClick={handleSubmit}>
          Verificar
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default AutorizacionModal;
Formik y Yup
Propósito: Formik maneja el estado del formulario y validación, mientras Yup proporciona un sistema de validación de esquemas.
Uso en el proyecto:

Gestión del estado de formularios complejos
Validación de datos con esquemas
Manejo de errores de validación
Visualización de mensajes de error

Ejemplo de implementación:
jsxCopy// Formulario con Formik y Yup
import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';

const UsuarioForm = ({ initialValues, onSubmit }) => {
  // Esquema de validación con Yup
  const validationSchema = Yup.object({
    nombre: Yup.string()
      .required('El nombre es obligatorio')
      .min(3, 'El nombre debe tener al menos 3 caracteres')
      .max(50, 'El nombre no debe exceder 50 caracteres'),
    usuario: Yup.string()
      .required('El usuario es obligatorio')
      .min(3, 'El usuario debe tener al menos 3 caracteres')
      .max(30, 'El usuario no debe exceder 30 caracteres')
      .matches(
        /^[a-zA-Z0-9_]+$/,
        'El usuario solo puede contener letras, números y guiones bajos'
      ),
    contrasena: Yup.string()
      .when('_id', {
        is: val => !val,
        then: Yup.string()
          .required('La contraseña es obligatoria')
          .min(6, 'La contraseña debe tener al menos 6 caracteres')
      }),
    rol: Yup.string()
      .required('El rol es obligatorio')
      .oneOf(['administrador', 'cajero', 'cocinero'], 'Rol no válido'),
    sucursal: Yup.string()
      .required('La sucursal es obligatoria')
  });

  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
    >
      {({ isSubmitting, errors, touched }) => (
        <Form>
          <div className="mb-3">
            <label htmlFor="nombre" className="form-label">Nombre Completo</label>
            <Field
              type="text"
              id="nombre"
              name="nombre"
              className={`form-control ${errors.nombre && touched.nombre ? 'is-invalid' : ''}`}
            />
            <ErrorMessage name="nombre" component="div" className="invalid-feedback" />
          </div>
          
          <div className="mb-3">
            <label htmlFor="usuario" className="form-label">Usuario</label>
            <Field
              type="text"
              id="usuario"
              name="usuario"
              className={`form-control ${errors.usuario && touched.usuario ? 'is-invalid' : ''}`}
            />
            <ErrorMessage name="usuario" component="div" className="invalid-feedback" />
          </div>
          
          {/* Otros campos... */}
          
          <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
            {isSubmitting ? 'Guardando...' : 'Guardar'}
          </button>
        </Form>
      )}
    </Formik>
  );
};

export default UsuarioForm;
jwt-decode
Propósito: Biblioteca para decodificar tokens JWT en el frontend.
Uso en el proyecto:

Extracción de información del usuario desde el token
Verificación de expiración del token
Acceso a propiedades específicas del token

Ejemplo de implementación:
javascriptCopy// En context/AuthContext.js
import jwtDecode from 'jwt-decode';

const checkLoggedIn = async () => {
  const token = localStorage.getItem('token');
  
  if (token) {
    try {
      // Decodificar token para verificar validez
      const decodedToken = jwtDecode(token);
      
      // Verificar si el token ha expirado
      if (decodedToken.exp * 1000 < Date.now()) {
        // Token expirado
        localStorage.removeItem('token');
        setUser(null);
      } else {
        // Token válido, extraer información del usuario
        setUser({
          id: decodedToken.id,
          usuario: decodedToken.usuario,
          rol: decodedToken.rol,
          sucursalId: decodedToken.sucursalId
        });
        
        // Configurar Axios para usar el token
        api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      }
    } catch (error) {
      console.error('Error decodificando token:', error);
      localStorage.removeItem('token');
      setUser(null);
    }
  }
  
  setLoading(false);
};
react-to-print
Propósito: Biblioteca para habilitar la funcionalidad de impresión en componentes React.
Uso en el proyecto:

Impresión de facturas y tickets desde el navegador
Configuración de estilos específicos para impresión
Visualización previa del contenido a imprimir

Ejemplo de implementación:
jsxCopyimport React, { useRef } from 'react';
import { useReactToPrint } from 'react-to-print';

const FacturaVenta = ({ venta }) => {
  const componentRef = useRef();
  
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: `Factura-${venta._id}`,
    // Estilos específicos para impresión
    pageStyle: `
      @page {
        size: 80mm auto;
        margin: 0mm;
      }
      @media print {
        body {
          width: 80mm;
          margin: 0;
          padding: 0;
          font-family: monospace;
        }
      }
    `
  });

  return (
    <div>
      {/* Contenido que se imprimirá */}
      <div className="d-none">
        <div ref={componentRef}>
          <div className="factura-container">
            <div className="factura-header">
              <h3>JQ Q Berraquera</h3>
              <p>NIT: 123456789-0</p>
              <p>Sucursal: {venta.sucursal.nombre}</p>
              <p>Fecha: {new Date(venta.fecha).toLocaleString()}</p>
            </div>
            
            <div className="factura-detalle">
              <table>
                <thead>
                  <tr>
                    <th>Producto</th>
                    <th>Cant.</th>
                    <th>Precio</th>
                  </tr>
                </thead>
                <tbody>
                  {venta.productos.map((producto, index) => (
                    <tr key={index}>
                      <td>{producto.nombre_producto}</td>
                      <td>{producto.cantidad}</td>
                      <td>${producto.subtotal.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <div className="factura-total">
              <p>Total: ${venta.total.toFixed(2)}</p>
              <p>Método de pago: {venta.metodo_pago}</p>
            </div>
            
            <div className="factura-footer">
              <p>¡Gracias por su compra!</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Botón de impresión */}
      <button onClick={handlePrint} className="btn btn-primary">
        <i className="bi bi-printer"></i> Imprimir Factura
      </button>
    </div>
  );
};

export default FacturaVenta;
Integración entre Frontend y Backend
La integración entre las bibliotecas de frontend y backend se realiza principalmente a través de:

Comunicación API REST:

El frontend utiliza Axios para realizar peticiones HTTP al backend
El backend responde con datos en formato JSON
Estructura estandarizada de respuestas: { success, message, data }


Autenticación con JWT:

El backend genera tokens JWT con jsonwebtoken
El frontend almacena el token en localStorage
Las peticiones incluyen el token en el header Authorization
jwt-decode extrae la información del usuario en el frontend


Validación de datos:

Formik y Yup validan datos en el frontend antes de enviarlos
Mongoose valida datos en el backend antes de guardarlos
Estructura de validación similar en ambos lados


Manejo de errores:

Interceptores de Axios gestionan errores en el frontend
Middleware de Express maneja errores en el backend
Estructura uniforme de mensajes de error



Configuración de Desarrollo
Scripts disponibles
En el directorio del backend:
jsonCopy"scripts": {
  "start": "node server.js",
  "dev": "nodemon server.js",
  "seed": "node scripts/setup-admin.js"
}
En el directorio del frontend:
jsonCopy"scripts": {
  "start": "react-scripts start",
  "build": "react-scripts build",
  "test": "react-scripts test",
  "eject": "react-scripts eject"
}
Dependencias del Backend
jsonCopy"dependencies": {
  "bcrypt": "^5.1.0",
  "cors": "^2.8.5",
  "dotenv": "^16.0.3",
  "express": "^4.18.2",
  "jsonwebtoken": "^9.0.0",
  "mongoose": "^7.0.3"
},
"devDependencies": {
  "nodemon": "^2.0.22"
}
Dependencias del Frontend
jsonCopy"dependencies": {
  "@testing-library/jest-dom": "^5.16.5",
  "@testing-library/react": "^14.0.0",
  "@testing-library/user-event": "^14.4.3",
  "axios": "^1.3.4",
  "bootstrap": "^5.2.3",
  "formik": "^2.2.9",
  "jwt-decode": "^3.1.2",
  "react": "^18.2.0",
  "react-bootstrap": "^2.7.2",
  "react-dom": "^18.2.0",
  "react-router-dom": "^6.10.0",
  "react-scripts": "5.0.1",
  "react-to-print": "^2.14.12",
  "web-vitals": "^3.3.1",
  "yup": "^1.0.2"
}
Nuevas Bibliotecas para el Módulo de Ventas
react-to-print
Propósito: Permite la impresión de componentes React con un formato personalizado, ideal para facturas y tickets.
Instalación:
Copynpm install react-to-print
Uso en el proyecto:

Impresión de facturas de venta
Configuración de estilos específicos para impresoras térmicas
Previsualización del contenido de impresión

Integración:
La biblioteca se integra mediante el hook useReactToPrint y una referencia a un componente React para determinar qué contenido imprimir. Los estilos de impresión se configuran mediante una cadena CSS personalizada.
react-window
Propósito: Proporciona componentes para renderizar eficientemente grandes listas y tablas mediante "virtualización".
Instalación:
Copynpm install react-window
Uso en el proyecto:

Renderizado eficiente del historial de ventas
Mejora del rendimiento con grandes volúmenes de datos
Visualización de listas sin afectar la experiencia del usuario

Integración:
Se utiliza principalmente en el componente HistorialVentas.js para mostrar grandes cantidades de registros sin ralentizar la interfaz. Los componentes FixedSizeList o VariableSizeList encapsulan el renderizado de filas.
date-fns
Propósito: Biblioteca utilitaria para manipulación y formateo de fechas.
Instalación:
Copynpm install date-fns
Uso en el proyecto:

Formateo consistente de fechas en la interfaz
Cálculos de rangos de fechas para filtros
Manipulación de zonas horarias

Integración:
Se utiliza en utilidades de formateo y en componentes que muestran o manipulan fechas, como el historial de ventas, detalles de venta y facturas.
Consideraciones para Futuras Integraciones
Para integrar nuevas bibliotecas en el proyecto, considere:

Compatibilidad: Asegúrese de que las nuevas bibliotecas sean compatibles con las versiones existentes.
Propósito claro: Cada biblioteca debe tener un propósito específico, evitando duplicidades.
Tamaño y rendimiento: Evalúe el impacto en el tamaño del bundle y el rendimiento.
Mantenimiento activo: Prefiera bibliotecas con mantenimiento activo y buena documentación.
Configuración centralizada: Mantenga la configuración de cada biblioteca centralizada para facilitar cambios.
Seguridad: Compruebe si hay vulnerabilidades conocidas antes de integrar nuevas bibliotecas.

Acoplamiento y Cohesión
Las bibliotecas se han integrado siguiendo los principios de bajo acoplamiento y alta cohesión:

Servicios independientes: Los servicios de API están separados por entidad
Componentes reutilizables: Los componentes de UI se han diseñado para ser reutilizables
Centralización de configuración: Configuraciones como Axios y JWT están centralizadas
Separación de responsabilidades: Cada biblioteca tiene un propósito específico

Estos principios facilitan el mantenimiento y la evolución del sistema a medida que crece en funcionalidades.

Última actualización: 12 de marzo de 2025