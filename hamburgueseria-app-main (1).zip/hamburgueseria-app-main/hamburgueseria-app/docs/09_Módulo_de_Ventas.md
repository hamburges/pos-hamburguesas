ódulo de Ventas
Descripción General
El módulo de ventas es una parte fundamental del Sistema de Gestión para "JQ Q Berraquera", que permite a los cajeros realizar el proceso completo de ventas, desde la selección de productos, personalización, hasta la emisión de facturas e historial de ventas. Este módulo integra funcionalidades esenciales para la operación diaria del negocio y proporciona una interfaz intuitiva optimizada para entornos de punto de venta. Ahora cuenta con integración completa al sistema de ciclos de caja para mejorar el control financiero y al sistema de gestión de pagos con reconciliación financiera para garantizar integridad en las transacciones.

Funcionalidades Implementadas
Punto de Venta

Interfaz optimizada para cajeros
Catálogo visual de productos organizados por categorías
Carrito de compras en tiempo real
Sistema de personalización de productos (agregar/quitar ingredientes)
Proceso de finalización de venta con selección de método de pago
Interfaz intuitiva y eficiente para operaciones rápidas
Integración con ciclos de caja: validación de ciclo activo antes de permitir ventas
Visualización del ciclo de caja activo con información relevante

Historial de Ventas

Listado completo de ventas realizadas
Filtrado por fecha, método de pago y ciclo de caja
Visualización de estado de ventas (completada/anulada)
Acceso directo a detalles de cada venta
Indicadores visuales del estado de la venta
Información de ciclo de caja asociado a cada venta

Detalles de Venta

Visualización detallada de cada venta
Información completa de productos, cantidades y precios
Visualización de personalizaciones aplicadas a cada producto
Desglose de totales, impuestos y descuentos
Opción para anular ventas (con permisos adecuados)
Información del ciclo de caja asociado a la venta

Facturación

Generación de facturas en formato de ticket
Visualización previa de la factura
Impresión directa desde la aplicación
Diseño optimizado para impresoras térmicas
Inclusión de información fiscal y de la empresa
Referencia al ciclo de caja correspondiente

Integración con Ciclos de Caja

Verificación automática de ciclo activo antes de permitir ventas
Actualización automática del monto de ventas en el ciclo al realizar operaciones
Filtrado de ventas por ciclo específico en el historial
Asociación automática de cada venta a un ciclo de caja
Actualización de montos en ciclo cuando se anulan ventas

Estructura de Archivos
El módulo está compuesto por los siguientes archivos principales:
Frontend

/pages/cajero/PuntoVenta.js: Interfaz principal para el punto de venta (actualizado con verificación de ciclo activo)
/pages/cajero/HistorialVentas.js: Visualización y filtrado del historial (actualizado con filtro por ciclo)
/pages/cajero/DetalleVenta.js: Visualización detallada de una venta específica (muestra ciclo asociado)
/pages/cajero/FacturaVenta.js: Componente para visualizar e imprimir facturas
/components/cajero/Carrito.js: Componente para gestionar productos seleccionados
/components/cajero/PersonalizarProducto.js: Modal para personalizar productos
/components/cajero/ResumenVenta.js: Visualización del resumen antes de finalizar
/components/cajero/ProcesarPago.js: Procesa el pago y finaliza la venta (incluye ID de ciclo)
/services/ventaService.js: Comunicación con la API para operaciones de ventas (actualizado para integración con ciclos)
/utils/formatters.js: Utilidades para formateo de datos (fechas, moneda, etc.)

Backend

/models/Venta.js: Modelo de datos para ventas (actualizado con campo ciclo_caja)
/models/DetalleVenta.js: Modelo para detalles de cada venta
/controllers/venta.controller.js: Controlador para operaciones CRUD de ventas (actualizado para verificar ciclo)
/routes/venta.routes.js: Definición de rutas API para ventas

API Endpoints
MétodoRutaDescripciónRoles PermitidosGET/api/ventasObtener todas las ventas (con filtros)Admin, CajeroGET/api/ventas/:idObtener una venta específica con detallesAdmin, CajeroPOST/api/ventasCrear una nueva ventaCajeroPATCH/api/ventas/:id/anularAnular una venta existenteAdmin, CajeroGET/api/ventas/reporte/diarioObtener reporte diarioAdminGET/api/ventas/reporte/fechasObtener reporte por rango de fechasAdminGET/api/ventas/ciclo/:cicloCajaIdObtener ventas por ciclo de cajaAdmin, Cajero

Modelo de Datos
Venta
javascriptCopiarconst ventaSchema = new Schema({
  fecha: {
    type: Date,
    required: true,
    default: Date.now
  },
  cajero: {
    type: Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true
  },
  sucursal: {
    type: Schema.Types.ObjectId,
    ref: 'Sucursal',
    required: true
  },
  ciclo_caja: {
    type: Schema.Types.ObjectId,
    ref: 'CicloCaja'
  },
  estado: {
    type: String,
    enum: ['completada', 'anulada'],
    default: 'completada'
  },
  metodo_pago: {
    type: String,
    enum: ['efectivo', 'nequi', 'daviplata', 'combinado', 'transferencia'],
    required: true
  },
  total_sin_impuestos: {
    type: Number,
    required: true,
    min: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  total_impuestos: {
    type: Number,
    required: true,
    min: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  total: {
    type: Number,
    required: true,
    min: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  para_llevar: {
    type: Boolean,
    default: false
  },
  notas: {
    type: String,
    trim: true
  }
}, {
  timestamps: {
    createdAt: 'fecha_creacion',
    updatedAt: 'fecha_actualizacion'
  }
});

// Índices para optimizar consultas
ventaSchema.index({ ciclo_caja: 1 });
ventaSchema.index({ sucursal: 1 });
ventaSchema.index({ fecha: 1 });
ventaSchema.index({ metodo_pago: 1 });

DetalleVenta
javascriptCopiarconst detalleVentaSchema = new Schema({
  venta: {
    type: Schema.Types.ObjectId,
    ref: 'Venta',
    required: true
  },
  producto: {
    type: Schema.Types.ObjectId,
    ref: 'Producto',
    required: true
  },
  nombre_producto: {
    type: String,
    required: true
  },
  precio_unitario: {
    type: Number,
    required: true,
    min: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  cantidad: {
    type: Number,
    required: true,
    min: 1,
    default: 1
  },
  subtotal: {
    type: Number,
    required: true,
    min: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  personalizaciones: [{
    ingrediente: {
      type: Schema.Types.ObjectId,
      ref: 'Ingrediente'
    },
    nombre_ingrediente: {
      type: String
    },
    accion: {
      type: String,
      enum: ['agregar', 'quitar'],
      required: true
    },
    cantidad: {
      type: Number,
      min: 1,
      default: 1
    },
    precio_adicional: {
      type: Number,
      default: 0,
      get: v => parseFloat(v.toFixed(2)),
      set: v => parseFloat(parseFloat(v).toFixed(2))
    }
  }]
}, {
  timestamps: {
    createdAt: 'fecha_creacion',
    updatedAt: 'fecha_actualizacion'
  }
});

Casos de Uso Principales
Realización de una Venta

El cajero verifica que exista un ciclo de caja activo (si no existe, debe abrir uno)
El cajero selecciona la categoría de productos
Selecciona los productos deseados y los agrega al carrito
Personaliza cada producto si es necesario (agregar/quitar ingredientes)
Revisa el resumen de la venta
Selecciona el método de pago
Confirma la venta
El sistema actualiza automáticamente el monto del ciclo de caja activo
Imprime la factura

Visualización del Historial de Ventas

El cajero o administrador navega a la sección de historial
Aplica filtros por fecha, método de pago o ciclo de caja si desea
Visualiza las ventas realizadas, incluyendo a qué ciclo pertenece cada una
Selecciona una venta para ver sus detalles

Anulación de una Venta

El cajero o administrador busca la venta en el historial
Accede a la vista de detalles
Selecciona la opción de anular venta
Confirma la anulación proporcionando un motivo
El sistema actualiza el estado de la venta
El sistema actualiza el monto del ciclo de caja correspondiente, descontando el valor de la venta anulada

Impresión de Factura

El usuario accede a los detalles de una venta
Selecciona la opción de imprimir factura
Visualiza una vista previa del formato del ticket (incluye información del ciclo)
Selecciona las opciones de impresión
Imprime el ticket en la impresora configurada

Integración con Otros Módulos
Módulo de Ciclos de Caja

El punto de venta verifica la existencia de un ciclo activo antes de permitir ventas
Cada venta se asocia automáticamente al ciclo de caja activo
Las anulaciones actualizan el monto del ciclo correspondiente
El historial de ventas permite filtrar por ciclo específico
La información del ciclo es visible en los detalles de venta y facturas

Módulo de Productos

El punto de venta utiliza el catálogo completo de productos
La personalización de productos utiliza las opciones definidas para cada producto
Los precios base y adicionales se calculan según la configuración de productos e ingredientes

Módulo de Usuarios

La autenticación determina quién puede realizar ventas (cajeros)
Los permisos de usuario determinan el acceso a funciones de anulación y reportes
Cada venta registra el cajero que la realizó para auditoría

Módulo de Categorías

Las categorías se utilizan para organizar los productos en el punto de venta
El filtrado por categorías facilita la búsqueda de productos

Consideraciones Técnicas
Rendimiento

Carga eficiente de productos por categoría
Manejo optimizado del estado del carrito de compras
Cálculo rápido de precios y totales
Generación eficiente de facturas
Índices optimizados para consultas de ventas por ciclo de caja

Seguridad

Validación completa de datos tanto en frontend como backend
Restricción de acciones por rol de usuario
Registro de auditoría para todas las transacciones
Protección de operaciones sensibles
Verificación de ciclo de caja activo antes de permitir ventas

Usabilidad

Interfaz optimizada para pantallas táctiles
Flujo de trabajo intuitivo para reducir tiempo de operación
Feedback inmediato al usuario tras operaciones
Accesos rápidos a funciones frecuentes
Información clara sobre el ciclo de caja activo

Problemas Encontrados y Soluciones
1. Error de Cálculo de Precios en Personalizaciones
Problema: Se identificó un error en el cálculo de precios de personalizaciones que causaba valores incorrectos en el historial de ventas.
Causa: En el backend se estaba multiplicando nuevamente el precio de las personalizaciones que ya venían calculadas desde el frontend.
Solución:

Modificación del archivo venta.controller.js para evitar el doble cálculo del precio
Uso directo del precio calculado en el frontend sin multiplicarlo nuevamente en el backend
Implementación de pruebas para verificar la correcta aplicación de precios

Código modificado:
javascriptCopiar// Versión anterior (con error)
const calcularTotalPersonalizaciones = (personalizaciones) => {
  return personalizaciones.reduce((total, p) => {
    return total + (p.precio_adicional * p.cantidad);
  }, 0);
};

// Versión corregida
const calcularTotalPersonalizaciones = (personalizaciones) => {
  return personalizaciones.reduce((total, p) => {
    return total + p.precio_adicional;
  }, 0);
};

2. Mejora en el Manejo de Datos Numéricos
Problema: Inconsistencias en los valores numéricos entre frontend y backend, especialmente en precios y totales.
Solución:

Implementación de normalización de valores numéricos en todos los endpoints
Uso de getters y setters en los esquemas de Mongoose para formatear valores
Creación de utilidades de formato en el frontend

javascriptCopiar// En los esquemas de Mongoose
total: {
  type: Number,
  required: true,
  min: 0,
  get: v => parseFloat(v.toFixed(2)),
  set: v => parseFloat(parseFloat(v).toFixed(2))
}

// En formatters.js
export const formatearMoneda = (valor) => {
  return new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    minimumFractionDigits: 0
  }).format(valor);
};

3. Error en el controlador de ventas con ObjectId
Problema: En la función obtenerVentasDelDia del controlador venta.controller.js, se encontró un error crítico: se utilizaba el constructor mongoose.Types.ObjectId() sin la palabra clave new.
Causa: Este error causaba fallos al acceder al reporte de ventas del día y al historial de ventas, con un error 500 y el mensaje: "Class constructor ObjectId cannot be invoked without 'new'".
Solución:
javascriptCopiar// Código original con error
if (sucursal) {
  filtro.sucursal = mongoose.Types.ObjectId(sucursal);
}
if (ciclo_caja) {
  filtro.ciclo_caja = mongoose.Types.ObjectId(ciclo_caja);
}

// Código corregido
if (sucursal) {
  filtro.sucursal = new mongoose.Types.ObjectId(sucursal);
}
if (ciclo_caja) {
  filtro.ciclo_caja = new mongoose.Types.ObjectId(ciclo_caja);
}

4. Error en esquema del modelo Venta
Problema: El controlador de ventas intentaba hacer un populate del campo ciclo_caja, pero este campo no estaba definido en el esquema del modelo Venta.
Causa: Esto generaba un error: "Cannot populate path ciclo_caja because it is not in your schema".
Solución:

Se actualizó el esquema del modelo Venta.js para incluir el campo ciclo_caja
Se añadió un índice para este nuevo campo para optimizar consultas

Funcionalidades Implementadas (Anteriormente Pendientes)
Sistema de Ciclos de Caja

✅ Verificación del ciclo activo antes de permitir ventas
✅ Asociación automática de ventas al ciclo activo
✅ Actualización automática de montos en el ciclo al realizar o anular ventas
✅ Visualización y filtrado de ventas por ciclo de caja

Gestión de Pagos y Vueltas

✅ Sistema completo de gestión de pagos con reconciliación financiera
✅ Cálculo automático de vueltas según el monto entregado
✅ Registro detallado del método de pago utilizado
✅ Manejo de pagos combinados entre diferentes métodos
✅ Garantía de integridad financiera mediante reconciliación exacta

Funcionalidades Pendientes
1. Integración con Inventario
Se integrará el sistema de ventas con el inventario:

Descuento automático de ingredientes al realizar una venta
Alertas cuando un ingrediente alcanza niveles críticos
Actualización en tiempo real del stock disponible
Reportes de consumo de ingredientes

2. Mejoras en Sistema de Ventas Offline

Implementación de capacidad completa para trabajar sin conexión
Sincronización automática al recuperar la conexión
Cola de ventas pendientes de sincronización
Indicadores visuales del estado de sincronización

Flujo de Trabajo - Proceso de Venta
El siguiente diagrama muestra el flujo de trabajo completo para una venta:
┌─────────────────┐     ┌────────────────┐     ┌─────────────────┐
│                 │     │                │     │                 │
│  Verificación   │────►│  Selección de  │────►│ Personalización │
│  ciclo activo   │     │  Productos     │     │ de Productos    │
│                 │     │                │     │                 │
└─────────────────┘     └────────────────┘     └─────────────────┘
                                                      │
                                                      ▼
┌─────────────────┐     ┌────────────────┐     ┌─────────────────┐
│                 │     │                │     │                 │
│  Revisión del   │────►│  Proceso de    │────►│  Confirmación   │
│  Carrito        │     │  Pago          │     │  de Venta       │
│                 │     │                │     │                 │
└─────────────────┘     └────────────────┘     └─────────────────┘
                                                      │
                                                      ▼
                                              ┌─────────────────┐
                                              │                 │
                                              │  Impresión de   │
                                              │  Factura        │
                                              │                 │
                                              └─────────────────┘

Mejoras Planificadas

Experiencia de Usuario: Mejorar la interfaz del punto de venta para mayor eficiencia
Funcionalidad Offline: Implementar capacidad de trabajar sin conexión con sincronización posterior
Sistema de Combos: Crear una interfaz para la venta de combos predefinidos
Promociones y Descuentos: Implementar un sistema de aplicación de descuentos y promociones
Estadísticas en Tiempo Real: Visualización de estadísticas de ventas del día actual
Notificación a Cocina: Sistema de notificación automática a cocina cuando se realiza una venta
Integración con Sistemas Fiscales: Preparación para integración con sistemas de facturación electrónica
Dashboard de Ventas: Panel con métricas e indicadores de rendimiento por ciclo de caja

## Integración con Sistema de Gestión de Pagos

El Módulo de Ventas ha sido integrado con el nuevo Sistema de Gestión de Pagos con Reconciliación Financiera, proporcionando las siguientes mejoras:

- **Reconciliación Financiera Automática**: Garantiza integridad en transacciones con cambio
- **Máquina de Estados para Pagos**: Gestión robusta del ciclo de vida de transacciones
- **Validación Desacoplada por Método**: Reglas específicas para cada método de pago
- **Procesamiento Polimórfico**: Estrategias específicas por tipo de pago
- **Comunicación por Eventos**: Integración no intrusiva mediante EventBus

### Funcionamiento del Sistema Integrado

El flujo de trabajo para procesamiento de pagos ahora incluye estas capacidades avanzadas:

1. Al confirmar una venta, el sistema identifica automáticamente si el pago generará cambio
2. En caso de cambio, se solicita confirmación explícita antes de proceder
3. La reconciliación financiera garantiza integridad en todos los montos y balance exacto
4. El procesamiento específico por método de pago aplica reglas de negocio precisas
5. Todos los valores originales y reconciliados quedan registrados para auditoría

### Métodos de Pago Soportados con Validación Específica

| Método | Características | Validación | Reconciliación |
|--------|-----------------|------------|----------------|
| Efectivo | Genera cambio | Monto > 0 | Ajuste automático |
| Nequi | Requiere referencia | Referencia válida | No aplicable |
| Daviplata | Requiere referencia | Referencia válida | No aplicable |
| Transferencia | Requiere referencia | Referencia válida | No aplicable |
| Combinado | Múltiples métodos | Según cada método | Parcial (solo efectivo) |

El sistema ahora proporciona:
- Mayor robustez en el procesamiento de pagos
- Garantía de integridad financiera
- Trazabilidad completa para auditoría
- Extensibilidad para nuevos métodos de pago
- Desacoplamiento estricto entre componentes

---

*Última actualización: 7 de abril de 2025*