# Módulo de Productos

## Descripción General

El módulo de productos permite la gestión completa del catálogo de productos ofrecidos en las sucursales de JQ Q Berraquera. Incluye funcionalidades para crear, editar, visualizar y eliminar productos, así como para gestionar las opciones de ingredientes que pueden añadirse a cada producto.

## Funcionalidades Implementadas

### Listado de Productos
- Visualización en formato de tabla con información detallada
- Filtrado por categoría, disponibilidad y nombre
- Cambio rápido de disponibilidad mediante interruptores
- Visualización de imágenes de productos
- Botones de acción para editar, configurar opciones y eliminar

### Formulario de Producto
- Creación de nuevos productos
- Edición de productos existentes
- Configuración de información básica (nombre, descripción, precio)
- Asignación a categorías
- Configuración de URL de imagen
- Opciones de disponibilidad y modalidad (para llevar/en local)

### Gestión de Opciones de Producto
- Asignación de ingredientes a productos
- Configuración de ingredientes predeterminados
- Configuración de ingredientes removibles
- Especificación de cantidades predeterminadas
- Interfaz visual para añadir/eliminar opciones

## Estructura de Archivos

El módulo está compuesto por los siguientes archivos principales:

- `pages/admin/productos/ProductosList.js`: Listado y filtrado de productos
- `pages/admin/productos/ProductoForm.js`: Formulario para crear y editar productos
- `pages/admin/productos/ProductoOpciones.js`: Gestión de opciones de ingredientes
- `services/productoService.js`: Comunicación con la API para operaciones CRUD
- `services/opcionProductoService.js`: Gestión de opciones de productos

## API Endpoints

| Método | Ruta | Descripción | Roles Permitidos |
|--------|------|-------------|------------------|
| `GET` | `/api/productos` | Obtener todos los productos (con filtros opcional) | Todos (autenticados) |
| `GET` | `/api/productos/:id` | Obtener un producto específico con sus opciones | Todos (autenticados) |
| `GET` | `/api/productos/categoria/:categoriaId` | Obtener productos por categoría | Todos (autenticados) |
| `POST` | `/api/productos` | Crear un nuevo producto | Administrador |
| `PUT` | `/api/productos/:id` | Actualizar un producto existente | Administrador |
| `DELETE` | `/api/productos/:id` | Eliminar un producto | Administrador |
| `PUT` | `/api/productos/:id/opciones` | Actualizar opciones de ingredientes | Administrador |
| `PATCH` | `/api/productos/:id/disponibilidad` | Cambiar disponibilidad de un producto | Administrador, Cocinero |

## Modelo de Datos

### Producto

```javascript
const productoSchema = new Schema({
  nombre: {
    type: String,
    required: true,
    trim: true
  },
  descripcion: {
    type: String,
    trim: true
  },
  precio_base: {
    type: Number,
    required: true,
    min: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  categoria: {
    type: Schema.Types.ObjectId,
    ref: 'Categoria',
    required: true
  },
  imagen: {
    type: String,
    trim: true
  },
  disponible: {
    type: Boolean,
    default: true
  },
  para_llevar: {
    type: String,
    enum: ['sí', 'no', 'ambos'],
    default: 'ambos'
  }
}, {
  timestamps: {
    createdAt: 'fecha_creacion',
    updatedAt: 'fecha_actualizacion'
  }
});
OpcionProducto
javascriptCopyconst opcionProductoSchema = new Schema({
  producto: {
    type: Schema.Types.ObjectId,
    ref: 'Producto',
    required: true
  },
  ingrediente: {
    type: Schema.Types.ObjectId,
    ref: 'Ingrediente',
    required: true
  },
  es_predeterminado: {
    type: Boolean,
    default: true
  },
  es_removible: {
    type: Boolean,
    default: true
  },
  cantidad_predeterminada: {
    type: Number,
    default: 1,
    min: 0
  }
}, {
  timestamps: {
    createdAt: 'fecha_creacion', 
    updatedAt: 'fecha_actualizacion'
  }
});

// Índice compuesto para prevenir duplicados
opcionProductoSchema.index({ producto: 1, ingrediente: 1 }, { unique: true });
Casos de Uso Principales
Creación de un Producto

El administrador navega a la lista de productos
Hace clic en "Nuevo Producto"
Completa el formulario con información básica
Guarda el producto
Navega a la página de opciones de producto
Añade los ingredientes disponibles para el producto
Configura cuáles son predeterminados y removibles
Guarda la configuración

Cambio de Disponibilidad

El administrador o cocinero navega a la lista de productos
Cambia el interruptor de disponibilidad
El sistema actualiza automáticamente la disponibilidad

Filtrado de Productos

El usuario navega a la lista de productos
Utiliza los filtros por categoría, disponibilidad o búsqueda por nombre
El sistema muestra los productos que coinciden con los criterios

Integración con Otros Módulos
Módulo de Categorías

Los productos están asociados a categorías que deben crearse previamente.

Módulo de Ingredientes

Los productos pueden tener múltiples ingredientes asociados que deben estar disponibles.

Módulo de Ventas

La información de productos y sus opciones de personalización se utiliza en el punto de venta.
Las opciones configuradas determinan qué ingredientes pueden agregarse o quitarse durante la personalización.
Los precios base y adicionales configurados aquí se utilizan para calcular el precio final de venta.

Consideraciones Técnicas
Rendimiento

Indexación de campos clave (nombre, categoría, disponibilidad)
Carga eficiente de relaciones mediante populate()
Filtrado optimizado en backend y frontend

Seguridad

Validación completa de datos tanto en frontend como backend
Restricción de acciones por rol de usuario
Protección CSRF mediante tokens

Usabilidad

Interfaz intuitiva con acciones claras
Feedback inmediato al usuario tras operaciones
Validación en tiempo real de formularios

Problemas Encontrados y Soluciones
1. Error CORS con método PATCH
Problema: Al intentar cambiar la disponibilidad de productos mediante el método PATCH, se producían errores CORS porque este método no estaba permitido en la configuración del servidor.
Solución:
Se actualizó la configuración CORS en server.js para incluir el método PATCH:
javascriptCopyapp.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:3000',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'], // Añadido PATCH
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));
Se eliminó una configuración CORS duplicada que causaba conflictos.
2. Problemas de Visualización de Iconos
Problema: Los iconos de Bootstrap no se visualizaban correctamente en los botones de acción.
Solución:

Se reemplazaron los iconos por texto descriptivo en los botones para mejorar la compatibilidad
Alternativamente, se pueden usar SVG embebidos para garantizar la visualización sin depender de bibliotecas externas

3. Filtrado de Productos
Problema: Al seleccionar "Todos" en el filtro de disponibilidad, se ocultaban los productos.
Solución:
Se modificó la lógica de filtrado para no incluir el parámetro disponible cuando está vacío:
javascriptCopy// Si disponible es una cadena vacía, no la incluimos en los filtros
const filtrosAplicados = {...filtros};
if (filtrosAplicados.disponible === '') {
  delete filtrosAplicados.disponible;
}
4. Búsqueda por Nombre
Problema: La búsqueda por nombre no filtraba correctamente los productos.
Solución:
Se implementó un filtrado en el cliente para buscar por nombre:
javascriptCopy// Filtramos por nombre en el cliente si hay un término de búsqueda
if (buscar && buscar.trim() !== '') {
  const busqueda = buscar.trim().toLowerCase();
  productosData = productosData.filter(producto => 
    producto.nombre.toLowerCase().includes(busqueda)
  );
}
5. Error en la Personalización de Productos
Problema: Durante la implementación del módulo de ventas, se descubrió que algunas opciones de productos no se cargaban correctamente en el componente de personalización.
Solución:
Se mejoró la carga de opciones de productos en el componente de personalización:
javascriptCopy// En PersonalizarProducto.js
useEffect(() => {
  const cargarOpciones = async () => {
    try {
      setLoading(true);
      const respuesta = await opcionProductoService.obtenerPorProducto(productoId);
      
      if (respuesta.success) {
        // Organizar las opciones en predeterminadas y adicionales
        const predeterminadas = respuesta.data.filter(op => op.es_predeterminado);
        const adicionales = respuesta.data.filter(op => !op.es_predeterminado);
        
        setOpcionesPredeterminadas(predeterminadas);
        setOpcionesAdicionales(adicionales);
      }
      
      setError(null);
    } catch (error) {
      setError('Error al cargar opciones del producto');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  
  if (productoId) {
    cargarOpciones();
  }
}, [productoId]);
Flujo de Trabajo - Gestión de Productos
El siguiente diagrama muestra el flujo de trabajo para la gestión completa de productos:
┌─────────────────┐     ┌────────────────┐     ┌─────────────────┐
│                 │     │                │     │                 │
│  Creación de    │────►│ Configuración  │────►│  Visualización  │
│  Categorías     │     │ de Ingredientes│     │  en Catálogo    │
│                 │     │                │     │                 │
└─────────────────┘     └────────────────┘     └─────────────────┘
        ▲                       │                       │
        │                       │                       │
        │                       ▼                       ▼
┌───────┴───────┐     ┌─────────────────┐     ┌─────────────────┐
│               │     │                 │     │                 │
│ Configuración │◄────┤  Creación de    │     │  Uso en Módulo  │
│ de Opciones   │     │  Productos      │     │  de Ventas      │
│ de Ingrediente│     │                 │     │                 │
└───────────────┘     └─────────────────┘     └─────────────────┘
        │                       ▲
        │                       │
        ▼                       │
┌───────────────┐     ┌─────────────────┐
│               │     │                 │
│  Gestión de   │────►│ Actualización   │
│ Disponibilidad│     │ de Información  │
│               │     │                 │
└───────────────┘     └─────────────────┘
Mejoras Planificadas

Sistema de Subida de Imágenes: Permitir la subida de imágenes locales en lugar de URLs
Previsualización de Productos: Mostrar cómo se verá el producto en el punto de venta
Gestión de Variantes: Permitir configurar variantes de productos (tamaños, presentaciones)
Importación/Exportación: Facilitar la carga masiva de productos mediante CSV
Productos Compuestos: Permitir la creación de combos y productos compuestos
Integración con Inventario: Actualización automática del inventario al realizar ventas


Última actualización: 12 de marzo de 2025