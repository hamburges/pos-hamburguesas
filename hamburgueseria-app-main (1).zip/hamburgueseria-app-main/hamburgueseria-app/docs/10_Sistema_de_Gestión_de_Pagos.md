# Sistema de Gestión de Pagos con Reconciliación Financiera

Este documento detalla la arquitectura e implementación del Sistema de Gestión de Pagos con Reconciliación Financiera para "JQ Q Berraquera", diseñado bajo principios de máximo desacoplamiento y responsabilidad única.

## 1. Análisis Arquitectónico

### 1.1 Descomposición Funcional

El sistema implementa una arquitectura de microservicios internos con responsabilidades atómicas:

- **ReconciliadorFinanciero**: Servicio único responsable de ajustar montos financieros
- **GestorConfirmaciones**: Administra flujos de estados transaccionales durante confirmaciones
- **AdaptadorPresentación**: Transforma estados financieros en representaciones visuales
- **ValidadorEntrada**: Aplica reglas de negocio desacopladas de la interfaz

Esta arquitectura implementa estricta separación entre:
- Cálculo financiero
- Gestión de estados
- Presentación visual
- Validación de datos

### 1.2 Patrón Arquitectónico Implementado

```
┌─────────────────────┐        ┌─────────────────────┐
│ Capa de Presentación│        │ Capa de Dominio     │
│                     │        │                     │
│  - Visualizadores   │◄──────►│  - Reconciliadores  │
│  - Adaptadores UI   │        │  - Validadores      │
└─────────────────────┘        └─────────────────────┘
           ▲                             ▲
           │                             │
           ▼                             ▼
┌─────────────────────┐        ┌─────────────────────┐
│ Capa de Estado      │        │ Capa de Integración │
│                     │        │                     │
│  - GestorEstados    │◄──────►│  - Transformadores  │
│  - SincronizadorUI  │        │  - Serializadores   │
└─────────────────────┘        └─────────────────────┘
```

## 2. Implementaciones Fundamentales

### 2.1 Sistema de Reconciliación Financiera

Microservicio interno con responsabilidad única de mantener integridad financiera:

```javascript
const reconciliadorFinanciero = {
  /**
   * Ajusta montos para garantizar balance exacto tras confirmación
   * @param {Array<Object>} pagos - Registros de pagos realizados
   * @param {Number} montoRequerido - Valor total requerido
   * @param {Boolean} confirmado - Estado de confirmación
   * @returns {Object} - Valores reconciliados con integridad garantizada
   */
  reconciliar(pagos, montoRequerido, confirmado) {
    // Cálculos brutos iniciales
    const totalBruto = this._calcularTotalBruto(pagos);
    const pagosEfectivo = this._extraerPagosEfectivo(pagos);
    const cambioBruto = Math.max(0, pagosEfectivo - montoRequerido);
    
    // Reconciliación condicional
    if (confirmado && cambioBruto > 0) {
      // Implementación de ajuste automático preservando valores originales
      return this._generarEstadoReconciliado(pagos, montoRequerido, cambioBruto);
    }
    
    // Sin reconciliación, valores brutos
    return {
      pagosReconciliados: [...pagos],
      totalReconciliado: totalBruto,
      cambio: cambioBruto,
      saldoPendiente: Math.max(0, montoRequerido - totalBruto)
    };
  },
  
  // Métodos privados para cálculos específicos
  _calcularTotalBruto(pagos) { /* implementación */ },
  _extraerPagosEfectivo(pagos) { /* implementación */ },
  _generarEstadoReconciliado(pagos, montoRequerido, cambio) { /* implementación */ }
}
```

### 2.2 Sistema de Confirmación de Cambio

Implementa una máquina de estados para el ciclo de vida de una transacción:

```javascript
const gestorConfirmaciones = {
  // Estados posibles
  estados: {
    INICIAL: 'inicial',
    CAMBIO_PENDIENTE: 'cambio_pendiente',
    CAMBIO_CONFIRMADO: 'cambio_confirmado',
    PAGO_COMPLETO: 'pago_completo',
    ERROR: 'error'
  },
  
  // Transiciones permitidas entre estados
  transiciones: {
    'inicial': ['cambio_pendiente', 'pago_completo', 'error'],
    'cambio_pendiente': ['cambio_confirmado', 'error'],
    'cambio_confirmado': ['pago_completo', 'error'],
    'pago_completo': ['error'],
    'error': ['inicial']
  },
  
  /**
   * Procesa evento y retorna siguiente estado válido
   * @param {String} estadoActual - Estado actual del sistema
   * @param {String} evento - Evento desencadenado
   * @returns {String} - Nuevo estado
   */
  procesarEvento(estadoActual, evento) {
    // Implementación de lógica de transición
  }
}
```

### 2.3 Validador Desacoplado

Componente autónomo para aplicar reglas de negocio sin acoplamiento a UI:

```javascript
const validadorPagos = {
  /**
   * Valida integridad de método de pago según reglas de negocio
   * @param {String} metodo - Método de pago
   * @param {String|Number} monto - Monto ingresado
   * @param {String} referencia - Referencia para métodos electrónicos
   * @param {Number} saldoPendiente - Saldo restante
   * @returns {Object} - Resultado de validación
   */
  validarMetodoPago(metodo, monto, referencia, saldoPendiente) {
    // Pipeline de validación con cortocircuito
    
    // 1. Validar monto básico
    const validacionMonto = this._validarMontoBasico(monto);
    if (!validacionMonto.valido) return validacionMonto;
    
    // 2. Validar referencia para métodos que lo requieren
    const validacionReferencia = this._validarReferencia(metodo, referencia);
    if (!validacionReferencia.valido) return validacionReferencia;
    
    // 3. Validar límites por tipo de método
    return this._validarLimitesPorMetodo(metodo, monto, saldoPendiente);
  },
  
  // Métodos privados para validaciones específicas
  _validarMontoBasico(monto) { /* implementación */ },
  _validarReferencia(metodo, referencia) { /* implementación */ },
  _validarLimitesPorMetodo(metodo, monto, saldoPendiente) { /* implementación */ }
}
```

## 3. Diagrama de Flujo de Transacciones

```
┌────────────┐
│ Inicio     │
└─────┬──────┘
      │
      ▼
┌─────────────┐    No    ┌─────────────┐
│¿Efectivo con├─────────►│Otros Métodos│
│  cambio?    │          │  de Pago    │
└─────┬───────┘          └──────┬──────┘
      │ Sí                      │
      ▼                         │
┌─────────────┐                 │
│  Confirmar  │                 │
│   Cambio    │                 │
└─────┬───────┘                 │
      │                         │
      ▼                         ▼
┌─────────────────────────────────┐
│ Reconciliación Financiera       │
│ - Ajuste automático de montos   │
│ - Balance exacto garantizado    │
└─────────────┬───────────────────┘
              │
              ▼
┌─────────────────────────────────┐
│ Completar Transacción           │
└─────────────────────────────────┘
```

## 4. Vectores de Extensión Vertical

La arquitectura implementa múltiples vectores de extensión que permiten evolución orgánica sin modificación de código base:

```javascript
// Patrón estrategia para algoritmos de reconciliación intercambiables
class EstrategiaReconciliacion {
  reconciliar(pagos, totalRequerido) { /* Interfaz abstracta */ }
}

class ReconciliacionEstándar extends EstrategiaReconciliacion {
  reconciliar(pagos, totalRequerido) {
    // Implementación actual
  }
}

class ReconciliacionProporcional extends EstrategiaReconciliacion {
  reconciliar(pagos, totalRequerido) {
    // Algoritmo alternativo que distribuye ajustes proporcionalmente
  }
}

// Cliente que consume cualquier estrategia que cumpla el contrato
class ProcesadorTransacciones {
  constructor(estrategiaReconciliacion) {
    this.estrategia = estrategiaReconciliacion;
  }
  
  procesarPago(pagos, totalRequerido) {
    return this.estrategia.reconciliar(pagos, totalRequerido);
  }
}
```

## 5. Mecanismos de Propagación de Eventos

```javascript
// Sistema de eventos para desacoplar completamente acciones y reacciones
class EventBus {
  constructor() {
    this.handlers = new Map();
  }
  
  subscribe(event, handler) {
    if (!this.handlers.has(event)) {
      this.handlers.set(event, []);
    }
    this.handlers.get(event).push(handler);
  }
  
  publish(event, data) {
    if (this.handlers.has(event)) {
      this.handlers.get(event).forEach(handler => handler(data));
    }
  }
}

// Integración con reconciliación
const eventBus = new EventBus();
eventBus.subscribe('cambio.confirmado', data => {
  // Reconciliación automática sin acoplamiento directo
  const datosReconciliados = reconciliadorFinanciero.reconciliar(data.pagos, data.total, true);
  // Propagación de estado actualizado
  eventBus.publish('transaccion.reconciliada', datosReconciliados);
});
```

## 6. Sistema de Validación Estratificado

```javascript
// Cadena de responsabilidad para validación progresiva
class ValidadorBase {
  constructor(nextValidator = null) {
    this.nextValidator = nextValidator;
  }
  
  validate(data) {
    const result = this.doValidate(data);
    if (!result.isValid && !this.nextValidator) {
      return result;
    }
    
    return this.nextValidator ? this.nextValidator.validate(data) : result;
  }
  
  doValidate(data) { return { isValid: true }; }
}

class ValidadorMonto extends ValidadorBase {
  doValidate(data) {
    if (!data.monto || parseFloat(data.monto) <= 0) {
      return {
        isValid: false,
        error: 'Monto debe ser mayor a cero'
      };
    }
    return { isValid: true };
  }
}

// Composición de validadores
const validadorCompleto = new ValidadorMonto(
  new ValidadorReferencia(
    new ValidadorLimite()
  )
);
```

## 7. Ampliación Mediante Comportamiento Polimórfico

```javascript
// Estrategia para métodos de pago con comportamiento específico
class EstrategiaMetodoPago {
  validar(monto, referencia, saldoPendiente) { /* Abstracto */ }
  procesarPago(monto, referencia) { /* Abstracto */ }
  requiereReferencia() { /* Abstracto */ }
}

class EstrategiaEfectivo extends EstrategiaMetodoPago {
  validar(monto, _, saldoPendiente) {
    return { 
      valido: parseFloat(monto) > 0,
      mensaje: parseFloat(monto) <= 0 ? 'Monto inválido' : null
    };
  }
  
  procesarPago(monto, _) {
    // Procesar pago en efectivo
    return { tipo: 'efectivo', monto: parseFloat(monto) };
  }
  
  requiereReferencia() {
    return false;
  }
  
  generaCambio(monto, totalRequerido) {
    return Math.max(0, parseFloat(monto) - totalRequerido);
  }
}

// Fábrica de estrategias - Open/Closed Principle
class FabricaEstrategiasPago {
  obtenerEstrategia(metodo) {
    switch(metodo) {
      case 'efectivo': return new EstrategiaEfectivo();
      case 'nequi': return new EstrategiaNequi();
      case 'daviplata': return new EstrategiaDaviplata();
      case 'transferencia': return new EstrategiaTransferencia();
      default: throw new Error(`Método no soportado: ${metodo}`);
    }
  }
}
```

## 8. Beneficios de la Arquitectura

### 8.1 Desacoplamiento Total

- **Separación Crítica**: Los cálculos financieros están completamente desacoplados de la interfaz de usuario
- **Interfaces Contractuales**: Cada módulo expone interfaces precisas sin dependencias implementativas
- **Sustitución Sin Impacto**: Cualquier componente puede reemplazarse sin modificar otros sistemas

### 8.2 Integridad Transaccional

- **Garantía de Balance**: El sistema asegura reconciliación exacta entre monto requerido y pagado
- **Trazabilidad**: Conservación de valores originales y reconciliados para auditoría completa
- **Atomicidad**: Las operaciones de reconciliación son atómicas e indivisibles

### 8.3 Extensibilidad

- **Ampliación Vertical**: Nuevos métodos de pago añadibles sin modificar lógica existente
- **Ampliación Horizontal**: Nuevas reglas de reconciliación incorporables mediante composición
- **Extensiones Especializadas**: Posibilidad de añadir capacidades como redondeo fiscal o ajustes por divisa

## 9. Casos de Prueba Fundamentales

| Escenario | Entrada | Comportamiento Esperado | Reconciliación |
|-----------|---------|--------------------------|----------------|
| Pago exacto | Efectivo = Total | Completar sin cambio | No requerida |
| Pago con cambio | Efectivo > Total | Requerir confirmación | Ajusta valor a total exacto |
| Pago electrónico | Nequi/Daviplata = Total | Requerir referencia | No aplicable |
| Pago mixto | Efectivo + Electrónico | Reconciliación parcial | Solo efectivo reconciliado |
| Cancelación | Cualquier estado | Revertir transacción | Descarta reconciliación |

## 10. Integración con Sistema de Ventas

Este sistema se integra con el Módulo de Ventas existente mediante:

- **Integración por Eventos**: Utilizando el EventBus para comunicación asíncrona
- **Adaptadores de Modelos**: Transformadores entre el dominio de ventas y el de pagos
- **Interfaz Unificada**: API común para procesamiento de pagos independiente del método

## 11. Consideraciones para Extensiones Futuras

- **Integración con Impuestos**: Incorporación de cálculos fiscales automatizados
- **Personalización de Reglas**: Parametrización de reglas de reconciliación por usuario o sucursal
- **Ciclos de Caja Extendidos**: Integración bidireccional con arqueos y cierres de caja
- **Auditoría Avanzada**: Registro detallado de operaciones de reconciliación para cumplimiento regulatorio

---

*Última actualización: 7 de abril de 2025*