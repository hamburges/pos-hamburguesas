import api from './api';

const sucursalService = {
  // Obtener todas las sucursales
  obtenerTodas: async () => {
    try {
      const response = await api.get('/sucursales');
      return response.data.data;
    } catch (error) {
      console.error('Error al obtener sucursales:', error);
      throw error;
    }
  },

  // Crear nueva sucursal
  crear: async (sucursal) => {
    try {
      const response = await api.post('/sucursales', sucursal);
      return response.data.data;
    } catch (error) {
      console.error('Error al crear sucursal:', error);
      throw error;
    }
  },

  // Obtener sucursal por ID
  obtenerPorId: async (id) => {
    try {
      const response = await api.get(`/sucursales/${id}`);
      return response.data.data;
    } catch (error) {
      console.error('Error al obtener sucursal:', error);
      throw error;
    }
  },

  // Actualizar sucursal
  actualizar: async (id, sucursal) => {
    try {
      const response = await api.put(`/sucursales/${id}`, sucursal);
      return response.data.data;
    } catch (error) {
      console.error('Error al actualizar sucursal:', error);
      throw error;
    }
  },

  // Eliminar sucursal
  eliminar: async (id) => {
    try {
      const response = await api.delete(`/sucursales/${id}`);
      return response.data;
    } catch (error) {
      console.error('Error al eliminar sucursal:', error);
      throw error;
    }
  }
};

export default sucursalService;