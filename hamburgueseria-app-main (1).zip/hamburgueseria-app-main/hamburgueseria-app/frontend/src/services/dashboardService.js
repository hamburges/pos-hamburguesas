import api from './api';

const dashboardService = {
  // Obtener estadísticas generales
  obtenerEstadisticas: async () => {
    try {
      // Realizar múltiples solicitudes en paralelo usando la instancia api configurada
      const [sucursalesRes, usuariosRes, productosRes, categoriasRes, ingredientesRes] = await Promise.all([
        api.get('/sucursales'),
        api.get('/usuarios'),
        api.get('/productos'),
        api.get('/categorias'),
        api.get('/ingredientes')
      ]);
      
      // Procesar y devolver las estadísticas
      return {
        sucursales: sucursalesRes.data.data || [],
        usuarios: usuariosRes.data.data || [],
        productos: productosRes.data.data || [],
        categorias: categoriasRes.data.data || [],
        ingredientes: ingredientesRes.data.data || [],
        // Estadísticas derivadas
        sucursalesActivas: (sucursalesRes.data.data || []).filter(s => s.estado === 'activa').length,
        totalSucursales: (sucursalesRes.data.data || []).length,
        // Ingredientes con stock bajo
        ingredientesBajoStock: (ingredientesRes.data.data || []).filter(
          ing => ing.stock <= ing.stock_minimo
        )
      };
    } catch (error) {
      console.error('Error al obtener estadísticas del dashboard:', error);
      throw error;
    }
  }
};

export default dashboardService;