import api from './api';

/**
 * Servicio para gestión de cajas y ciclos
 * Adaptado para funcionar con el nuevo sistema de ciclos
 */
const cajaService = {
  /**
   * Abre un nuevo ciclo de caja
   */
  abrirCaja: async (datos) => {
    try {
      console.log("Intentando abrir ciclo con datos:", datos);
      
      // Preparar datos para la apertura
      const datosApertura = {
        monto_apertura: parseFloat(datos.monto_apertura || datos.monto || 0),
        observaciones: datos.observaciones || datos.notas || ''
      };
      
      // Usar el endpoint de ciclos-caja para abrir ciclo
      const response = await api.post('/ciclos-caja/abrir', datosApertura);
      return response.data;
    } catch (error) {
      console.error("Error al abrir ciclo:", error.response?.data || error.message);
      throw error;
    }
  },
  
  /**
   * Verifica y obtiene el ciclo de caja actual/activo
   */
  obtenerCajaActual: async () => {
    try {
      console.log("Obteniendo ciclo activo...");
      
      // CORREGIDO: Cambiar la ruta por /actual para obtener el ciclo activo
      const response = await api.get('/ciclos-caja/actual');
      return response.data;
    } catch (error) {
      console.error("Error al obtener ciclo activo:", error.response?.data || error.message);
      throw error;
    }
  },
  
  /**
   * Registra un movimiento de caja (ingreso o egreso)
   * Usa el nuevo endpoint de movimientos
   */
  agregarMovimiento: async (datos) => {
    try {
      console.log("Registrando movimiento:", datos);
      
      // Preparar datos del movimiento para el nuevo endpoint
      const movimientoData = {
        tipo: datos.tipo,
        concepto: datos.concepto,
        monto: parseFloat(datos.monto),
        codigo_autorizacion: datos.codigo_autorizacion || undefined
      };
      
      // Usar el nuevo endpoint de movimientos
      const response = await api.post('/movimientos', movimientoData);
      return response.data;
    } catch (error) {
      console.error("Error al registrar movimiento:", error.response?.data || error.message);
      throw error;
    }
  },
  
  /**
   * Obtiene los movimientos del ciclo activo o de un ciclo específico
   */
  obtenerMovimientos: async (cicloId = null) => {
    try {
      let url = '/movimientos';
      
      // Si se especifica un ID de ciclo, obtener movimientos de ese ciclo
      if (cicloId) {
        url = `/movimientos/${cicloId}`;
      }
      
      const response = await api.get(url);
      return response.data;
    } catch (error) {
      console.error("Error al obtener movimientos:", error.response?.data || error.message);
      throw error;
    }
  },
  
  /**
   * Cierra un ciclo de caja
   */
  cerrarCaja: async (datos) => {
    try {
      const id = datos.id || datos.caja_id || datos.ciclo_id;
      
      if (!id) {
        throw new Error('Se requiere ID del ciclo para cerrar la caja');
      }
      
      console.log(`Cerrando ciclo ${id} con datos:`, datos);
      
      // Preparar datos para el cierre
      const datosCierre = {
        monto_final: parseFloat(datos.monto_final || datos.monto_cierre_real || 0),
        observaciones: datos.observaciones || datos.notas_cierre || '',
        codigo_autorizacion: datos.codigo_autorizacion
      };
      
      // Usar el endpoint de ciclos-caja para cerrar
      const response = await api.post(`/ciclos-caja/${id}/cerrar`, datosCierre);
      return response.data;
    } catch (error) {
      console.error("Error al cerrar ciclo:", error.response?.data || error.message);
      throw error;
    }
  },
  
  /**
   * Obtiene el historial de ciclos con filtrado y paginación
   */
  obtenerHistorial: async (filtros = {}) => {
    try {
      let queryParams = new URLSearchParams();
      
      // Añadir todos los filtros disponibles
      if (filtros.fechaInicio) queryParams.append('fechaInicio', filtros.fechaInicio);
      if (filtros.fechaFin) queryParams.append('fechaFin', filtros.fechaFin);
      if (filtros.sucursal) queryParams.append('sucursal', filtros.sucursal);
      if (filtros.estado) queryParams.append('estado', filtros.estado);
      if (filtros.pagina) queryParams.append('pagina', filtros.pagina || 1);
      if (filtros.limite) queryParams.append('limite', filtros.limite || 10);
      
      console.log("Obteniendo historial con filtros:", queryParams.toString());
      
      // Usar el endpoint principal de ciclos-caja (obtenerHistorial)
      const response = await api.get(`/ciclos-caja?${queryParams.toString()}`);
      return response.data;
    } catch (error) {
      console.error("Error al obtener historial:", error.response?.data || error.message);
      throw error;
    }
  },
  
  /**
   * Obtiene los detalles de un ciclo específico
   * Opcionalmente incluye código de autorización para acceder a datos protegidos
   */
  obtenerDetalleCaja: async (id, codigoAutorizacion = null) => {
    try {
      if (!id) {
        throw new Error('Se requiere ID del ciclo para obtener detalles');
      }
      
      let url = `/ciclos-caja/${id}`;
      
      // Añadir código de autorización si se proporciona
      if (codigoAutorizacion) {
        url += `?codigo_autorizacion=${codigoAutorizacion}`;
      }
      
      console.log(`Obteniendo detalles del ciclo ${id}`);
      const response = await api.get(url);
      return response.data;
    } catch (error) {
      console.error("Error al obtener detalles del ciclo:", error.response?.data || error.message);
      throw error;
    }
  },
  
  /**
   * Verifica un código de autorización de administrador
   */
  verificarAutorizacion: async (codigo) => {
    try {
      if (!codigo) {
        return { success: false, message: 'Código de autorización requerido' };
      }
      
      console.log("Verificando código de autorización");
      const response = await api.post('/usuarios/autorizar', { codigo });
      return response.data;
    } catch (error) {
      console.error("Error al verificar autorización:", error.response?.data || error.message);
      throw error;
    }
  }
};

export default cajaService;