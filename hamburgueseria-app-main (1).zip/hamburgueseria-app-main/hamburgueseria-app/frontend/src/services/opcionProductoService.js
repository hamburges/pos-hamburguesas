// src/services/opcionProductoService.js
import api from './api';

const opcionProductoService = {
  obtenerOpcionesPorProducto: async (productoId) => {
    try {
      const response = await api.get(`/productos/${productoId}/opciones`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  crearOpcion: async (productoId, opcion) => {
    try {
      const response = await api.post(`/productos/${productoId}/opciones`, opcion);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  actualizarOpcion: async (productoId, opcionId, opcion) => {
    try {
      const response = await api.put(`/productos/${productoId}/opciones/${opcionId}`, opcion);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  eliminarOpcion: async (productoId, opcionId) => {
    try {
      const response = await api.delete(`/productos/${productoId}/opciones/${opcionId}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  actualizarOpciones: async (productoId, opciones) => {
    try {
      const response = await api.put(`/productos/${productoId}/opciones`, { opciones });
      return response.data;
    } catch (error) {
      throw error;
    }
  }
};

export default opcionProductoService;