// src/services/ventaService.js
import api from './api';

const ventaService = {
  // Crear una nueva venta
  crearVenta: async (datosVenta) => {
    try {
      // Asegurarnos de que ciclo_caja esté incluido en los datos si existe
      if (datosVenta.ciclo_caja) {
        datosVenta = {
          ...datosVenta,
          ciclo_caja: datosVenta.ciclo_caja
        };
      }
      
      const response = await api.post('/ventas', datosVenta);
      return response.data;
    } catch (error) {
      console.error('Error al crear venta:', error.response?.data || error.message);
      throw error;
    }
  },

  // Obtener todas las ventas con filtros opcionales
  obtenerVentas: async (filtros = {}) => {
    try {
      let queryParams = new URLSearchParams();

      // Añadir filtros a los parámetros de consulta
      Object.entries(filtros).forEach(([key, value]) => {
        if (value) queryParams.append(key, value);
      });

      console.log('URL de consulta:', `/ventas?${queryParams.toString()}`);
      const response = await api.get(`/ventas?${queryParams.toString()}`);
      console.log('Respuesta obtenerVentas:', response.data);
      
      // Normalizar los valores numéricos
      if (response.data && response.data.data) {
        response.data.data = response.data.data.map(venta => ({
          ...venta,
          total: Number(venta.total),
          subtotal: Number(venta.subtotal || 0),
          descuento: Number(venta.descuento || 0),
          impuestos: Number(venta.impuestos || 0)
        }));
      }
      
      return response.data;
    } catch (error) {
      console.error('Error en obtenerVentas:', error.response?.data || error.message);
      throw error;
    }
  },

  // Obtener ventas del día actual
  obtenerVentasDelDia: async (sucursal = null, ciclo_caja = null) => {
    try {
      // Usar la ruta específica para ventas del día
      let url = '/ventas/obtener-dia';
      let params = [];
      
      if (sucursal) {
        params.push(`sucursal=${sucursal}`);
      }
      
      if (ciclo_caja) {
        params.push(`ciclo_caja=${ciclo_caja}`);
      }
      
      if (params.length > 0) {
        url += `?${params.join('&')}`;
      }
      
      console.log('URL de consulta del día:', url);
      const response = await api.get(url);
      console.log('Respuesta obtenerVentasDelDia:', response.data);
      
      // Normalizar los valores numéricos
      if (response.data && response.data.data && response.data.data.ventas) {
        response.data.data.ventas = response.data.data.ventas.map(venta => ({
          ...venta,
          total: Number(venta.total),
          subtotal: Number(venta.subtotal || 0),
          descuento: Number(venta.descuento || 0),
          impuestos: Number(venta.impuestos || 0)
        }));
      }
      
      return response.data;
    } catch (error) {
      console.error('Error en obtenerVentasDelDia:', error.response?.data || error.message);
      throw error;
    }
  },

  // Obtener una venta específica por ID
  obtenerVentaPorId: async (id) => {
    try {
      const response = await api.get(`/ventas/${id}`);
      
      // Normalizar los valores numéricos
      if (response.data && response.data.data) {
        response.data.data = {
          ...response.data.data,
          total: Number(response.data.data.total),
          subtotal: Number(response.data.data.subtotal || 0),
          descuento: Number(response.data.data.descuento || 0),
          impuestos: Number(response.data.data.impuestos || 0)
        };
      }
      
      return response.data;
    } catch (error) {
      console.error('Error al obtener venta por ID:', error.response?.data || error.message);
      throw error;
    }
  },

  anularVenta: async (id, datos) => {
    try {
      const response = await api.put(`/ventas/${id}/anular`, datos);
      return response.data;
    } catch (error) {
      throw error;
    }
  }
};

export default ventaService;