// src/services/cicloCajaService.js
import api from './api';

const cicloCajaService = {
  // Obtener ciclo actual
  obtenerCicloActual: async () => {
    try {
      const response = await api.get('/ciclos-caja/actual');
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Abrir nuevo ciclo
  abrirCiclo: async (datos) => {
    try {
      const response = await api.post('/ciclos-caja/abrir', datos);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Cerrar ciclo
  cerrarCiclo: async (id, datos) => {
    try {
      const response = await api.post(`/ciclos-caja/${id}/cerrar`, datos);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Obtener historial de ciclos
  obtenerHistorial: async (filtros = {}) => {
    try {
      let queryParams = new URLSearchParams();
      
      if (filtros.fechaInicio) queryParams.append('fechaInicio', filtros.fechaInicio);
      if (filtros.fechaFin) queryParams.append('fechaFin', filtros.fechaFin);
      if (filtros.estado) queryParams.append('estado', filtros.estado);
      if (filtros.pagina) queryParams.append('pagina', filtros.pagina);
      if (filtros.limite) queryParams.append('limite', filtros.limite);
      if (filtros.sucursal) queryParams.append('sucursal', filtros.sucursal);
      
      const response = await api.get(`/ciclos-caja/historial?${queryParams.toString()}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  
  // Obtener detalle de un ciclo específico
  obtenerDetalleCiclo: async (id, codigoAutorizacion = null) => {
    try {
      let url = `/ciclos-caja/${id}`;
      
      if (codigoAutorizacion) {
        url += `?codigo_autorizacion=${codigoAutorizacion}`;
      }
      
      const response = await api.get(url);
      return response.data;
    } catch (error) {
      throw error;
    }
  }
};

export default cicloCajaService;