import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import PrivateRoute from './components/PrivateRoute';

// Componente de carga
import LoadingSpinner from './components/common/LoadingSpinner';

// Solo importar componentes críticos de forma estática
import Login from './pages/auth/Login';

// Páginas de autenticación
const Unauthorized = lazy(() => import('./pages/auth/Unauthorized'));

// Páginas de administrador
const AdminDashboard = lazy(() => import('./pages/admin/Dashboard'));
const UsuariosList = lazy(() => import('./pages/admin/usuarios/UsuariosList'));
const NuevoUsuario = lazy(() => import('./pages/admin/usuarios/NuevoUsuario'));
const EditarUsuario = lazy(() => import('./pages/admin/usuarios/EditarUsuario'));
const SucursalesList = lazy(() => import('./pages/admin/sucursales/SucursalesList'));
const NuevaSucursal = lazy(() => import('./pages/admin/sucursales/NuevaSucursal'));
const EditarSucursal = lazy(() => import('./pages/admin/sucursales/EditarSucursal'));
const ProductosList = lazy(() => import('./pages/admin/productos/ProductosList'));
const ProductoForm = lazy(() => import('./pages/admin/productos/ProductoForm'));
const ProductoOpciones = lazy(() => import('./pages/admin/productos/ProductoOpciones'));
const CategoriasList = lazy(() => import('./pages/admin/categorias/CategoriasList'));
const CategoriaForm = lazy(() => import('./pages/admin/categorias/CategoriaForm'));
const IngredientesList = lazy(() => import('./pages/admin/ingredientes/IngredientesList'));
const IngredienteForm = lazy(() => import('./pages/admin/ingredientes/IngredienteForm'));
const ReportesList = lazy(() => import('./pages/admin/reportes/ReportesList'));

// Páginas de cajero
const PuntoVenta = lazy(() => import('./pages/cajero/ventas/PuntoVenta'));
const HistorialVentas = lazy(() => import('./pages/cajero/ventas/HistorialVentas'));
const DetalleVenta = lazy(() => import('./pages/cajero/ventas/DetalleVenta'));

// Componentes de caja
const AperturaCaja = lazy(() => import('./components/cajero/AperturaCaja'));
const CierreCaja = lazy(() => import('./components/cajero/CierreCaja'));
const MovimientoCaja = lazy(() => import('./components/cajero/MovimientoCaja'));
const HistorialCaja = lazy(() => import('./components/cajero/HistorialCaja'));
const DetalleCaja = lazy(() => import('./components/cajero/DetalleCaja'));

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Suspense fallback={<LoadingSpinner />}>
          <Routes>
            {/* Rutas públicas */}
            <Route path="/login" element={<Login />} />
            <Route path="/unauthorized" element={<Unauthorized />} />
            
            {/* Rutas para administradores */}
            <Route path="/admin/*" element={<PrivateRoute allowedRoles={['administrador']} />}>
              <Route path="dashboard" element={<AdminDashboard />} />
              
              {/* Rutas de sucursales */}
              <Route path="sucursales" element={<SucursalesList />} />
              <Route path="sucursales/nuevo" element={<NuevaSucursal />} />
              <Route path="sucursales/editar/:id" element={<EditarSucursal />} />
              
              {/* Rutas de usuarios */}
              <Route path="usuarios" element={<UsuariosList />} />
              <Route path="usuarios/nuevo" element={<NuevoUsuario />} />
              <Route path="usuarios/editar/:id" element={<EditarUsuario />} />
              
              {/* Rutas de categorías */}
              <Route path="categorias" element={<CategoriasList />} />
              <Route path="categorias/nuevo" element={<CategoriaForm />} />
              <Route path="categorias/editar/:id" element={<CategoriaForm />} />
              
              {/* Rutas de ingredientes */}
              <Route path="ingredientes" element={<IngredientesList />} />
              <Route path="ingredientes/nuevo" element={<IngredienteForm />} />
              <Route path="ingredientes/editar/:id" element={<IngredienteForm />} />
              
              {/* Rutas de productos */}
              <Route path="productos" element={<ProductosList />} />
              <Route path="productos/nuevo" element={<ProductoForm />} />
              <Route path="productos/editar/:id" element={<ProductoForm />} />
              <Route path="productos/:id/opciones" element={<ProductoOpciones />} />
              
              {/* Otras rutas */}
              <Route path="reportes" element={<ReportesList />} />
              
              {/* Redirecciones */}
              <Route path="" element={<Navigate to="dashboard" />} />
              <Route path="*" element={<Navigate to="dashboard" />} />
            </Route>
            
            {/* Rutas para cajeros */}
            <Route path="/cajero/*" element={<PrivateRoute allowedRoles={['cajero', 'administrador']} />}>
              {/* Rutas de ventas */}
              <Route path="ventas" element={<PuntoVenta />} />
              <Route path="ventas/historial" element={<HistorialVentas />} />
              <Route path="ventas/detalle/:id" element={<DetalleVenta />} />
              
              {/* Rutas para la caja */}
              <Route path="caja/apertura" element={<AperturaCaja />} />
              <Route path="caja/cierre" element={<CierreCaja />} />
              <Route path="caja/movimiento" element={<MovimientoCaja />} />
              <Route path="caja/historial" element={<HistorialCaja />} />
              <Route path="caja/detalle/:id" element={<DetalleCaja />} />
              
              <Route path="" element={<Navigate to="ventas" />} />
              <Route path="*" element={<Navigate to="ventas" />} />
            </Route>
            
            {/* Rutas alternativas para acceso directo */}
            <Route path="/ventas" element={<Navigate to="/cajero/ventas" />} />
            <Route path="/ventas/historial" element={<Navigate to="/cajero/ventas/historial" />} />
            
            {/* Redirección por defecto basada en el rol */}
            <Route 
              path="/" 
              element={
                <Navigate to="/login" />
              } 
            />
            <Route path="*" element={<Navigate to="/login" />} />
          </Routes>
        </Suspense>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;