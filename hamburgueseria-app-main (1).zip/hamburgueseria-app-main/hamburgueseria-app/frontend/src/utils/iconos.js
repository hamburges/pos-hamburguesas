// src/utils/iconos.js
// Lista de opciones de iconos para productos
export const opcionesIconos = [
  { valor: 'hamburguesa-normal', etiqueta: 'Hamburguesa Normal', simbolo: '🍔' },
  { valor: 'hamburguesa-especial', etiqueta: 'Hamburguesa Especial', simbolo: '🥪' },
  { valor: 'hamburguesa-doble', etiqueta: 'Hamburguesa Doble', simbolo: '🍔🍔' },
  { valor: 'perro-sencillo', etiqueta: 'Perro Caliente Sencillo', simbolo: '🌭' },
  { valor: 'perro-especial', etiqueta: 'Perro Caliente Especial', simbolo: '🌭+' },
  { valor: 'chorizo-normal', etiqueta: 'Chorizo Normal', simbolo: '🥓' },
  { valor: 'chorizo-especial', etiqueta: 'Chorizo Especial', simbolo: '🥓+' },
  { valor: 'arepa-sola', etiqueta: 'Arepa Sola', simbolo: '⚪' },
  { valor: 'arepa-chorizo', etiqueta: 'Arepa con Chorizo', simbolo: '🥮' },
  { valor: 'arepa-completa', etiqueta: 'Arepa Completa', simbolo: '🥮+' },
  { valor: 'huevos-codorniz', etiqueta: 'Huevos de Codorniz', simbolo: '🥚' },
  { valor: 'vaso-gaseosa', etiqueta: 'Vaso de Gaseosa', simbolo: '🥤' },
  { valor: 'botella-gaseosa', etiqueta: 'Botella de Gaseosa', simbolo: '🍾' },
  { valor: 'jugo', etiqueta: 'Jugo', simbolo: '🧃' },
  { valor: 'combo', etiqueta: 'Combo', simbolo: '🍱' }
];

// Función para obtener el símbolo según el ID del icono
export const getIconoSimbolo = (iconoId) => {
  const icono = opcionesIconos.find(item => item.valor === iconoId);
  return icono ? icono.simbolo : '📦';
};