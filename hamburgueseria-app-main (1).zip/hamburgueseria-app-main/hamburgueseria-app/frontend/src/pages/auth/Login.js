import React, { useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Alert from 'react-bootstrap/Alert';
import { AuthContext } from '../../context/AuthContext';

// Estilos mínimos para esta página
// Puedes añadir estos en un archivo CSS separado o usar styled-components
const loginStyles = {
  container: {
    marginTop: '3rem'
  },
  card: {
    boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
  }
};

const Login = () => {
  const [credentials, setCredentials] = useState({
    usuario: '',
    contrasena: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { login, user } = useContext(AuthContext);
  const navigate = useNavigate();
  
  // Redirigir si ya está autenticado
  useEffect(() => {
    if (user) {
      redirectUserByRole(user);
    }
  }, [user]);
  
  const redirectUserByRole = (userData) => {
    if (userData.rol === 'administrador') {
      navigate('/admin/dashboard');
    } else if (userData.rol === 'cajero') {
      navigate('/cajero/ventas');
    } else if (userData.rol === 'cocinero') {
      navigate('/cocinero/pedidos');
    } else {
      setError('El usuario no tiene un rol válido');
    }
  };
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setCredentials({
      ...credentials,
      [name]: value
    });
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    try {
      const success = await login(credentials);
      
      if (!success) {
        setError('Credenciales inválidas');
      }
    } catch (err) {
      console.error("Error en login:", err);
      setError(`Error al iniciar sesión: ${err.message || 'Intente nuevamente'}`);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <Container style={loginStyles.container}>
      <Row className="justify-content-center">
        <Col md={6} lg={5}>
          <Card style={loginStyles.card}>
            <Card.Body className="p-4">
              <div className="text-center mb-4">
                <h2 className="fw-bold">JQ Q Berraquera</h2>
                <p className="text-muted">Sistema de Gestión</p>
              </div>
              
              {error && <Alert variant="danger">{error}</Alert>}
              
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label htmlFor="usuario-input">Usuario</Form.Label>
                  <Form.Control
                    id="usuario-input"
                    type="text"
                    name="usuario"
                    value={credentials.usuario}
                    onChange={handleChange}
                    required
                    autoFocus
                    aria-describedby="usuario-help"
                  />
                  <div id="usuario-help" className="form-text">
                    Ingresa tu nombre de usuario asignado.
                  </div>
                </Form.Group>
                
                <Form.Group className="mb-4">
                  <Form.Label htmlFor="contrasena-input">Contraseña</Form.Label>
                  <Form.Control
                    id="contrasena-input"
                    type="password"
                    name="contrasena"
                    value={credentials.contrasena}
                    onChange={handleChange}
                    required
                    aria-describedby="contrasena-help"
                  />
                  <div id="contrasena-help" className="form-text">
                    Ingresa tu contraseña de acceso.
                  </div>
                </Form.Group>
                
                <div className="d-grid">
                  <Button 
                    variant="primary" 
                    type="submit" 
                    disabled={loading}
                    className="py-2"
                    aria-label={loading ? 'Iniciando sesión, por favor espere' : 'Iniciar sesión'}
                  >
                    {loading ? 'Iniciando sesión...' : 'Iniciar Sesión'}
                  </Button>
                </div>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default Login;