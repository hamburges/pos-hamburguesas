// src/pages/cajero/ventas/ProcesarPago.js
import React, { useState, useEffect, useMemo } from 'react';
import ventaService from '../../../services/ventaService';

// Interfaces abstractas para garantizar el principio de inversión de dependencias
/**
 * @interface IReconciliadorFinanciero
 * Interfaz para el sistema de reconciliación financiera
 */
// IReconciliadorFinanciero { reconciliar(pagos, totalRequerido, cambioConfirmado) => pagosReconciliados }

/**
 * @interface IGestorEstadoTransaccion
 * Interfaz para la gestión del ciclo de vida de la transacción
 */
// IGestorEstadoTransaccion { actualizarEstado(estadoActual, evento) => nuevoEstado }

const ProcesarPago = (props) => {
  // Si props es undefined, asignar un objeto vacío
  const safeProps = props || {};
  
  // Estado del sistema de pago - Single Responsibility Principle
  const [metodoActual, setMetodoActual] = useState('efectivo');
  const [pagosPorMetodo, setPagosPorMetodo] = useState([]);
  const [montoActual, setMontoActual] = useState('');
  const [referenciaActual, setReferenciaActual] = useState('');
  
  // Estado del sistema de cambio - Single Responsibility Principle
  const [cambio, setCambio] = useState(0);
  const [cambioConfirmado, setCambioConfirmado] = useState(true);
  
  // Estado general del componente - Single Responsibility Principle
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [paraLlevar, setParaLlevar] = useState(false);
  const [cliente, setCliente] = useState({
    nombre: '',
    identificacion: '',
    telefono: ''
  });
  const [notas, setNotas] = useState('');

  // Extraer props con valores por defecto de forma segura - Principio de Robustez
  const carrito = useMemo(() => safeProps.carrito || [], [safeProps.carrito]);
  const totalCarrito = safeProps.total || 0;
  const sucursal = safeProps.sucursal || null;
  const cajero = safeProps.cajero || null;
  const ciclo_caja = safeProps.ciclo_caja || null;
  const onPagoCompleto = safeProps.onPagoCompleto || (() => {});
  const onCancel = safeProps.onCancel || (() => {});

  // Servicio de reconciliación financiera - Open/Closed Principle
  const reconciliadorFinanciero = {
    /**
     * Ajusta los pagos para que coincidan exactamente con el monto requerido
     * cuando se confirma la entrega del cambio
     * 
     * @param {Array} pagos - Lista de pagos registrados
     * @param {Number} totalRequerido - Total que debe pagarse
     * @param {Boolean} confirmado - Si el cambio ha sido confirmado
     * @returns {Object} - Valores reconciliados
     */
    reconciliar: (pagos, totalRequerido, confirmado) => {
      // Cálculo estándar sin reconciliación
      const totalBruto = pagos.reduce((sum, item) => sum + parseFloat(item.monto || 0), 0);
      
      // Pagos de efectivo para cálculo de cambio
      const pagosEfectivo = pagos
        .filter(p => p.metodo === 'efectivo')
        .reduce((sum, p) => sum + parseFloat(p.monto || 0), 0);
      
      // Cálculo del cambio bruto
      const cambioBruto = Math.max(0, pagosEfectivo - totalRequerido);
      
      // Preparar pagos reconciliados - copia profunda para evitar mutaciones
      let pagosReconciliados = [...pagos];
      
      // Si hay cambio y está confirmado, ajustamos los pagos en efectivo
      if (confirmado && cambioBruto > 0) {
        // Verificar si hay pagos en efectivo
        const indexEfectivo = pagos.findIndex(p => p.metodo === 'efectivo');
        
        if (indexEfectivo !== -1) {
          // Crear copia profunda
          pagosReconciliados = [...pagos];
          
          // Ajustar el monto del pago en efectivo
          pagosReconciliados[indexEfectivo] = {
            ...pagosReconciliados[indexEfectivo],
            monto_original: pagosReconciliados[indexEfectivo].monto, // Preservar valor original
            monto: totalRequerido // Ajustar exactamente al valor requerido
          };
        }
      }
      
      // Calcular totales con pagos reconciliados
      const totalReconciliado = pagosReconciliados.reduce(
        (sum, item) => sum + parseFloat(item.monto || 0), 0
      );
      
      // Saldo pendiente basado en valores reconciliados
      const saldoPendienteReconciliado = Math.max(0, totalRequerido - totalReconciliado);
      
      return {
        pagosReconciliados,
        totalReconciliado: confirmado && cambioBruto > 0 ? totalRequerido : totalBruto,
        cambio: cambioBruto,
        saldoPendiente: saldoPendienteReconciliado,
        esPagoMixto: pagos.length > 1
      };
    }
  };
  
  // Obtener valores reconciliados - Dependency Inversion Principle
  const { 
    pagosReconciliados, 
    totalReconciliado, 
    cambio: cambioCalculado, 
    saldoPendiente, 
    esPagoMixto 
  } = reconciliadorFinanciero.reconciliar(pagosPorMetodo, totalCarrito, cambioConfirmado);
  
  // Sincronizar cambio calculado con estado
  useEffect(() => {
    if (cambioCalculado !== cambio) {
      setCambio(cambioCalculado);
      // Auto-confirmar solo si no hay cambio
      if (cambioCalculado === 0) {
        setCambioConfirmado(true);
      } else if (cambio === 0) {
        // Solo cambia a false si estamos pasando de sin cambio a con cambio
        setCambioConfirmado(false);
      }
    }
  }, [cambioCalculado, cambio]);

  // Efecto de sincronización de pagosPorMetodo - evita actualizaciones ineficientes
  useEffect(() => {
    // Solo actualizar si hay diferencias sustanciales
    if (cambioConfirmado && cambio > 0 && pagosPorMetodo.some(p => p.metodo === 'efectivo')) {
      // Actualizar los pagos reconciliados
      setPagosPorMetodo(pagosReconciliados);
    }
  }, [cambioConfirmado, cambio, pagosPorMetodo, pagosReconciliados]);

  // Cálculo reactivo para cambio inmediato en formulario de efectivo
  const cambioInmediato = metodoActual === 'efectivo' && montoActual 
    ? Math.max(0, parseFloat(montoActual || 0) - Math.max(0, saldoPendiente))
    : 0;
  
  useEffect(() => {
    console.log("ProcesarPago montado con props:", { carrito, totalCarrito, sucursal, cajero, ciclo_caja });
    
    // Verificar propiedades necesarias
    if (!cajero || !sucursal) {
      console.warn('ProcesarPago: Faltan datos obligatorios', { cajero, sucursal });
    }
  }, [carrito, totalCarrito, sucursal, cajero, ciclo_caja]);

  // Servicio de formateo monetario - Single Responsibility Principle
  const formateador = {
    /**
     * Formatea un valor numérico como moneda
     * 
     * @param {Number} amount - Cantidad a formatear
     * @returns {String} - Representación formateada
     */
    formatearMoneda: (amount) => {
      try {
        if (amount === undefined || amount === null) return "$0";
        return "$" + (Math.round(amount * 100) / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      } catch (error) {
        console.error("Error en formatMoney:", error);
        return "$0";
      }
    }
  };

  // Servicios de validación - Single Responsibility Principle
  const validador = {
    /**
     * Valida que el monto sea correcto para el método de pago
     * 
     * @param {String} metodo - Método de pago
     * @param {String} monto - Monto a validar
     * @param {String} referencia - Referencia para métodos electrónicos
     * @param {Number} saldoPendiente - Saldo pendiente actual
     * @returns {Object} - Resultado de validación
     */
    validarMetodoPago: (metodo, monto, referencia, saldoPendiente) => {
      // Validar que el monto sea válido
      if (!monto || parseFloat(monto) <= 0) {
        return { 
          valido: false, 
          mensaje: 'Debe ingresar un monto válido mayor a cero'
        };
      }
      
      // Validar referencia para métodos electrónicos
      if ((metodo === 'nequi' || metodo === 'daviplata' || metodo === 'transferencia') 
          && !referencia) {
        return { 
          valido: false, 
          mensaje: 'Debe ingresar una referencia para este método de pago'
        };
      }
      
      // Para métodos no-efectivo, verificar que no exceda el saldo pendiente
      const montoFloat = parseFloat(monto);
      if (montoFloat > saldoPendiente && saldoPendiente > 0 && metodo !== 'efectivo') {
        return { 
          valido: false, 
          mensaje: 'El monto excede el saldo pendiente',
          ajuste: saldoPendiente.toString()
        };
      }
      
      return { valido: true };
    }
  };

  // Agregar un método de pago a la lista - Single Responsibility Principle
  const agregarMetodoPago = () => {
    // Utilizar el servicio de validación
    const resultadoValidacion = validador.validarMetodoPago(
      metodoActual, 
      montoActual, 
      referenciaActual, 
      saldoPendiente
    );
    
    if (!resultadoValidacion.valido) {
      if (resultadoValidacion.ajuste) {
        setMontoActual(resultadoValidacion.ajuste);
      }
      setError(resultadoValidacion.mensaje);
      return;
    }
    
    // Agregar el pago a la lista
    setPagosPorMetodo([
      ...pagosPorMetodo,
      {
        metodo: metodoActual,
        monto: parseFloat(montoActual),
        referencia: referenciaActual || ''
      }
    ]);
    
    // Limpiar los campos
    setMontoActual('');
    setReferenciaActual('');
    
    // Limpiar cualquier error
    setError(null);
  };

  // Eliminar un método de pago - Single Responsibility Principle
  const eliminarMetodoPago = (index) => {
    const metodosActualizados = pagosPorMetodo.filter((_, i) => i !== index);
    setPagosPorMetodo(metodosActualizados);
    
    // Verificar si hemos eliminado todos los pagos en efectivo
    const hayPagosEfectivo = metodosActualizados.some(p => p.metodo === 'efectivo');
    if (!hayPagosEfectivo) {
      // Si no hay pagos en efectivo, no hay cambio para confirmar
      setCambioConfirmado(true);
    }
  };

  // Confirmar entrega de cambio - Single Responsibility Principle
  const confirmarCambioEntregado = () => {
    setCambioConfirmado(true);
  };

  const handleClienteChange = (e) => {
    const { name, value } = e.target;
    setCliente(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Proceso de envío de formulario - Single Responsibility Principle
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validar que haya al menos un método de pago
    if (pagosPorMetodo.length === 0) {
      setError('Debe agregar al menos un método de pago');
      return;
    }
    
    // Validar que se haya confirmado el cambio si hay pagos en efectivo y cambio > 0
    if (!cambioConfirmado && cambio > 0) {
      setError('Debe confirmar que ha entregado el cambio al cliente');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      // Verificar datos obligatorios
      if (!cajero) {
        setError('Error: Datos del cajero no disponibles');
        setLoading(false);
        return;
      }
      
      if (!sucursal) {
        setError('Error: Datos de la sucursal no disponibles');
        setLoading(false);
        return;
      }

      // Obtener IDs con manejo seguro
      const cajeroId = cajero?.id || cajero?._id;
      let sucursalId;
      
      if (typeof sucursal === 'string') {
        sucursalId = sucursal;
      } else {
        sucursalId = sucursal?._id;
      }

      if (!cajeroId || !sucursalId) {
        setError('Error: No se pueden obtener los identificadores necesarios');
        console.error("Error en IDs:", { cajeroId, sucursalId, cajero, sucursal });
        setLoading(false);
        return;
      }
      
      // Preparar datos de productos con manejo seguro
      const productosData = Array.isArray(carrito) ? carrito.map(item => {
        if (!item || !item.producto) {
          console.warn("Elemento de carrito inválido:", item);
          return null;
        }
        
        return {
          producto: item.producto._id,
          cantidad: item.cantidad || 1,
          precio_unitario: item.precio_unitario || 0,
          personalizaciones: Array.isArray(item.personalizaciones) 
            ? item.personalizaciones
                .filter(p => p && p.ingrediente)
                .map(p => ({
                  ingrediente: p.ingrediente._id,
                  accion: p.accion || 'agregar',
                  cantidad: p.cantidad || 1,
                  precio: p.precio || 0
                }))
            : [],
          subtotal: item.subtotal || 0
        };
      }).filter(item => item !== null) : [];
      
      // Determinar el método de pago principal para el campo metodo_pago
      const metodoPrincipal = esPagoMixto ? 'mixto' : pagosPorMetodo[0]?.metodo || 'efectivo';
      
      // Usar la estructura reconciliada para detalles_pago
      // Los pagos ya están reconciliados gracias al sistema de reconciliación
      const ventaData = {
        cajero: cajeroId,
        sucursal: sucursalId,
        ciclo_caja: ciclo_caja,
        productos: productosData,
        metodo_pago: metodoPrincipal,
        detalles_pago: {
          montos_por_metodo: pagosReconciliados.map(pago => ({
            metodo: pago.metodo,
            monto: parseFloat(pago.monto),
            monto_original: pago.monto_original ? parseFloat(pago.monto_original) : undefined,
            referencia: pago.referencia || ''
          })),
          cambio: cambio || 0
        },
        para_llevar: paraLlevar,
        cliente: {
          nombre: cliente.nombre || '',
          identificacion: cliente.identificacion || '',
          telefono: cliente.telefono || ''
        },
        notas: notas || ''
      };

      console.log("Enviando datos de venta:", ventaData);
      const response = await ventaService.crearVenta(ventaData);
      
      onPagoCompleto(response);
    } catch (error) {
      console.error('Error al procesar el pago:', error);
      setError(error.response?.data?.message || 'Ocurrió un error al procesar el pago. Por favor intente nuevamente.');
    } finally {
      setLoading(false);
    }
  };

  // Verificar si hay pagos con efectivo que tengan cambio pendiente
  const hayCambioPendiente = cambio > 0 && !cambioConfirmado;
  
  // Determinar si se puede completar el pago
  const puedeCompletarPago = !loading && saldoPendiente <= 0 && (!hayCambioPendiente);

  return (
    <div className="modal-overlay" 
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1050
      }}>
      <div className="modal-dialog" 
        style={{
          maxWidth: '600px',
          width: '100%',
          margin: 0,
          backgroundColor: 'white',
          borderRadius: '8px',
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
          maxHeight: '90vh',
          display: 'flex',
          flexDirection: 'column'
        }}>
        
        <div className="modal-content" style={{ 
          display: 'flex', 
          flexDirection: 'column',
          height: '100%',
          overflow: 'hidden'
        }}>
          <div className="modal-header bg-primary text-white" style={{ 
            flex: '0 0 auto'
          }}>
            <h5 className="modal-title">Procesar Pago</h5>
            <button type="button" className="btn-close btn-close-white" onClick={onCancel}></button>
          </div>
          
          <form onSubmit={handleSubmit} style={{ 
            display: 'flex', 
            flexDirection: 'column',
            height: '100%', 
            overflow: 'hidden'
          }}>
            {/* Área de información crítica (siempre visible) */}
            <div style={{ 
              padding: '15px', 
              flex: '0 0 auto',
              borderBottom: '1px solid #dee2e6'
            }}>
              {error && <div className="alert alert-danger">{error}</div>}
              
              <div className="d-flex justify-content-between">
                <div>
                  <label className="form-label fw-bold">Total a Pagar:</label>
                  <h3 className="text-primary">{formateador.formatearMoneda(totalCarrito)}</h3>
                </div>
                
                {pagosPorMetodo.length > 0 && (
                  <div>
                    <label className="form-label">Total Pagado:</label>
                    <h3 className={totalReconciliado >= totalCarrito ? 'text-success' : 'text-danger'}>
                      {formateador.formatearMoneda(totalReconciliado)}
                    </h3>
                  </div>
                )}
              </div>
              
              {/* Sistema unificado de notificación de cambio */}
              {cambio > 0 && (
                <div className={`alert ${cambioConfirmado ? 'alert-success' : 'alert-danger'} mt-2 mb-0`}>
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <strong>Cambio a entregar:</strong> {formateador.formatearMoneda(cambio)}
                    </div>
                    {!cambioConfirmado && (
                      <button 
                        type="button" 
                        className="btn btn-sm btn-light"
                        onClick={confirmarCambioEntregado}
                      >
                        Confirmar Entrega
                      </button>
                    )}
                  </div>
                </div>
              )}
              
              {saldoPendiente > 0 && (
                <div className="alert alert-warning mt-2 mb-0">
                  <strong>Saldo pendiente:</strong> {formateador.formatearMoneda(saldoPendiente)}
                </div>
              )}
            </div>
            
            {/* Cuerpo con scroll */}
            <div className="modal-body" style={{ 
              flex: '1 1 auto',
              overflowY: 'auto',
              padding: '15px'
            }}>
              {/* Lista de métodos de pago agregados */}
              {pagosPorMetodo.length > 0 && (
                <div className="mb-3">
                  <h6>Pagos registrados:</h6>
                  <div className="table-responsive">
                    <table className="table table-sm table-bordered">
                      <thead className="table-light">
                        <tr>
                          <th>Método</th>
                          <th>Monto</th>
                          <th>Referencia</th>
                          <th>Acción</th>
                        </tr>
                      </thead>
                      <tbody>
                        {pagosPorMetodo.map((pago, index) => (
                          <tr key={index}>
                            <td>{pago.metodo.charAt(0).toUpperCase() + pago.metodo.slice(1)}</td>
                            <td>{formateador.formatearMoneda(pago.monto)}</td>
                            <td>{pago.referencia}</td>
                            <td>
                              <button 
                                type="button" 
                                className="btn btn-sm btn-danger"
                                onClick={() => eliminarMetodoPago(index)}
                              >
                                Eliminar
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
              
              {/* Agregar nuevo método de pago */}
              <div className="mb-3 p-3 border rounded">
                <h6>Agregar método de pago:</h6>
                <div className="row g-2">
                  <div className="col-md-5">
                    <label htmlFor="metodoActual" className="form-label">Método:</label>
                    <select 
                      id="metodoActual"
                      name="metodoActual"
                      className="form-select" 
                      value={metodoActual} 
                      onChange={(e) => setMetodoActual(e.target.value)}
                    >
                      <option value="efectivo">Efectivo</option>
                      <option value="nequi">Nequi</option>
                      <option value="daviplata">Daviplata</option>
                      <option value="transferencia">Transferencia</option>
                    </select>
                  </div>
                  
                  <div className="col-md-7">
                    <label htmlFor="montoActual" className="form-label">Monto:</label>
                    <div className="input-group">
                      <span className="input-group-text">$</span>
                      <input 
                        type="number" 
                        className="form-control" 
                        id="montoActual"
                        name="montoActual"
                        value={montoActual} 
                        onChange={(e) => setMontoActual(e.target.value)}
                        min="0"
                        step="100"
                        placeholder={saldoPendiente > 0 ? saldoPendiente.toString() : ""}
                      />
                    </div>
                  </div>
                  
                  {/* Visualizador de cambio inmediato para efectivo */}
                  {metodoActual === 'efectivo' && montoActual && parseFloat(montoActual) > 0 && (
                    <div className="col-12">
                      <div className={`mt-2 p-2 rounded text-center ${cambioInmediato > 0 ? 'bg-success text-white' : ''}`}>
                        {cambioInmediato > 0 
                          ? <strong>Cambio a dar: {formateador.formatearMoneda(cambioInmediato)}</strong>
                          : 'Introduzca un valor mayor al saldo pendiente para calcular el cambio'
                        }
                      </div>
                    </div>
                  )}
                  
                  {(metodoActual === 'nequi' || metodoActual === 'daviplata' || metodoActual === 'transferencia') && (
                    <div className="col-12">
                      <label htmlFor="referenciaActual" className="form-label">Referencia:</label>
                      <input 
                        type="text" 
                        className="form-control" 
                        id="referenciaActual"
                        name="referenciaActual"
                        value={referenciaActual} 
                        onChange={(e) => setReferenciaActual(e.target.value)}
                        placeholder="Número de transacción o referencia"
                      />
                    </div>
                  )}
                  
                  <div className="col-12 mt-2">
                    <button 
                      type="button" 
                      className="btn btn-success"
                      onClick={agregarMetodoPago}
                    >
                      Agregar Pago
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="mb-3 form-check">
                <input 
                  type="checkbox" 
                  className="form-check-input" 
                  id="paraLlevar"
                  name="paraLlevar"
                  checked={paraLlevar} 
                  onChange={(e) => setParaLlevar(e.target.checked)}
                />
                <label className="form-check-label" htmlFor="paraLlevar">Para llevar</label>
              </div>
              
              <div className="mb-3">
                <h6>Datos del Cliente (Opcional):</h6>
                <div className="row g-2">
                  <div className="col-md-6">
                    <label htmlFor="nombreCliente" className="form-label">Nombre:</label>
                    <input 
                      type="text" 
                      className="form-control" 
                      id="nombreCliente"
                      name="nombre"
                      value={cliente.nombre} 
                      onChange={handleClienteChange}
                    />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="identificacionCliente" className="form-label">Identificación:</label>
                    <input 
                      type="text" 
                      className="form-control" 
                      id="identificacionCliente"
                      name="identificacion"
                      value={cliente.identificacion} 
                      onChange={handleClienteChange}
                    />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="telefonoCliente" className="form-label">Teléfono:</label>
                    <input 
                      type="text" 
                      className="form-control" 
                      id="telefonoCliente"
                      name="telefono"
                      value={cliente.telefono} 
                      onChange={handleClienteChange}
                    />
                  </div>
                </div>
              </div>
              
              <div className="mb-3">
                <label htmlFor="notas" className="form-label">Notas adicionales:</label>
                <textarea 
                  className="form-control" 
                  id="notas"
                  name="notas"
                  value={notas} 
                  onChange={(e) => setNotas(e.target.value)}
                  rows="2"
                ></textarea>
              </div>
            </div>
            
            {/* Footer siempre visible con botones de acción */}
            <div className="modal-footer" style={{ 
              flex: '0 0 auto',
              borderTop: '1px solid #dee2e6',
              padding: '15px',
              backgroundColor: '#f8f9fa'
            }}>
              <button type="button" className="btn btn-secondary" onClick={onCancel}>
                Cancelar
              </button>
              <button 
                type="submit" 
                className="btn btn-primary" 
                disabled={!puedeCompletarPago}
              >
          {loading ? 'Procesando...' : hayCambioPendiente ? 'Confirmar cambio para continuar' : 'Completar Pago'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ProcesarPago;