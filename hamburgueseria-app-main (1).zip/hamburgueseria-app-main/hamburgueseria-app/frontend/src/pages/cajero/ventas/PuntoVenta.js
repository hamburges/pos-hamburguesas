// src/pages/cajero/ventas/PuntoVenta.js
import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../../context/AuthContext';
import CajeroLayout from '../../../components/layout/CajeroLayout';
import productoService from '../../../services/productoService';
import categoriaService from '../../../services/categoriaService';
import ventaService from '../../../services/ventaService';
import cajaService from '../../../services/cajaService';
import PersonalizarProducto from './PersonalizarProducto';
import ProcesarPago from './ProcesarPago';
import opcionProductoService from '../../../services/opcionProductoService';

const PuntoVenta = () => {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  
  // Estados para verificar la caja
  const [cajaAbierta, setCajaAbierta] = useState(false);
  const [verificandoCaja, setVerificandoCaja] = useState(true);
  const [cicloActual, setCicloActual] = useState(null); // Estado para almacenar el ciclo actual
  
  // Estados para gestionar categorías y productos
  const [categorias, setCategorias] = useState([]);
  const [productos, setProductos] = useState([]);
  const [categoriaSeleccionada, setCategoriaSeleccionada] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Estados para el carrito
  const [carrito, setCarrito] = useState([]);
  const [totalCarrito, setTotalCarrito] = useState(0);
  
  // Estados para modales
  const [productoPersonalizar, setProductoPersonalizar] = useState(null);
  const [showPersonalizarModal, setShowPersonalizarModal] = useState(false);
  const [mostrarProcesarPago, setMostrarProcesarPago] = useState(false);

  // Verificar si hay un ciclo de caja abierto
  useEffect(() => {
    const verificarCiclo = async () => {
      try {
        setVerificandoCaja(true);
        const respuesta = await cajaService.obtenerCajaActual();
        
        if (respuesta.success) {
          setCajaAbierta(true);
          setCicloActual(respuesta.data); // Guardar datos del ciclo actual
          console.log("Ciclo de caja activo:", respuesta.data);
        } else {
          setCajaAbierta(false);
          setCicloActual(null);
        }
      } catch (error) {
        if (error.response && error.response.status === 404) {
          // No hay ciclo abierto
          setCajaAbierta(false);
          setCicloActual(null);
          // Redirigir a apertura de caja
          navigate('/cajero/caja/apertura');
        } else {
          console.error('Error al verificar el ciclo de caja:', error);
          setCajaAbierta(false);
          setCicloActual(null);
        }
      } finally {
        setVerificandoCaja(false);
      }
    };
    
    verificarCiclo();
  }, [navigate]);
  
  // Solo cargar las categorías si hay un ciclo abierto
  useEffect(() => {
    if (cajaAbierta) {
      const cargarCategorias = async () => {
        try {
          setLoading(true);
          const response = await categoriaService.obtenerTodas();
          setCategorias(response.data);
          
          // Seleccionar primera categoría por defecto
          if (response.data.length > 0) {
            setCategoriaSeleccionada(response.data[0]._id);
          }
          
          setLoading(false);
        } catch (error) {
          console.error('Error al cargar categorías:', error);
          setError('Error al cargar las categorías');
          setLoading(false);
        }
      };
      
      cargarCategorias();
    }
  }, [cajaAbierta]);
  
  // Cargar productos al cambiar la categoría seleccionada
  useEffect(() => {
    const cargarProductos = async () => {
      if (!categoriaSeleccionada) return;
      
      try {
        setLoading(true);
        
        // Obtener productos por categoría
        const filtros = { categoria: categoriaSeleccionada, disponible: true };
        const response = await productoService.obtenerTodos(filtros);
        
        // Añadir propiedad tieneOpciones a cada producto
        const productosConOpciones = await Promise.all(
          response.data.map(async (producto) => {
            try {
              const opcionesResp = await opcionProductoService.obtenerOpcionesPorProducto(producto._id);
              return {
                ...producto,
                tieneOpciones: opcionesResp.data && opcionesResp.data.length > 0
              };
            } catch (error) {
              console.error(`Error al cargar opciones para producto ${producto._id}:`, error);
              return {
                ...producto,
                tieneOpciones: false
              };
            }
          })
        );
        
        setProductos(productosConOpciones);
        setLoading(false);
      } catch (error) {
        console.error('Error al cargar productos:', error);
        setError('Error al cargar los productos');
        setLoading(false);
      }
    };
      
    cargarProductos();
  }, [categoriaSeleccionada]);

  // Calcular total del carrito cuando cambia
  useEffect(() => {
    const total = carrito.reduce((sum, item) => sum + item.subtotal, 0);
    setTotalCarrito(total);
  }, [carrito]);

  // Función para manejar selección de categoría
  const handleCategoriaClick = (categoriaId) => {
    setCategoriaSeleccionada(categoriaId);
  };
  
  // Función para agregar al carrito
  const agregarAlCarrito = (producto) => {
    // Para productos con opciones personalizables
    if (producto.tieneOpciones) {
      setProductoPersonalizar(producto);
      setShowPersonalizarModal(true);
      return;
    }
    
    // Para productos sin opciones
    const productoEnCarrito = carrito.find(item => 
      item.producto._id === producto._id && 
      (!item.personalizaciones || item.personalizaciones.length === 0)
    );
    
    if (productoEnCarrito) {
      // Si ya existe, aumentar cantidad
      setCarrito(carrito.map(item => 
        item.producto._id === producto._id && 
        (!item.personalizaciones || item.personalizaciones.length === 0)
          ? { 
              ...item, 
              cantidad: item.cantidad + 1, 
              subtotal: (item.cantidad + 1) * item.precio_unitario 
            } 
          : item
      ));
    } else {
      // Si no existe, añadirlo con cantidad 1
      setCarrito([...carrito, {
        producto: producto,
        cantidad: 1,
        precio_unitario: producto.precio_base,
        personalizaciones: [],
        subtotal: producto.precio_base
      }]);
    }
  };
  
  // Función para agregar producto personalizado
  const agregarProductoPersonalizado = (productoPersonalizado) => {
    setCarrito([...carrito, productoPersonalizado]);
    setShowPersonalizarModal(false);
    setProductoPersonalizar(null);
  };
  
  // Función para eliminar producto del carrito
  const eliminarDelCarrito = (index) => {
    setCarrito(carrito.filter((_, i) => i !== index));
  };
  
  // Función para actualizar cantidad de un producto
  const actualizarCantidad = (index, cantidad) => {
    if (cantidad < 1) return;
    
    setCarrito(carrito.map((item, i) => 
      i === index 
        ? { 
            ...item, 
            cantidad: cantidad,
            subtotal: cantidad * item.precio_unitario
          } 
        : item
    ));
  };
  
  // Función para limpiar el carrito
  const limpiarCarrito = () => {
    setCarrito([]);
  };
  
  // Función para finalizar la compra
  const finalizarCompra = () => {
    if (carrito.length === 0) {
      alert('El carrito está vacío');
      return;
    }
    
    setMostrarProcesarPago(true);
  };
  
  // Función para manejar el pago completado
  const handlePagoCompleto = (ventaData) => {
    // Limpiar carrito
    setCarrito([]);
    // Cerrar modal de pago
    setMostrarProcesarPago(false);
    
    // Mostrar mensaje de éxito
    alert(`Venta completada exitosamente. Número de venta: ${ventaData.data.numero_venta}`);
  };

  // Renderizado condicional si no hay ciclo de caja abierto
  if (verificandoCaja) {
    return (
      <CajeroLayout>
        <div className="container text-center my-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Verificando estado del ciclo de caja...</span>
          </div>
          <p className="mt-3">Verificando estado del ciclo de caja...</p>
        </div>
      </CajeroLayout>
    );
  }
  
  if (!cajaAbierta) {
    return (
      <CajeroLayout>
        <div className="container my-5">
          <div className="alert alert-warning">
            <h4 className="alert-heading">No hay un ciclo de caja abierto</h4>
            <p>
              Para realizar ventas, primero debes abrir un ciclo de caja.
            </p>
            <hr />
            <div className="d-flex justify-content-end">
              <button 
                className="btn btn-primary"
                onClick={() => navigate('/cajero/caja/apertura')}
              >
                Ir a Apertura de Ciclo
              </button>
            </div>
          </div>
        </div>
      </CajeroLayout>
    );
  }

  return (
    <CajeroLayout>
      <div className="container-fluid my-3">
        {/* Si hay ciclo activo, mostrar información básica */}
        {cicloActual && (
          <div className="alert alert-info d-flex justify-content-between align-items-center mb-3">
            <div>
              <strong>Ciclo de caja activo</strong> • Abierto: {new Date(cicloActual.fecha_apertura).toLocaleString()}
            </div>
            <button 
              className="btn btn-sm btn-outline-primary"
              onClick={() => navigate('/cajero/caja/cierre')}
            >
              Cerrar Ciclo
            </button>
          </div>
        )}
        
        <div className="row">
          {/* Columna izquierda - Categorías y Productos */}
          <div className="col-md-8">
            <div className="card mb-3">
              <div className="card-header bg-primary text-white">
                <h5 className="mb-0">Categorías</h5>
              </div>
              <div className="card-body">
                {loading && categorias.length === 0 ? (
                  <div className="text-center">
                    <div className="spinner-border text-primary" role="status">
                      <span className="visually-hidden">Cargando...</span>
                    </div>
                  </div>
                ) : (
                  <div className="d-flex flex-wrap gap-2">
                    {categorias.map(categoria => (
                      <button
                        key={categoria._id}
                        className={`btn ${categoriaSeleccionada === categoria._id ? 'btn-primary' : 'btn-outline-primary'}`}
                        onClick={() => handleCategoriaClick(categoria._id)}
                      >
                        {categoria.nombre}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="card">
              <div className="card-header bg-info text-white">
                <h5 className="mb-0">Productos</h5>
              </div>
              <div className="card-body">
                {loading && productos.length === 0 ? (
                  <div className="text-center">
                    <div className="spinner-border text-info" role="status">
                      <span className="visually-hidden">Cargando...</span>
                    </div>
                  </div>
                ) : productos.length === 0 ? (
                  <div className="alert alert-info">
                    No hay productos disponibles en esta categoría
                  </div>
                ) : (
                  <div className="row row-cols-1 row-cols-md-3 g-3">
                    {productos.map(producto => (
                      <div key={producto._id} className="col">
                        <div className="card h-100">
                          <div className="card-body text-center">
                            <h5 className="card-title">{producto.nombre}</h5>
                            <p className="card-text text-muted">
                              {producto.descripcion && producto.descripcion.length > 60
                                ? `${producto.descripcion.substring(0, 60)}...`
                                : producto.descripcion}
                            </p>
                            <div className="fs-4 mb-3">${producto.precio_base.toLocaleString()}</div>
                            <button 
                              className="btn btn-success w-100"
                              onClick={() => agregarAlCarrito(producto)}
                            >
                              Agregar {producto.tieneOpciones && <span>⚙️</span>}
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Columna derecha - Carrito y Pago */}
          <div className="col-md-4">
            <div className="card">
              <div className="card-header bg-success text-white">
                <h5 className="mb-0">Carrito de Compra</h5>
              </div>
              <div className="card-body">
                {carrito.length === 0 ? (
                  <div className="alert alert-info">
                    No hay productos en el carrito
                  </div>
                ) : (
                  <div className="cart-items">
                    {carrito.map((item, index) => (
                      <div key={index} className="cart-item border-bottom py-2">
                        <div className="d-flex justify-content-between">
                          <h6>{item.producto.nombre}</h6>
                          <button 
                            className="btn btn-sm btn-danger"
                            onClick={() => eliminarDelCarrito(index)}
                          >
                            <i className="bi bi-trash"></i>
                          </button>
                        </div>
                        <div className="d-flex justify-content-between align-items-center mt-2">
                          <div className="input-group input-group-sm" style={{ width: '120px' }}>
                            <button 
                              className="btn btn-outline-secondary" 
                              type="button"
                              onClick={() => actualizarCantidad(index, item.cantidad - 1)}
                            >
                              -
                            </button>
                            <input 
                              type="number" 
                              className="form-control text-center" 
                              value={item.cantidad} 
                              readOnly
                              id={`cantidad-${index}`}
                              name={`cantidad-${index}`}
                            />
                            <button 
                              className="btn btn-outline-secondary" 
                              type="button"
                              onClick={() => actualizarCantidad(index, item.cantidad + 1)}
                            >
                              +
                            </button>
                          </div>
                          <div className="price">
                            ${item.subtotal.toLocaleString()}
                          </div>
                        </div>
                        {item.personalizaciones && item.personalizaciones.length > 0 && (
                          <div className="personalizations mt-1 small text-muted">
                            {item.personalizaciones.map((p, i) => (
                              <div key={i}>
                                {p.accion === 'agregar' ? '+' : '-'} {p.ingrediente?.nombre || 'Ingrediente'} x{p.cantidad}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                    
                    <div className="total mt-3">
                      <div className="d-flex justify-content-between">
                        <h5>Total:</h5>
                        <h5>${totalCarrito.toLocaleString()}</h5>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <div className="card-footer">
                <div className="d-grid gap-2">
                  <button 
                    className="btn btn-primary"
                    disabled={carrito.length === 0}
                    onClick={finalizarCompra}
                  >
                    Procesar Pago
                  </button>
                  <button 
                    className="btn btn-outline-secondary"
                    disabled={carrito.length === 0}
                    onClick={limpiarCarrito}
                  >
                    Vaciar Carrito
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Modal de personalización */}
      {showPersonalizarModal && productoPersonalizar && (
        <PersonalizarProducto 
          show={showPersonalizarModal}
          onHide={() => setShowPersonalizarModal(false)}
          producto={productoPersonalizar}
          agregarAlCarrito={agregarProductoPersonalizado}
        />
      )}
      
      {/* Modal de procesamiento de pago - Añadido ciclo_caja */}
      {mostrarProcesarPago && (
        <ProcesarPago
          carrito={carrito || []}
          total={totalCarrito || 0}
          sucursal={user?.sucursal}
          cajero={user}
          ciclo_caja={cicloActual?._id} // Pasamos el ID del ciclo de caja
          onPagoCompleto={handlePagoCompleto}
          onCancel={() => setMostrarProcesarPago(false)}
        />
      )}
    </CajeroLayout>
  );
};

export default PuntoVenta;