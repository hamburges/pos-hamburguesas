// src/pages/cajero/ventas/FacturaVenta.js
import React, { useRef } from 'react';
import { formatearFecha } from '../../../utils/formatters';
import html2pdf from 'html2pdf.js';

const FacturaVenta = ({ venta, onClose }) => {
  const facturaRef = useRef(null);

  // Función para generar PDF y mostrarlo en una ventana para imprimir
  const generarPDF = () => {
    // Opciones para el PDF
    const opciones = {
      margin: [5, 5, 5, 5], // top, right, bottom, left - márgenes pequeños
      filename: `Factura-${venta.numero_venta}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { 
        unit: 'mm', 
        format: [100, 400], // Aumentado el ancho a 100mm para evitar cortes
        orientation: 'portrait'
      },
      // Importante: outputPdf abre una vista previa en lugar de descargar
      output: 'dataurlnewwindow'
    };

    // Elemento a convertir
    const elemento = facturaRef.current;

    // Generar PDF y abrir en nueva ventana en lugar de descargar
    html2pdf().from(elemento).set(opciones).toPdf().output('dataurlnewwindow');
  };

  if (!venta) return null;

  return (
    <div className="modal-backdrop" style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1050
    }}>
      <div className="modal-factura bg-white shadow" style={{
        width: '80%',
        maxWidth: '600px',
        maxHeight: '90vh',
        overflowY: 'auto',
        padding: '20px',
        borderRadius: '8px'
      }}>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h5 className="mb-0">Factura: {venta.numero_venta}</h5>
          <div>
            <button 
              className="btn btn-outline-secondary me-2" 
              onClick={onClose}
            >
              Cerrar
            </button>
            <button 
              className="btn btn-primary"
              onClick={generarPDF}
            >
              <i className="bi bi-printer me-1"></i> Vista previa impresión
            </button>
          </div>
        </div>

        {/* Contenido a convertir en PDF - Ajustado para mejor formato */}
        <div className="factura-content p-3 border" ref={facturaRef} style={{
          backgroundColor: 'white',
          width: '90mm', // Ancho ligeramente aumentado
          margin: '0 auto', // Centrar en la pantalla
          padding: '5mm',   // Padding interno
          boxSizing: 'border-box'
        }}>
          <div className="text-center mb-3">
            <h3 className="fw-bold mb-1" style={{ fontSize: '14pt' }}>JQ Q BERRAQUERA</h3>
            <p className="mb-0" style={{ fontSize: '9pt' }}>NIT: (Pendiente)</p>
            <p className="mb-0" style={{ fontSize: '9pt' }}>{venta.sucursal?.nombre || 'Sucursal Principal'}</p>
            <p className="mb-0" style={{ fontSize: '9pt' }}>{venta.sucursal?.direccion || 'Dirección pendiente'}</p>
            <p className="mb-0" style={{ fontSize: '9pt' }}>Tel: (Pendiente)</p>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
            <div style={{ width: '50%' }}>
              <p className="mb-0" style={{ fontSize: '9pt' }}><strong>Factura #:</strong><br/>{venta.numero_venta}</p>
              <p className="mb-0" style={{ fontSize: '9pt' }}><strong>Fecha:</strong><br/>{formatearFecha(venta.fecha)}</p>
            </div>
            <div style={{ width: '50%', textAlign: 'right' }}>
              <p className="mb-0" style={{ fontSize: '9pt' }}><strong>Cajero:</strong><br/>{venta.cajero?.nombre || 'N/A'}</p>
              <p className="mb-0" style={{ fontSize: '9pt' }}><strong>Método pago:</strong><br/>{venta.metodo_pago.toUpperCase()}</p>
              {venta.detalles_pago?.referencia && (
                <p className="mb-0" style={{ fontSize: '9pt' }}><strong>Ref:</strong> {venta.detalles_pago.referencia}</p>
              )}
            </div>
          </div>

          {venta.cliente && (venta.cliente.nombre || venta.cliente.identificacion) && (
            <div style={{ 
              borderTop: '1px solid #ddd', 
              borderBottom: '1px solid #ddd',
              padding: '5px 0',
              marginBottom: '8px'
            }}>
              <p className="mb-0" style={{ fontSize: '9pt' }}><strong>Cliente:</strong> {venta.cliente.nombre || 'Sin nombre'}</p>
              {venta.cliente.identificacion && (
                <p className="mb-0" style={{ fontSize: '9pt' }}><strong>ID/NIT:</strong> {venta.cliente.identificacion}</p>
              )}
              {venta.cliente.telefono && (
                <p className="mb-0" style={{ fontSize: '9pt' }}><strong>Teléfono:</strong> {venta.cliente.telefono}</p>
              )}
            </div>
          )}

          <table style={{ 
            width: '100%', 
            borderCollapse: 'collapse',
            fontSize: '9pt',
            marginBottom: '8px'
          }}>
            <thead>
              <tr style={{ borderBottom: '1px solid #ddd' }}>
                <th style={{ textAlign: 'left', padding: '3px 2px' }}>Producto</th>
                <th style={{ textAlign: 'center', padding: '3px 2px' }}>Cant.</th>
                <th style={{ textAlign: 'right', padding: '3px 2px' }}>Precio</th>
              </tr>
            </thead>
            <tbody>
              {venta.productos.map((item, index) => (
                <React.Fragment key={index}>
                  <tr style={{ borderBottom: '1px solid #eee' }}>
                    <td style={{ padding: '3px 2px' }}>{item.producto?.nombre || 'Producto'}</td>
                    <td style={{ textAlign: 'center', padding: '3px 2px' }}>{item.cantidad}</td>
                    <td style={{ textAlign: 'right', padding: '3px 2px' }}>${Number(item.precio_unitario).toLocaleString()}</td>
                  </tr>
                  {item.personalizaciones && item.personalizaciones.length > 0 && (
                    item.personalizaciones.map((p, i) => (
                      <tr key={`${index}-${i}`} style={{ fontSize: '8pt', color: '#666' }}>
                        <td colSpan="2" style={{ paddingLeft: '10px', padding: '2px' }}>
                          {p.accion === 'agregar' ? '+ ' : '- '}
                          {p.ingrediente?.nombre || 'Ingrediente'} ({p.cantidad})
                        </td>
                        <td style={{ textAlign: 'right', padding: '2px' }}>
                          {p.accion === 'agregar' && p.precio > 0 ? `$${Number(p.precio).toLocaleString()}` : ''}
                        </td>
                      </tr>
                    ))
                  )}
                </React.Fragment>
              ))}
            </tbody>
            <tfoot>
              {/* Sólo un subtotal */}
              <tr style={{ borderTop: '1px solid #ddd' }}>
                <th colSpan="2" style={{ textAlign: 'right', padding: '3px 2px' }}>Subtotal:</th>
                <th style={{ textAlign: 'right', padding: '3px 2px' }}>${Number(venta.subtotal).toLocaleString()}</th>
              </tr>
              {venta.descuento > 0 && (
                <tr>
                  <th colSpan="2" style={{ textAlign: 'right', padding: '3px 2px' }}>Descuento:</th>
                  <th style={{ textAlign: 'right', padding: '3px 2px' }}>${Number(venta.descuento).toLocaleString()}</th>
                </tr>
              )}
              <tr>
                <th colSpan="2" style={{ textAlign: 'right', padding: '3px 2px', fontSize: '11pt' }}>Total:</th>
                <th style={{ textAlign: 'right', padding: '3px 2px', fontSize: '11pt' }}>${Number(venta.total).toLocaleString()}</th>
              </tr>
            </tfoot>
          </table>

          {venta.notas && (
            <div style={{ 
              borderTop: '1px solid #ddd',
              paddingTop: '8px', 
              marginTop: '8px',
              fontSize: '9pt'
            }}>
              <p className="mb-0"><strong>Notas:</strong></p>
              <p className="mb-0">{venta.notas}</p>
            </div>
          )}

          <div style={{ 
            textAlign: 'center', 
            marginTop: '16px',
            borderTop: '1px dashed #ddd',
            paddingTop: '8px',
            fontSize: '9pt'
          }}>
            <p className="mb-0">¡Gracias por su compra!</p>
            <p className="mb-0">Visítenos de nuevo pronto</p>
          </div>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        @media print {
          body * {
            visibility: hidden;
          }
          
          .factura-content, .factura-content * {
            visibility: visible;
          }
          
          .factura-content {
            position: absolute;
            left: 0;
            top: 0;
            width: 90mm !important;
          }
        }
      `}} />
    </div>
  );
};

export default FacturaVenta;