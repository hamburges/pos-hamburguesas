// src/pages/cajero/ventas/HistorialVentas.js
import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../../context/AuthContext';
import CajeroLayout from '../../../components/layout/CajeroLayout';
import ventaService from '../../../services/ventaService';
import cajaService from '../../../services/cajaService';
import cicloCajaService from '../../../services/cicloCajaService';
import { formatearFecha } from '../../../utils/formatters';

const HistorialVentas = () => {
  const [ventas, setVentas] = useState([]);
  const [filtros, setFiltros] = useState({
    fecha_inicio: '',
    fecha_fin: '',
    metodo_pago: '',
    ciclo_caja: '' // Nuevo filtro para ciclo de caja
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [ciclos, setCiclos] = useState([]); // Lista de ciclos de caja disponibles
  const [cicloActual, setCicloActual] = useState(null); // Ciclo actual
  const [cargandoCiclos, setCargandoCiclos] = useState(false);
  
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();

  // Cargar ciclos de caja para el filtro
  useEffect(() => {
    const cargarCiclos = async () => {
      try {
        setCargandoCiclos(true);
        // Cargar historial de ciclos
        const respuesta = await cicloCajaService.obtenerHistorial();
        if (respuesta.success) {
          setCiclos(respuesta.data);
        }

        // Intentar obtener ciclo actual
        try {
          const cicloActualResp = await cajaService.obtenerCajaActual();
          if (cicloActualResp.success) {
            setCicloActual(cicloActualResp.data);
            // Actualizar filtro automáticamente con el ciclo actual
            setFiltros(prev => ({
              ...prev,
              ciclo_caja: cicloActualResp.data._id
            }));
          }
        } catch (err) {
          // Si no hay ciclo activo, no hacemos nada específico
          console.log("No hay ciclo activo:", err);
        }
      } catch (error) {
        console.error("Error al cargar ciclos:", error);
      } finally {
        setCargandoCiclos(false);
      }
    };

    cargarCiclos();
  }, []);

  // Cargar ventas al inicio y cuando cambien los filtros
  useEffect(() => {
    const cargarVentas = async () => {
      if (cargandoCiclos) return; // Esperar a que se carguen los ciclos
      
      try {
        setLoading(true);
        
        // Preparar filtros
        const filtrosAplicados = {
          ...filtros,
          cajero: user.id
        };
        
        console.log("Filtros aplicados:", filtrosAplicados);
        
        // Obtener ventas del día si no hay fechas seleccionadas y hay un ciclo seleccionado o actual
        let response;
        if (!filtros.fecha_inicio && !filtros.fecha_fin) {
          console.log("Obteniendo ventas del día");
          // Pasar el ciclo seleccionado o el actual a obtenerVentasDelDia
          response = await ventaService.obtenerVentasDelDia(
            user.sucursal?._id || user.sucursal, 
            filtros.ciclo_caja || (cicloActual ? cicloActual._id : null)
          );
        } else {
          console.log("Obteniendo ventas con filtros");
          response = await ventaService.obtenerVentas(filtrosAplicados);
        }
        
        console.log("Respuesta completa:", response);
        
        // Procesar los datos recibidos
        let ventasData = [];
        if (response.data && response.data.ventas) {
          ventasData = response.data.ventas;
        } else if (response.data && Array.isArray(response.data.data)) {
          ventasData = response.data.data;
        }
        
        setVentas(ventasData);
        setError(null);
      } catch (error) {
        console.error('Error al cargar ventas:', error);
        let mensajeError = 'Error al cargar el historial de ventas';
        if (error.response) {
          console.log("Detalles del error:", error.response.data);
          mensajeError += `: ${error.response.data.message || 'Error en el servidor'}`;
        }
        setError(mensajeError);
        setVentas([]);
      } finally {
        setLoading(false);
      }
    };
    
    cargarVentas();
  }, [filtros, user.id, user.sucursal, cargandoCiclos, cicloActual]);

  // Manejar cambios en los filtros
  const handleFiltrosChange = (e) => {
    const { name, value } = e.target;
    setFiltros(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Manejar clic en una venta para ver detalles
  const handleVerDetalles = (ventaId) => {
    navigate(`/cajero/ventas/detalle/${ventaId}`);
  };

  return (
    <CajeroLayout>
      <div className="container-fluid">
        <h1 className="mb-4">Historial de Ventas</h1>
        
        {/* Información del ciclo actual */}
        {cicloActual && (
          <div className="alert alert-info mb-4">
            <strong>Ciclo de caja activo</strong> • Abierto: {formatearFecha(cicloActual.fecha_apertura)}
          </div>
        )}
        
        {/* Filtros */}
        <div className="card mb-4">
          <div className="card-body">
            <h5 className="card-title">Filtros</h5>
            <div className="row g-3">
              <div className="col-md-3">
                <label className="form-label">Fecha Inicio</label>
                <input
                  type="date"
                  className="form-control"
                  name="fecha_inicio"
                  value={filtros.fecha_inicio}
                  onChange={handleFiltrosChange}
                />
              </div>
              <div className="col-md-3">
                <label className="form-label">Fecha Fin</label>
                <input
                  type="date"
                  className="form-control"
                  name="fecha_fin"
                  value={filtros.fecha_fin}
                  onChange={handleFiltrosChange}
                />
              </div>
              <div className="col-md-3">
                <label className="form-label">Método de Pago</label>
                <select
                  className="form-select"
                  name="metodo_pago"
                  value={filtros.metodo_pago}
                  onChange={handleFiltrosChange}
                >
                  <option value="">Todos</option>
                  <option value="efectivo">Efectivo</option>
                  <option value="nequi">Nequi</option>
                  <option value="daviplata">Daviplata</option>
                  <option value="transferencia">Transferencia</option>
                  <option value="mixto">Mixto</option>
                </select>
              </div>
              <div className="col-md-3">
                <label className="form-label">Ciclo de Caja</label>
                <select
                  className="form-select"
                  name="ciclo_caja"
                  value={filtros.ciclo_caja}
                  onChange={handleFiltrosChange}
                  disabled={cargandoCiclos}
                >
                  <option value="">Todos los ciclos</option>
                  {cicloActual && (
                    <option value={cicloActual._id}>Ciclo actual</option>
                  )}
                  {ciclos
                    .filter(c => !cicloActual || c._id !== cicloActual._id) // Excluir el ciclo actual que ya está en la lista
                    .map(ciclo => (
                      <option key={ciclo._id} value={ciclo._id}>
                        {formatearFecha(ciclo.fecha_apertura)} 
                        {ciclo.estado === 'cerrado' ? ' (Cerrado)' : ''}
                      </option>
                    ))
                  }
                </select>
              </div>
            </div>
          </div>
        </div>
        
        {/* Mensajes de estado */}
        {error && <div className="alert alert-danger">{error}</div>}
        {loading && (
          <div className="d-flex justify-content-center my-4">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Cargando...</span>
            </div>
          </div>
        )}
        
        {/* Tabla de ventas */}
        {!loading && ventas && ventas.length === 0 ? (
          <div className="alert alert-info">
            No se encontraron ventas con los filtros seleccionados
          </div>
        ) : (
          <div className="table-responsive">
            <table className="table table-striped table-hover">
              <thead className="table-primary">
                <tr>
                  <th>N° Venta</th>
                  <th>Fecha</th>
                  <th>Ciclo</th>
                  <th>Total</th>
                  <th>Método Pago</th>
                  <th>Estado</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {ventas.map(venta => (
                  <tr key={venta._id}>
                    <td>{venta.numero_venta}</td>
                    <td>{formatearFecha(venta.fecha)}</td>
                    <td>
                      {venta.ciclo_caja ? (
                        <span className="badge bg-info">
                          {formatearFecha(venta.ciclo_caja.fecha_apertura).substring(0, 10)}
                        </span>
                      ) : (
                        <span className="badge bg-secondary">N/A</span>
                      )}
                    </td>
                    <td>${Number(venta.total).toLocaleString()}</td>
                    <td>
                      {venta.metodo_pago === 'efectivo' && 'Efectivo'}
                      {venta.metodo_pago === 'nequi' && 'Nequi'}
                      {venta.metodo_pago === 'daviplata' && 'Daviplata'}
                      {venta.metodo_pago === 'transferencia' && 'Transferencia'}
                      {venta.metodo_pago === 'mixto' && 'Mixto'}
                    </td>
                    <td>
                      <span 
                        className={`badge ${venta.estado === 'completada' ? 'bg-success' : 'bg-danger'}`}
                      >
                        {venta.estado === 'completada' ? 'Completada' : 'Anulada'}
                      </span>
                    </td>
                    <td>
                      <button
                        className="btn btn-sm btn-info"
                        onClick={() => handleVerDetalles(venta._id)}
                      >
                        Ver Detalles
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </CajeroLayout>
  );
};

export default HistorialVentas;