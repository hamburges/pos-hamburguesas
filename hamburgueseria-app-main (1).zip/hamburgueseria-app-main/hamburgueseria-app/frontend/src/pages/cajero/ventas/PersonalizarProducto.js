// src/pages/cajero/ventas/PersonalizarProducto.js
import React, { useState, useEffect } from 'react';
import opcionProductoService from '../../../services/opcionProductoService';

const PersonalizarProducto = ({ show, onHide, producto, agregarAlCarrito }) => {
  const [opciones, setOpciones] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [personalizaciones, setPersonalizaciones] = useState([]);
  
  // Cargar opciones disponibles cuando se abre el modal
  useEffect(() => {
    if (show && producto) {
      cargarOpciones();
    }
  }, [show, producto]);
  
  // Función para cargar opciones del producto
  const cargarOpciones = async () => {
    if (!producto) return;
    
    try {
      setLoading(true);
      const response = await opcionProductoService.obtenerOpcionesPorProducto(producto._id);
      setOpciones(response.data);
      
      // Inicializar las personalizaciones con los ingredientes predeterminados
      const defaultPersonalizaciones = response.data
        .filter(opcion => opcion.es_predeterminado)
        .map(opcion => ({
          ingrediente: opcion.ingrediente,
          accion: 'agregar',
          cantidad: opcion.cantidad_predeterminada,
          precio: 0, // Los ingredientes predeterminados no tienen costo adicional
          cantidadPredeterminada: opcion.cantidad_predeterminada // Guardamos la cantidad predeterminada
        }));
      
      setPersonalizaciones(defaultPersonalizaciones);
      setError(null);
    } catch (error) {
      console.error('Error al cargar opciones:', error);
      setError('Error al cargar las opciones del producto');
    } finally {
      setLoading(false);
    }
  };
  
  // Función para agregar o quitar un ingrediente
  const toggleIngrediente = (opcion, accion) => {
    // Buscar si ya existe una personalización para este ingrediente
    const personalizacionIndex = personalizaciones.findIndex(
      p => p.ingrediente._id === opcion.ingrediente._id
    );
    
    // Si el ingrediente ya está predeterminado y queremos agregar más
    if (opcion.es_predeterminado && accion === 'agregar') {
      if (personalizacionIndex >= 0) {
        // Si ya hay una personalización, actualizamos la cantidad
        const nuevasPersonalizaciones = [...personalizaciones];
        
        // Sumamos 1 a la cantidad existente
        const nuevaCantidad = nuevasPersonalizaciones[personalizacionIndex].cantidad + 1;
        
        // Calculamos el precio solo por la cantidad adicional por encima de la predeterminada
        const cantidadAdicional = nuevaCantidad - opcion.cantidad_predeterminada;
        const nuevoPrecio = cantidadAdicional > 0 
          ? opcion.ingrediente.precio_adicional * cantidadAdicional 
          : 0;
        
        nuevasPersonalizaciones[personalizacionIndex] = {
          ...nuevasPersonalizaciones[personalizacionIndex],
          cantidad: nuevaCantidad,
          precio: nuevoPrecio
        };
        
        setPersonalizaciones(nuevasPersonalizaciones);
      } else {
        // Si no existe personalización previa, creamos una con cantidad = predeterminada + 1
        const cantidadTotal = opcion.cantidad_predeterminada + 1;
        // Solo cobramos por la cantidad adicional (1 en este caso)
        const precio = opcion.ingrediente.precio_adicional;
        
        setPersonalizaciones([
          ...personalizaciones,
          {
            ingrediente: opcion.ingrediente,
            accion: 'agregar',
            cantidad: cantidadTotal,
            precio: precio,
            cantidadPredeterminada: opcion.cantidad_predeterminada
          }
        ]);
      }
    } 
    // Para ingredientes no predeterminados o acciones de quitar
    else {
      if (personalizacionIndex >= 0) {
        // Si ya existe, actualizar o eliminar
        if (accion === personalizaciones[personalizacionIndex].accion) {
          // Si es la misma acción, eliminar
          setPersonalizaciones(
            personalizaciones.filter((_, index) => index !== personalizacionIndex)
          );
        } else {
          // Si es diferente acción, actualizar
          const nuevasPersonalizaciones = [...personalizaciones];
          nuevasPersonalizaciones[personalizacionIndex] = {
            ...nuevasPersonalizaciones[personalizacionIndex],
            accion,
            cantidad: accion === 'agregar' ? 1 : opcion.cantidad_predeterminada,
            precio: accion === 'agregar' ? opcion.ingrediente.precio_adicional : 0,
            cantidadPredeterminada: opcion.cantidad_predeterminada
          };
          setPersonalizaciones(nuevasPersonalizaciones);
        }
      } else {
        // Si no existe, añadir
        setPersonalizaciones([
          ...personalizaciones,
          {
            ingrediente: opcion.ingrediente,
            accion,
            cantidad: accion === 'agregar' ? 1 : opcion.cantidad_predeterminada,
            precio: accion === 'agregar' ? opcion.ingrediente.precio_adicional : 0,
            cantidadPredeterminada: opcion.cantidad_predeterminada
          }
        ]);
      }
    }
  };
  
  // Función para ajustar la cantidad de un ingrediente personalizado
  const ajustarCantidad = (index, cantidad) => {
    if (cantidad < 1) return;
    
    const nuevasPersonalizaciones = [...personalizaciones];
    const personalizacion = nuevasPersonalizaciones[index];
    
    // Encontrar la opción correspondiente a este ingrediente
    const opcion = opciones.find(o => o.ingrediente._id === personalizacion.ingrediente._id);
    
    // Calcular el precio basado en si es predeterminado y la acción
    let nuevoPrecio = 0;
    
    if (personalizacion.accion === 'agregar') {
      if (opcion && opcion.es_predeterminado) {
        // Si es predeterminado, solo cobramos por lo que excede la cantidad predeterminada
        const cantidadAdicional = cantidad - opcion.cantidad_predeterminada;
        nuevoPrecio = cantidadAdicional > 0 
          ? personalizacion.ingrediente.precio_adicional * cantidadAdicional 
          : 0;
      } else {
        // Si no es predeterminado, cobramos por toda la cantidad
        nuevoPrecio = personalizacion.ingrediente.precio_adicional * cantidad;
      }
    }
    
    nuevasPersonalizaciones[index] = {
      ...personalizacion,
      cantidad,
      precio: nuevoPrecio
    };
    
    setPersonalizaciones(nuevasPersonalizaciones);
  };
  
  // Función para calcular el subtotal con personalizaciones
  const calcularSubtotal = () => {
    const precioBase = producto.precio_base;
    
    // Sumar precios de ingredientes añadidos
    const precioPorPersonalizaciones = personalizaciones.reduce((total, p) => 
      p.accion === 'agregar' ? total + p.precio : total
    , 0);
    
    return precioBase + precioPorPersonalizaciones;
  };
  
  // Función para agregar al carrito con personalizaciones
  const handleAgregarAlCarrito = () => {
    const subtotal = calcularSubtotal();
    
    // CORRECCIÓN IMPORTANTE: Asegurar que cada personalización incluya su precio correcto
    const personalizacionesActualizadas = personalizaciones.map(p => {
      if (p.accion === 'agregar') {
        // Encontrar la opción correspondiente
        const opcion = opciones.find(o => o.ingrediente._id === p.ingrediente._id);
        
        // Recalcular el precio para asegurarnos
        let precio = 0;
        if (opcion && opcion.es_predeterminado) {
          const cantidadAdicional = p.cantidad - opcion.cantidad_predeterminada;
          precio = cantidadAdicional > 0 
            ? p.ingrediente.precio_adicional * cantidadAdicional 
            : 0;
        } else {
          precio = p.ingrediente.precio_adicional * p.cantidad;
        }
        
        return {
          ...p,
          precio: precio
        };
      }
      return p;
    });
    
    const productoParaCarrito = {
      producto: producto,
      cantidad: 1,
      precio_unitario: producto.precio_base,
      personalizaciones: personalizacionesActualizadas,
      subtotal: subtotal
    };
    
    console.log('Agregando al carrito:', productoParaCarrito);
    agregarAlCarrito(productoParaCarrito);
    onHide();
  };
  
  // Función para obtener personalizaciones por tipo
  const getPersonalizacionesPorTipo = (tipo) => {
    return personalizaciones.filter(p => p.accion === tipo);
  };
  
  // Si no hay producto, no mostrar nada
  if (!show || !producto) {
    return null;
  }
  
  return (
    <div 
      className="modal-overlay" 
      onClick={onHide}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1050,
        backdropFilter: 'blur(5px)'
      }}
    >
      <div 
        className="modal-dialog" 
        onClick={e => e.stopPropagation()}
        style={{
          maxWidth: '800px',
          width: '95%',
          margin: 0,
          borderRadius: '10px',
          overflow: 'hidden',
          boxShadow: '0 5px 20px rgba(0, 0, 0, 0.3)'
        }}
      >
        <div className="modal-content">
          <div className="modal-header bg-primary text-white">
            <h5 className="modal-title">
              <i className="bi bi-gear-fill me-2"></i>
              Personalizar {producto.nombre}
            </h5>
            <button type="button" className="btn-close btn-close-white" onClick={onHide}></button>
          </div>
          
          <div className="modal-body p-4">
            {/* Resto del código del modal... */}
            {loading ? (
              <div className="text-center p-5">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Cargando...</span>
                </div>
                <p className="mt-3">Cargando opciones...</p>
              </div>
            ) : error ? (
              <div className="alert alert-danger">
                <i className="bi bi-exclamation-triangle-fill me-2"></i>
                {error}
              </div>
            ) : (
              <div>
                <div className="row mb-4">
                  <div className="col-md-6">
                    <div className="d-flex align-items-center mb-3">
                      <div 
                        className="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-2"
                        style={{ width: '24px', height: '24px', fontSize: '12px' }}
                      >
                        1
                      </div>
                      <h5 className="mb-0">Elige tus ingredientes</h5>
                    </div>
                    
                    {opciones.length === 0 ? (
                      <div className="alert alert-info">
                        <i className="bi bi-info-circle-fill me-2"></i>
                        Este producto no tiene opciones personalizables
                      </div>
                    ) : (
                      <div className="row g-2">
                        {opciones.map(opcion => (
                          <div key={opcion.ingrediente._id} className="col-12">
                            <div className="card border h-100 shadow-sm">
                              <div className="card-body py-2">
                                <div className="d-flex align-items-center justify-content-between">
                                  <div>
                                    <h6 className="mb-0">{opcion.ingrediente.nombre}</h6>
                                    <div className="d-flex gap-1 mt-1">
                                      {opcion.es_predeterminado && (
                                        <span className="badge bg-info rounded-pill">
                                          <i className="bi bi-check-circle-fill me-1"></i>
                                          Incluido ({opcion.cantidad_predeterminada})
                                        </span>
                                      )}
                                      {opcion.ingrediente.precio_adicional > 0 && (
                                        <span className="badge bg-warning text-dark rounded-pill">
                                          +${opcion.ingrediente.precio_adicional.toLocaleString()} c/u
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                  <div className="d-flex gap-1">
                                    <button 
                                      className="btn btn-sm btn-outline-danger rounded-pill px-3"
                                      disabled={!opcion.es_removible}
                                      onClick={() => toggleIngrediente(opcion, 'quitar')}
                                    >
                                      <i className="bi bi-dash-circle me-1"></i>
                                      Quitar
                                    </button>
                                    <button 
                                      className="btn btn-sm btn-outline-success rounded-pill px-3"
                                      onClick={() => toggleIngrediente(opcion, 'agregar')}
                                    >
                                      <i className="bi bi-plus-circle me-1"></i>
                                      Agregar
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="col-md-6">
                    <div className="d-flex align-items-center mb-3">
                      <div 
                        className="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-2"
                        style={{ width: '24px', height: '24px', fontSize: '12px' }}
                      >
                        2
                      </div>
                      <h5 className="mb-0">Tu selección</h5>
                    </div>
                    
                    {personalizaciones.length === 0 ? (
                      <div className="alert alert-warning">
                        <i className="bi bi-info-circle-fill me-2"></i>
                        No has realizado ninguna personalización
                      </div>
                    ) : (
                      <div>
                        {getPersonalizacionesPorTipo('agregar').length > 0 && (
                          <div className="mb-3">
                            <h6 className="text-success mb-2">
                              <i className="bi bi-plus-circle-fill me-1"></i>
                              Ingredientes agregados
                            </h6>
                            <ul className="list-group shadow-sm">
                              {getPersonalizacionesPorTipo('agregar').map((p, index) => {
                                const opcion = opciones.find(o => o.ingrediente._id === p.ingrediente._id);
                                const esPredeterminado = opcion && opcion.es_predeterminado;
                                const cantidadAdicional = esPredeterminado 
                                  ? p.cantidad - p.cantidadPredeterminada 
                                  : p.cantidad;
                                const hayAdicionales = esPredeterminado && cantidadAdicional > 0;
                                
                                return (
                                  <li key={index} className="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                      <span className="fw-semibold">{p.ingrediente.nombre}</span>
                                      <div className="small text-muted">
                                        {esPredeterminado 
                                          ? `Base: ${p.cantidadPredeterminada} ${hayAdicionales 
                                              ? `+ ${cantidadAdicional} extra` 
                                              : ''}`
                                          : `${p.cantidad} unidad${p.cantidad > 1 ? 'es' : ''}`
                                        }
                                      </div>
                                    </div>
                                    <div className="d-flex align-items-center gap-2">
                                      {p.precio > 0 && (
                                        <span className="text-success">+${p.precio.toLocaleString()}</span>
                                      )}
                                      <div className="input-group input-group-sm" style={{width: '100px'}}>
                                        <button 
                                          className="btn btn-outline-secondary" 
                                          type="button"
                                          onClick={() => ajustarCantidad(personalizaciones.indexOf(p), p.cantidad - 1)}
                                        >
                                          <i className="bi bi-dash"></i>
                                        </button>
                                        <input 
                                          type="number" 
                                          className="form-control text-center" 
                                          value={p.cantidad}
                                          id={`cantidad-agregar-${index}`}
                                          name={`cantidad-agregar-${index}`}
                                          readOnly
                                        />
                                        <button 
                                          className="btn btn-outline-secondary" 
                                          type="button"
                                          onClick={() => ajustarCantidad(personalizaciones.indexOf(p), p.cantidad + 1)}
                                        >
                                          <i className="bi bi-plus"></i>
                                        </button>
                                      </div>
                                    </div>
                                  </li>
                                );
                              })}
                            </ul>
                          </div>
                        )}
                        
                        {getPersonalizacionesPorTipo('quitar').length > 0 && (
                          <div className="mb-3">
                            <h6 className="text-danger mb-2">
                              <i className="bi bi-dash-circle-fill me-1"></i>
                              Ingredientes a quitar
                            </h6>
                            <ul className="list-group shadow-sm">
                              {getPersonalizacionesPorTipo('quitar').map((p, index) => (
                                <li key={index} className="list-group-item d-flex justify-content-between align-items-center">
                                  <span>{p.ingrediente.nombre}</span>
                                  <span className="badge bg-danger rounded-pill">Quitar</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}
                    
                    <div className="mt-4">
                      <div className="card bg-light shadow-sm">
                        <div className="card-body">
                          <div className="d-flex justify-content-between align-items-center">
                            <div>
                              <div className="text-muted">Precio base:</div>
                              <div className="text-muted">Extras:</div>
                              <div className="fw-bold mt-2">Total:</div>
                            </div>
                            <div className="text-end">
                              <div className="text-muted">${producto.precio_base.toLocaleString()}</div>
                              <div className="text-muted">
                                ${personalizaciones.reduce((total, p) => total + p.precio, 0).toLocaleString()}
                              </div>
                              <div className="fw-bold mt-2 fs-4 text-success">${calcularSubtotal().toLocaleString()}</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          <div className="modal-footer d-flex justify-content-between">
            <button type="button" className="btn btn-outline-secondary px-4" onClick={onHide}>
              <i className="bi bi-x-circle me-2"></i>
              Cancelar
            </button>
            <button 
              type="button" 
              className="btn btn-primary px-4"
              disabled={loading}
              onClick={handleAgregarAlCarrito}
            >
              <i className="bi bi-cart-plus me-2"></i>
              {loading ? 'Procesando...' : 'Agregar al Carrito'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PersonalizarProducto;