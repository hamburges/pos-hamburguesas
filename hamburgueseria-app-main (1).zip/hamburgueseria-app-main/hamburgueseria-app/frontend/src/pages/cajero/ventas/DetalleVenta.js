// src/pages/cajero/ventas/DetalleVenta.js
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import CajeroLayout from '../../../components/layout/CajeroLayout';
import ventaService from '../../../services/ventaService';
import FacturaVenta from './FacturaVenta';
import AutorizacionVentaModal from '../../../components/AutorizacionVentaModal';

const DetalleVenta = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [venta, setVenta] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [mostrarFactura, setMostrarFactura] = useState(false);
  const [mostrarAutorizacion, setMostrarAutorizacion] = useState(false);
  const [motivoAnulacion, setMotivoAnulacion] = useState('');
  
  // Función para formatear fecha
  const formatearFecha = (fechaString) => {
    const fecha = new Date(fechaString);
    return fecha.toLocaleString('es-CO', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Cargar datos de la venta
  useEffect(() => {
    const cargarVenta = async () => {
      try {
        setLoading(true);
        const response = await ventaService.obtenerVentaPorId(id);
        setVenta(response.data);
        setError(null);
      } catch (error) {
        console.error('Error al cargar venta:', error);
        setError('Error al cargar los detalles de la venta');
      } finally {
        setLoading(false);
      }
    };
    
    if (id) {
      cargarVenta();
    }
  }, [id]);

  // Iniciar flujo de anulación
  const iniciarAnulacionVenta = () => {
    if (!window.confirm('¿Estás seguro de anular esta venta? Esta acción no se puede deshacer.')) {
      return;
    }
    
    // Solicitar motivo de anulación
    const motivo = window.prompt('Por favor, ingresa el motivo de la anulación:');
    if (!motivo || motivo.trim().length < 5) {
      alert('Debes proporcionar un motivo válido (mínimo 5 caracteres).');
      return;
    }
    
    setMotivoAnulacion(motivo);
    // Mostrar modal de autorización
    setMostrarAutorizacion(true);
  };
  
  // Confirmar anulación con autorización
  const confirmarAnulacion = async (codigoPin) => {
    try {
      setLoading(true);
      await ventaService.anularVenta(id, {
        motivo: motivoAnulacion,
        codigo_autorizacion: codigoPin
      });
      
      // Recargar la venta para actualizar su estado
      const response = await ventaService.obtenerVentaPorId(id);
      setVenta(response.data);
      
      alert('Venta anulada correctamente');
      setMostrarAutorizacion(false);
    } catch (error) {
      console.error('Error al anular venta:', error);
      alert('Error al anular la venta: ' + (error.response?.data?.message || 'Error desconocido'));
    } finally {
      setLoading(false);
    }
  };

  // Volver al historial
  const handleVolver = () => {
    navigate('/cajero/ventas/historial');
  };

  if (loading) {
    return (
      <CajeroLayout>
        <div className="container-fluid">
          <div className="d-flex justify-content-center my-5">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Cargando...</span>
            </div>
          </div>
        </div>
      </CajeroLayout>
    );
  }

  if (error || !venta) {
    return (
      <CajeroLayout>
        <div className="container-fluid">
          <div className="alert alert-danger">
            {error || 'No se pudo cargar la venta'}
          </div>
          <button className="btn btn-primary" onClick={handleVolver}>
            Volver al Historial
          </button>
        </div>
      </CajeroLayout>
    );
  }

  return (
    <CajeroLayout>
      <div className="container-fluid">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h1>Detalle de Venta</h1>
          <div>
            <button 
              className="btn btn-outline-primary me-2" 
              onClick={() => setMostrarFactura(true)}
            >
              <i className="bi bi-receipt me-1"></i> 
              Ver Factura
            </button>
            <button 
              className="btn btn-outline-secondary" 
              onClick={handleVolver}
            >
              Volver
            </button>
          </div>
        </div>
        
        <div className="card mb-4">
          <div className="card-header bg-primary text-white">
            <div className="d-flex justify-content-between align-items-center">
              <h5 className="mb-0">
                {venta.numero_venta}
                <span className={`ms-3 badge ${venta.estado === 'completada' ? 'bg-success' : 'bg-danger'}`}>
                  {venta.estado === 'completada' ? 'Completada' : 'Anulada'}
                </span>
              </h5>
              {venta.estado === 'completada' && (
                <button 
                  className="btn btn-sm btn-danger" 
                  onClick={iniciarAnulacionVenta}
                >
                  Anular Venta
                </button>
              )}
            </div>
          </div>
          <div className="card-body">
            <div className="row mb-4">
              <div className="col-md-6">
                <dl className="row">
                  <dt className="col-sm-4">Fecha:</dt>
                  <dd className="col-sm-8">{formatearFecha(venta.fecha)}</dd>
                  
                  <dt className="col-sm-4">Sucursal:</dt>
                  <dd className="col-sm-8">{venta.sucursal?.nombre || 'N/A'}</dd>
                  
                  <dt className="col-sm-4">Cajero:</dt>
                  <dd className="col-sm-8">{venta.cajero?.nombre || 'N/A'}</dd>
                  
                  {venta.estado === 'anulada' && venta.fecha_anulacion && (
                    <>
                      <dt className="col-sm-4">Fecha anulación:</dt>
                      <dd className="col-sm-8">{formatearFecha(venta.fecha_anulacion)}</dd>
                      
                      {venta.motivo_anulacion && (
                        <>
                          <dt className="col-sm-4">Motivo anulación:</dt>
                          <dd className="col-sm-8">{venta.motivo_anulacion}</dd>
                        </>
                      )}
                      
                      {venta.usuario_autorizo && (
                        <>
                          <dt className="col-sm-4">Autorizado por:</dt>
                          <dd className="col-sm-8">{venta.usuario_autorizo.nombre || venta.usuario_autorizo.usuario || 'N/A'}</dd>
                        </>
                      )}
                    </>
                  )}
                </dl>
              </div>
              <div className="col-md-6">
                <dl className="row">
                  <dt className="col-sm-4">Método de pago:</dt>
                  <dd className="col-sm-8">{venta.metodo_pago.toUpperCase()}</dd>
                  
                  {venta.detalles_pago?.referencia && (
                    <>
                      <dt className="col-sm-4">Referencia:</dt>
                      <dd className="col-sm-8">{venta.detalles_pago.referencia}</dd>
                    </>
                  )}
                  
                  <dt className="col-sm-4">Para llevar:</dt>
                  <dd className="col-sm-8">{venta.para_llevar ? 'Sí' : 'No'}</dd>
                </dl>
              </div>
            </div>
            
            {venta.cliente && (venta.cliente.nombre || venta.cliente.identificacion) && (
              <div className="cliente-info mb-4 p-3 bg-light rounded">
                <h6 className="mb-2">Información de Cliente</h6>
                <dl className="row mb-0">
                  {venta.cliente.nombre && (
                    <>
                      <dt className="col-sm-2">Nombre:</dt>
                      <dd className="col-sm-10">{venta.cliente.nombre}</dd>
                    </>
                  )}
                  
                  {venta.cliente.identificacion && (
                    <>
                      <dt className="col-sm-2">ID/NIT:</dt>
                      <dd className="col-sm-10">{venta.cliente.identificacion}</dd>
                    </>
                  )}
                  
                  {venta.cliente.telefono && (
                    <>
                      <dt className="col-sm-2">Teléfono:</dt>
                      <dd className="col-sm-10">{venta.cliente.telefono}</dd>
                    </>
                  )}
                </dl>
              </div>
            )}
            
            <h6 className="mb-3">Productos</h6>
            <div className="table-responsive">
              <table className="table table-striped table-hover">
                <thead className="table-light">
                  <tr>
                    <th>Producto</th>
                    <th className="text-center">Cantidad</th>
                    <th className="text-end">Precio</th>
                    <th className="text-end">Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  {venta.productos.map((item, index) => (
                    <React.Fragment key={index}>
                      <tr>
                        <td>{item.producto?.nombre || 'Producto'}</td>
                        <td className="text-center">{item.cantidad}</td>
                        <td className="text-end">${Number(item.precio_unitario).toLocaleString()}</td>
                        <td className="text-end">${Number(item.subtotal).toLocaleString()}</td>
                      </tr>
                      {item.personalizaciones && item.personalizaciones.length > 0 && (
                        <tr>
                          <td colSpan="4" className="py-0">
                            <div className="bg-light p-2 rounded">
                              <small className="fw-bold">Personalizaciones:</small>
                              <ul className="mb-0 ps-4">
                                {item.personalizaciones.map((p, i) => (
                                  <li key={i} className="small">
                                    {p.accion === 'agregar' ? '+ ' : '- '}
                                    {p.ingrediente?.nombre || 'Ingrediente'} 
                                    ({p.cantidad})
                                    {p.accion === 'agregar' && p.precio > 0 && (
                                      <span className="text-success"> +${Number(p.precio).toLocaleString()}</span>
                                    )}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <th colSpan="3" className="text-end">Subtotal:</th>
                    <th className="text-end">${Number(venta.subtotal).toLocaleString()}</th>
                  </tr>
                  {venta.descuento > 0 && (
                    <tr>
                      <th colSpan="3" className="text-end">Descuento:</th>
                      <th className="text-end">${Number(venta.descuento).toLocaleString()}</th>
                    </tr>
                  )}
                  <tr className="table-primary">
                    <th colSpan="3" className="text-end">Total:</th>
                    <th className="text-end">${Number(venta.total).toLocaleString()}</th>
                  </tr>
                </tfoot>
              </table>
            </div>
            
            {venta.notas && (
              <div className="mt-3">
                <h6>Notas:</h6>
                <p className="bg-light p-2 rounded">{venta.notas}</p>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Modal de factura */}
      {mostrarFactura && (
        <FacturaVenta 
          venta={venta} 
          onClose={() => setMostrarFactura(false)} 
        />
      )}
      
      {/* Modal de autorización */}
      <AutorizacionVentaModal
        show={mostrarAutorizacion}
        onClose={() => setMostrarAutorizacion(false)}
        onConfirm={confirmarAnulacion}
      />
    </CajeroLayout>
  );
};

export default DetalleVenta;