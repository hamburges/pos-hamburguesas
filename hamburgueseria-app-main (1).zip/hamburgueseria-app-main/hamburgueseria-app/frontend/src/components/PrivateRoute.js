// src/components/PrivateRoute.js
import React, { useContext } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const PrivateRoute = ({ allowedRoles }) => {
  const { user, loading } = useContext(AuthContext);
  
  // Añadir logs para depuración
  console.log("PrivateRoute - Usuario:", user);
  console.log("PrivateRoute - Roles permitidos:", allowedRoles);
  
  if (loading) {
    return <div className="text-center p-5">Cargando...</div>;
  }

  if (!user) {
    console.log("Usuario no autenticado, redirigiendo a login");
    return <Navigate to="/login" replace />;
  }

  // Verificar si el rol del usuario está permitido
  const tieneRolPermitido = allowedRoles.includes(user.rol);
  console.log("¿Tiene rol permitido?", tieneRolPermitido, "Rol:", user.rol);

  if (!tieneRolPermitido) {
    console.log("Usuario no tiene rol permitido, redirigiendo a unauthorized");
    return <Navigate to="/unauthorized" replace />;
  }

  return <Outlet />;
};

export default PrivateRoute;