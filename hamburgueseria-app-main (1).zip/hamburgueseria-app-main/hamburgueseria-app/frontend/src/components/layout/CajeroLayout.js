// src/components/layout/CajeroLayout.js
import React, { useContext, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';

const CajeroLayout = ({ children }) => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const location = useLocation();
  
  // Agregar esto para depuración
  console.log("Usuario en CajeroLayout:", user);

  // Asegurarse de que Bootstrap esté inicializado
  useEffect(() => {
    // Inicializar dropdowns Bootstrap
    if (typeof window !== 'undefined' && typeof document !== 'undefined') {
      // Importar Bootstrap dinámicamente si está disponible
      const bootstrap = window.bootstrap;
      if (bootstrap && bootstrap.Dropdown) {
        const dropdownElementList = document.querySelectorAll('.dropdown-toggle');
        [...dropdownElementList].map(dropdownToggleEl => new bootstrap.Dropdown(dropdownToggleEl));
      } else {
        console.warn('Bootstrap JS no está disponible. Los dropdowns pueden no funcionar correctamente.');
      }
    }
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  // Función para verificar si una ruta está activa
  const isActive = (path) => {
    return location.pathname === path ? 'active' : '';
  };

  // Función para obtener el nombre de la sucursal de forma segura
  const getSucursalNombre = () => {
    if (!user) return '';
    
    if (typeof user.sucursal === 'object' && user.sucursal !== null) {
      return user.sucursal.nombre || 'Sin nombre';
    }
    
    if (user.sucursalObj && typeof user.sucursalObj === 'object') {
      return user.sucursalObj.nombre || 'Sin nombre';
    }
    
    // Si es un string (ID) u otro formato, simplemente mostramos el ID
    return `ID: ${user.sucursal || 'N/A'}`;
  };

  return (
    <div className="d-flex flex-column min-vh-100">
      <header className="bg-dark text-white">
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
          <div className="container-fluid">
            <Link className="navbar-brand" to="/cajero/ventas">
              JQ Q Berraquera - Punto de Venta
            </Link>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav me-auto">
                {/* Menú de Ventas */}
                <li className="nav-item dropdown">
                  <a className="nav-link dropdown-toggle" href="#" id="ventasDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Ventas
                  </a>
                  <ul className="dropdown-menu" aria-labelledby="ventasDropdown">
                    <li>
                      <Link className={`dropdown-item ${isActive('/cajero/ventas')}`} to="/cajero/ventas">
                        Nueva Venta
                      </Link>
                    </li>
                    <li>
                      <Link className={`dropdown-item ${isActive('/cajero/ventas/historial')}`} to="/cajero/ventas/historial">
                        Historial de Ventas
                      </Link>
                    </li>
                  </ul>
                </li>
                
                {/* Menú de Caja */}
                <li className="nav-item dropdown">
                  <a className="nav-link dropdown-toggle" href="#" id="cajaDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Caja
                  </a>
                  <ul className="dropdown-menu" aria-labelledby="cajaDropdown">
                    <li>
                      <Link className={`dropdown-item ${isActive('/cajero/caja/apertura')}`} to="/cajero/caja/apertura">
                        Apertura de Caja
                      </Link>
                    </li>
                    <li>
                      <Link className={`dropdown-item ${isActive('/cajero/caja/cierre')}`} to="/cajero/caja/cierre">
                        Cierre de Caja
                      </Link>
                    </li>
                    <li>
                      <Link className={`dropdown-item ${isActive('/cajero/caja/movimiento')}`} to="/cajero/caja/movimiento">
                        Registrar Movimiento
                      </Link>
                    </li>
                    <li>
                      <Link className={`dropdown-item ${isActive('/cajero/caja/historial')}`} to="/cajero/caja/historial">
                        Historial de Cajas
                      </Link>
                    </li>
                  </ul>
                </li>
              </ul>
              <div className="d-flex align-items-center">
                <span className="me-3 text-light">
                  {user?.nombre || 'Usuario'} | {getSucursalNombre()}
                </span>
                <button 
                  className="btn btn-outline-light btn-sm" 
                  onClick={handleLogout}
                >
                  Cerrar Sesión
                </button>
              </div>
            </div>
          </div>
        </nav>
      </header>

      <main className="flex-grow-1 bg-light py-3">
        <div className="container">
          {children}
        </div>
      </main>

      <footer className="bg-dark text-white text-center py-2">
        <div className="container">
          <small>JQ Q Berraquera &copy; {new Date().getFullYear()}</small>
        </div>
      </footer>
    </div>
  );
};

export default CajeroLayout;