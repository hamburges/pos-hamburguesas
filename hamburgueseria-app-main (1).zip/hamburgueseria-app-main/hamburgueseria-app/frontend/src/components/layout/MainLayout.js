import React, { useContext, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';

const MainLayout = ({ children }) => {
 const { user, logout } = useContext(AuthContext);
 const navigate = useNavigate();
 const location = useLocation();

 // Asegurarse de que Bootstrap esté inicializado
 useEffect(() => {
   // Inicializar dropdowns Bootstrap
   if (typeof window !== 'undefined' && typeof document !== 'undefined') {
     // Importar Bootstrap dinámicamente si está disponible
     const bootstrap = window.bootstrap;
     if (bootstrap && bootstrap.Dropdown) {
       const dropdownElementList = document.querySelectorAll('.dropdown-toggle');
       [...dropdownElementList].map(dropdownToggleEl => new bootstrap.Dropdown(dropdownToggleEl));
     } else {
       console.warn('Bootstrap JS no está disponible. Los dropdowns pueden no funcionar correctamente.');
     }
   }
 }, []);

 const handleLogout = () => {
   logout();
   navigate('/login');
 };

 const isActive = (path) => {
   return location.pathname === path ? 'active' : '';
 };

 // Función para obtener el nombre de la sucursal de forma segura
 const getSucursalNombre = () => {
   if (!user) return 'Sin sucursal';
   
   if (typeof user.sucursal === 'object' && user.sucursal !== null) {
     return user.sucursal.nombre || 'Sin nombre';
   }
   
   if (user.sucursalObj && typeof user.sucursalObj === 'object') {
     return user.sucursalObj.nombre || 'Sin nombre';
   }
   
   // Si es un string (ID) u otro formato, simplemente mostramos el ID
   return `Sucursal ID: ${user.sucursal || 'N/A'}`;
 };

 return (
   <div className="d-flex flex-column min-vh-100">
     <header>
       <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
         <div className="container">
           <Link className="navbar-brand" to="/">JQ Q Berraquera</Link>
           
           <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
             <span className="navbar-toggler-icon"></span>
           </button>
           
           <div className="collapse navbar-collapse" id="navbarNav">
             <ul className="navbar-nav me-auto">
               {user?.rol === 'administrador' && (
                 <>
                   <li className="nav-item">
                     <Link className={`nav-link ${isActive('/admin/dashboard')}`} to="/admin/dashboard">Dashboard</Link>
                   </li>
                   <li className="nav-item">
                     <Link className={`nav-link ${isActive('/admin/sucursales')}`} to="/admin/sucursales">Sucursales</Link>
                   </li>
                   <li className="nav-item">
                     <Link className={`nav-link ${isActive('/admin/usuarios')}`} to="/admin/usuarios">Usuarios</Link>
                   </li>
                   <li className="nav-item">
                     <Link className={`nav-link ${isActive('/admin/productos')}`} to="/admin/productos">Productos</Link>
                   </li>
                   <li className="nav-item">
                     <Link className={`nav-link ${isActive('/admin/categorias')}`} to="/admin/categorias">Categorías</Link>
                   </li>
                   <li className="nav-item">
                     <Link className={`nav-link ${isActive('/admin/ingredientes')}`} to="/admin/ingredientes">Ingredientes</Link>
                   </li>
                   <li className="nav-item">
                     <Link className={`nav-link ${isActive('/admin/reportes')}`} to="/admin/reportes">Reportes</Link>
                   </li>
                   <li className="nav-item">
                     <Link className={`nav-link ${isActive('/cajero/ventas')}`} to="/cajero/ventas">Punto de Venta</Link>
                   </li>
                 </>
               )}
               
               {/* Para otros roles se pueden agregar más menús aquí */}
             </ul>
             
             {user && (
               <div className="d-flex">
                 <span className="navbar-text me-3">
                   {user.nombre || 'Usuario'} | {getSucursalNombre()}
                 </span>
                 <button className="btn btn-outline-light btn-sm" onClick={handleLogout}>
                   Cerrar Sesión
                 </button>
               </div>
             )}
           </div>
         </div>
       </nav>
     </header>
     
     <main className="flex-grow-1">
       <div className="container py-4">
         {children}
       </div>
     </main>
     
     <footer className="bg-light py-3 mt-auto">
       <div className="container text-center">
         <span className="text-muted">
           Sistema de Gestión JQ Q Berraquera &copy; 2025
         </span>
       </div>
     </footer>
   </div>
 );
};

export default MainLayout;