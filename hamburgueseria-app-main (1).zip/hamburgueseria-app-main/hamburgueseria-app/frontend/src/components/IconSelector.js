import React from 'react';

// Definición de iconos para los productos
const iconos = [
  // Hamburguesas
  { id: 'hamburguesa-normal', nombre: 'Hamburguesa Normal', simbolo: '🍔' },
  { id: 'hamburguesa-especial', nombre: 'Hamburguesa Especial', simbolo: '🥪' },
  { id: 'hamburguesa-doble', nombre: 'Hamburguesa Doble', simbolo: '🍔🍔' },
  
  // Perros Calientes
  { id: 'perro-sencillo', nombre: 'Perro Caliente Sencillo', simbolo: '🌭' },
  { id: 'perro-especial', nombre: 'Perro Caliente Especial', simbolo: '🌭+' },
  
  // Chorizos
  { id: 'chorizo-normal', nombre: 'Chorizo Normal', simbolo: '🥓' },
  { id: 'chorizo-especial', nombre: 'Chorizo Especial', simbolo: '🥓+' },
  
  // Arepas
  { id: 'arepa-sola', nombre: 'Arepa Sola', simbolo: '⚪' },
  { id: 'arepa-chorizo', nombre: 'Arepa con Chorizo', simbolo: '🥮' },
  { id: 'arepa-completa', nombre: 'Arepa Completa', simbolo: '🥮+' },
  
  // Adicionales
  { id: 'chorizo-solo', nombre: 'Chorizo Solo', simbolo: '🥓' },
  { id: 'huevos-codorniz', nombre: 'Huevos de Codorniz', simbolo: '🥚' },
  
  // Bebidas
  { id: 'vaso-gaseosa', nombre: 'Vaso de Gaseosa', simbolo: '🥤' },
  { id: 'botella-gaseosa', nombre: 'Botella de Gaseosa', simbolo: '🍾' },
  { id: 'jugo', nombre: 'Jugo', simbolo: '🧃' },
  
  // Combos
  { id: 'combo', nombre: 'Combo', simbolo: '🍔+🥤' },
];

// Función para obtener el símbolo según el ID del icono
export const getIconoSimbolo = (iconoId) => {
  const icono = iconos.find(item => item.id === iconoId);
  return icono ? icono.simbolo : '📦';
};

const IconSelector = ({ value, onChange }) => {
  return (
    <div className="mb-3">
      <label className="form-label">Ícono del Producto</label>
      <div className="d-flex flex-wrap gap-2 border rounded p-3 bg-light">
        {iconos.map(icono => (
          <div 
            key={icono.id}
            onClick={() => onChange(icono.id)}
            className={`d-flex flex-column align-items-center justify-content-center p-2 rounded ${value === icono.id ? 'bg-primary text-white' : 'bg-white'}`}
            style={{ 
              cursor: 'pointer', 
              width: '80px', 
              height: '80px',
              borderRadius: '8px',
              border: '1px solid #dee2e6',
              boxShadow: value === icono.id ? '0 0 0 2px #0d6efd' : 'none',
              transition: 'all 0.2s ease'
            }}
          >
            <span style={{ fontSize: '32px' }} className="mb-1">{icono.simbolo}</span>
            <span className="small text-center" style={{ fontSize: '10px' }}>{icono.nombre}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default IconSelector;