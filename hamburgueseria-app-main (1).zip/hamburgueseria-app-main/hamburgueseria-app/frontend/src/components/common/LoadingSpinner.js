import React from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Spinner from 'react-bootstrap/Spinner';

const LoadingSpinner = () => {
  return (
    <Container className="d-flex justify-content-center align-items-center" 
               style={{ minHeight: '100vh' }}>
      <Row>
        <Col className="text-center">
          <Spinner animation="border" role="status" variant="primary">
            <span className="visually-hidden">Cargando...</span>
          </Spinner>
          <p className="mt-2">Cargando...</p>
        </Col>
      </Row>
    </Container>
  );
};

export default LoadingSpinner;