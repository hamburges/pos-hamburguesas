import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import cajaService from '../../services/cajaService';
import { formatearMoneda, formatearFecha } from '../../utils/formatters';
import ventaService from '../../services/ventaService';

const CierreCaja = () => {
  const [montoCierreReal, setMontoCierreReal] = useState('');
  const [notasCierre, setNotasCierre] = useState('');
  const [codigoAutorizacion, setCodigoAutorizacion] = useState(''); // NUEVO: Campo para código PIN
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [cajaActual, setCajaActual] = useState(null);
  const [cargandoCaja, setCargandoCaja] = useState(true);
  const [ventas, setVentas] = useState([]);
  // Nuevo: Desglose de ventas por método
  const [ventasPorMetodo, setVentasPorMetodo] = useState({
    efectivo: 0,
    nequi: 0,
    daviplata: 0,
    transferencia: 0
  });
  
  const [resumenCaja, setResumenCaja] = useState({
    monto_apertura: 0,
    total_ventas: 0,
    total_ingresos: 0,
    total_egresos: 0,
    monto_cierre_sistema: 0
  });
  
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);
  
  // Cargar datos de la caja actual
  useEffect(() => {
    const cargarCajaActual = async () => {
      try {
        setCargandoCaja(true);
        const respuesta = await cajaService.obtenerCajaActual();
        
        if (respuesta.success) {
          setCajaActual(respuesta.data);
          
          // Cargar todas las ventas del ciclo (no solo efectivo)
          const ventasResp = await ventaService.obtenerVentas({
            ciclo_caja: respuesta.data._id,
            estado: 'completada'
          });
          
          if (ventasResp.success) {
            setVentas(ventasResp.data);
            
            // Inicializar desglose por método
            const desglosePorMetodo = {
              efectivo: 0,
              nequi: 0,
              daviplata: 0,
              transferencia: 0
            };
            
            // Procesar ventas para obtener montos por método de pago
            ventasResp.data.forEach(venta => {
              // Si tiene desglose detallado
              if (venta.detalles_pago && venta.detalles_pago.montos_por_metodo) {
                venta.detalles_pago.montos_por_metodo.forEach(metodoPago => {
                  const { metodo, monto } = metodoPago;
                  if (metodo in desglosePorMetodo) {
                    desglosePorMetodo[metodo] += Number(monto);
                  }
                });
              } 
              // Para compatibilidad con ventas antiguas
              else if (venta.metodo_pago !== 'mixto') {
                desglosePorMetodo[venta.metodo_pago] += Number(venta.total);
              }
            });
            
            // Actualizar estado con el desglose
            setVentasPorMetodo(desglosePorMetodo);
            
            // Calcular total de ventas (todas)
            const totalVentas = ventasResp.data.reduce(
              (sum, venta) => sum + venta.total, 0
            );
            
            // Calcular total de movimientos
            const totalIngresos = respuesta.data.movimientos?.reduce(
              (sum, mov) => mov.tipo === 'ingreso' ? sum + mov.monto : sum, 0
            ) || 0;
            
            const totalEgresos = respuesta.data.movimientos?.reduce(
              (sum, mov) => mov.tipo === 'egreso' ? sum + mov.monto : sum, 0
            ) || 0;
            
            // Calcular monto teórico de cierre (SOLO EFECTIVO + movimientos)
            const montoCierreSistema = respuesta.data.monto_apertura + desglosePorMetodo.efectivo + totalIngresos - totalEgresos;
            
            setResumenCaja({
              monto_apertura: respuesta.data.monto_apertura,
              total_ventas: totalVentas,
              total_ingresos: totalIngresos,
              total_egresos: totalEgresos,
              monto_cierre_sistema: montoCierreSistema
            });
          }
        }
      } catch (error) {
        if (error.response && error.response.status === 404) {
          // No hay caja abierta, redirigir a apertura
          navigate('/cajero/caja/apertura');
        } else {
          setError('Error al cargar información de la caja');
          console.error(error);
        }
      } finally {
        setCargandoCaja(false);
      }
    };
    
    cargarCajaActual();
  }, [navigate]);
  
  const handleCerrarCaja = async (e) => {
    e.preventDefault();
    
    if (!montoCierreReal || isNaN(parseFloat(montoCierreReal)) || parseFloat(montoCierreReal) < 0) {
      setError('Por favor ingresa un monto de cierre válido');
      return;
    }
    
    // NUEVO: Validar código de autorización
    if (!codigoAutorizacion) {
      setError('Se requiere el código PIN de autorización para cerrar la caja');
      return;
    }
    
    try {
      setLoading(true);
      setError(null);
      
      // MODIFICADO: Incluir código de autorización y ID del ciclo
      const respuesta = await cajaService.cerrarCaja({
        id: cajaActual._id, // Asegurar que enviamos el ID del ciclo
        monto_final: parseFloat(montoCierreReal),
        observaciones: notasCierre,
        codigo_autorizacion: codigoAutorizacion // Enviar código de autorización
      });
      
      if (respuesta.success) {
        // Navegar a la página de detalle de cierre
        navigate(`/cajero/caja/detalle/${respuesta.data.ciclo._id || respuesta.data._id}`);
      }
    } catch (error) {
      // Manejo mejorado de errores específicos
      if (error.response?.status === 401) {
        setError('Código de autorización inválido. Se requiere un PIN válido de administrador.');
      } else {
        setError(error.response?.data?.message || 'Error al cerrar la caja');
      }
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
    
  // Calcular diferencia entre monto real y sistema
  const calcularDiferencia = () => {
    if (!montoCierreReal) return 0;
    
    const diferencia = parseFloat(montoCierreReal) - resumenCaja.monto_cierre_sistema;
    return diferencia;
  };
  
  // Determinar clase CSS según la diferencia
  const getDiferenciaClass = () => {
    const diferencia = calcularDiferencia();
    
    if (diferencia === 0) return 'text-success';
    if (diferencia > 0) return 'text-primary';
    return 'text-danger';
  };
  
  if (cargandoCaja) {
    return <div className="text-center p-5">Cargando información de la caja...</div>;
  }
  
  if (!cajaActual) {
    return <div className="text-center p-5">No hay una caja abierta. Redirigiendo...</div>;
  }
  
  return (
    <div className="container py-4">
      <div className="row">
        <div className="col-lg-8">
          <div className="card mb-4">
            <div className="card-header bg-primary text-white">
              <h3 className="card-title mb-0">Cierre de Caja</h3>
            </div>
            <div className="card-body">
              <div className="row mb-4">
                <div className="col-md-6">
                  <p className="mb-1">
                    <strong>Cajero:</strong> {user?.nombre}
                  </p>
                  <p className="mb-1">
                    <strong>Sucursal:</strong> {user?.sucursal?.nombre}
                  </p>
                  <p className="mb-1">
                    <strong>Fecha de apertura:</strong> {formatearFecha(cajaActual.fecha_apertura)}
                  </p>
                </div>
                <div className="col-md-6">
                  <p className="mb-1">
                    <strong>Monto de apertura:</strong> {formatearMoneda(cajaActual.monto_apertura)}
                  </p>
                  <p className="mb-1">
                    <strong>Total ventas:</strong> {formatearMoneda(resumenCaja.total_ventas)}
                  </p>
                  <p className="mb-1">
                    <strong>Fecha de cierre:</strong> {formatearFecha(new Date())}
                  </p>
                </div>
              </div>
              
              {/* Nuevo: Tabla de desglose por método de pago */}
              <div className="table-responsive mb-4">
                <h4>Desglose de Ventas por Método de Pago</h4>
                <table className="table table-striped">
                  <thead>
                    <tr>
                      <th>Método de Pago</th>
                      <th className="text-end">Monto</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Efectivo</td>
                      <td className="text-end">{formatearMoneda(ventasPorMetodo.efectivo)}</td>
                    </tr>
                    <tr>
                      <td>Nequi</td>
                      <td className="text-end">{formatearMoneda(ventasPorMetodo.nequi)}</td>
                    </tr>
                    <tr>
                      <td>Daviplata</td>
                      <td className="text-end">{formatearMoneda(ventasPorMetodo.daviplata)}</td>
                    </tr>
                    <tr>
                      <td>Transferencia Bancaria</td>
                      <td className="text-end">{formatearMoneda(ventasPorMetodo.transferencia)}</td>
                    </tr>
                    <tr className="table-primary">
                      <th>Total Ventas</th>
                      <th className="text-end">{formatearMoneda(resumenCaja.total_ventas)}</th>
                    </tr>
                  </tbody>
                </table>
              </div>
              
              <div className="table-responsive mb-4">
                <h4>Arqueo de Caja (Solo Efectivo)</h4>
                <table className="table table-striped">
                  <thead>
                    <tr>
                      <th>Concepto</th>
                      <th className="text-end">Monto</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Monto de apertura</td>
                      <td className="text-end">{formatearMoneda(resumenCaja.monto_apertura)}</td>
                    </tr>
                    <tr>
                      <td>Ventas en efectivo</td>
                      <td className="text-end">{formatearMoneda(ventasPorMetodo.efectivo)}</td>
                    </tr>
                    <tr>
                      <td>Total ingresos</td>
                      <td className="text-end">{formatearMoneda(resumenCaja.total_ingresos)}</td>
                    </tr>
                    <tr>
                      <td>Total egresos</td>
                      <td className="text-end">- {formatearMoneda(resumenCaja.total_egresos)}</td>
                    </tr>
                    <tr className="table-primary">
                      <th>Total en caja (sistema)</th>
                      <th className="text-end">{formatearMoneda(resumenCaja.monto_cierre_sistema)}</th>
                    </tr>
                  </tbody>
                </table>
              </div>
              
              <form onSubmit={handleCerrarCaja}>
                <div className="mb-3">
                  <label htmlFor="montoCierreReal" className="form-label">
                    Monto Real en Caja (Conteo físico)
                  </label>
                  <div className="input-group">
                    <span className="input-group-text">$</span>
                    <input
                      type="number"
                      className="form-control"
                      id="montoCierreReal"
                      value={montoCierreReal}
                      onChange={(e) => setMontoCierreReal(e.target.value)}
                      required
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                    />
                  </div>
                  <div className="form-text">
                    Ingresa el monto exacto en efectivo que cuentas físicamente en la caja.
                  </div>
                </div>
                
                {/* NUEVO: Campo para código de autorización */}
                <div className="mb-3">
                  <label htmlFor="codigoAutorizacion" className="form-label">
                    Código PIN de Autorización
                  </label>
                  <input
                    type="password"
                    className="form-control"
                    id="codigoAutorizacion"
                    value={codigoAutorizacion}
                    onChange={(e) => setCodigoAutorizacion(e.target.value)}
                    required
                    maxLength="6"
                    placeholder="Ingrese el PIN de administrador"
                  />
                  <div className="form-text">
                    Se requiere el PIN de un administrador para autorizar el cierre de caja.
                  </div>
                </div>
                
                {montoCierreReal && (
                  <div className={`alert ${getDiferenciaClass() === 'text-success' ? 'alert-success' : 'alert-warning'}`}>
                    <strong>Diferencia: </strong>
                    <span className={getDiferenciaClass()}>
                      {formatearMoneda(calcularDiferencia())}
                    </span>
                    {calcularDiferencia() !== 0 && (
                      <p className="mt-2 mb-0">
                        {calcularDiferencia() > 0 
                          ? 'Sobra dinero en la caja. Verifica nuevamente tu conteo.' 
                          : 'Falta dinero en la caja. Verifica nuevamente tu conteo.'}
                      </p>
                    )}
                  </div>
                )}
                
                <div className="mb-3">
                  <label htmlFor="notasCierre" className="form-label">
                    Notas de Cierre
                  </label>
                  <textarea
                    className="form-control"
                    id="notasCierre"
                    value={notasCierre}
                    onChange={(e) => setNotasCierre(e.target.value)}
                    rows="3"
                    placeholder="Añade notas o justificación si hay diferencias..."
                  ></textarea>
                </div>
                
                {error && (
                  <div className="alert alert-danger" role="alert">
                    {error}
                  </div>
                )}
                
                <div className="d-grid gap-2">
                  <button 
                    type="submit" 
                    className="btn btn-primary"
                    disabled={loading}
                  >
                    {loading ? 'Cerrando caja...' : 'Cerrar Caja'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        
        <div className="col-lg-4">
          <div className="card">
            <div className="card-header bg-info text-white">
              <h4 className="card-title mb-0">Movimientos</h4>
            </div>
            <div className="card-body">
              {!cajaActual.movimientos || cajaActual.movimientos.length === 0 ? (
                <div className="alert alert-info">
                  No hay movimientos registrados en esta caja.
                </div>
              ) : (
                <div className="table-responsive">
                  <table className="table table-sm">
                    <thead>
                      <tr>
                        <th>Tipo</th>
                        <th>Concepto</th>
                        <th className="text-end">Monto</th>
                      </tr>
                    </thead>
                    <tbody>
                      {cajaActual.movimientos.map((mov, index) => (
                        <tr key={index}>
                          <td>
                            <span className={`badge ${mov.tipo === 'ingreso' ? 'bg-success' : 'bg-danger'}`}>
                              {mov.tipo}
                            </span>
                          </td>
                          <td>{mov.concepto}</td>
                          <td className="text-end">{formatearMoneda(mov.monto)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
  
export default CierreCaja;