import React, { useState, useEffect, useRef, useContext } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useReactToPrint } from 'react-to-print';
import cajaService from '../../services/cajaService';
import ventaService from '../../services/ventaService';
import { formatearMoneda, formatearFecha } from '../../utils/formatters';
import { AuthContext } from '../../context/AuthContext';

const DetalleCaja = () => {
  const [caja, setCaja] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  // Estados para autorización
  const [requiereAutorizacion, setRequiereAutorizacion] = useState(false);
  const [codigoAutorizacion, setCodigoAutorizacion] = useState('');
  const [verificandoAutorizacion, setVerificandoAutorizacion] = useState(false);
  const [errorAutorizacion, setErrorAutorizacion] = useState(null);
  // Estado para desglose por método de pago
  const [ventasPorMetodo, setVentasPorMetodo] = useState({
    efectivo: 0,
    nequi: 0,
    daviplata: 0,
    transferencia: 0
  });
  // Estado para movimientos
  const [movimientos, setMovimientos] = useState([]);
  const [resumenMovimientos, setResumenMovimientos] = useState({
    totalIngresos: 0,
    totalEgresos: 0,
    balance: 0
  });
  
  const { id } = useParams();
  const navigate = useNavigate();
  const reporteRef = useRef();
  const { user } = useContext(AuthContext);
  
  // Función para cargar datos del ciclo/caja
  const cargarDetalleCiclo = async (codigo = null) => {
    try {
      setLoading(true);
      setError(null);
      
      const respuesta = await cajaService.obtenerDetalleCaja(id, codigo);
      console.log("Respuesta de API:", respuesta);
      
      if (respuesta.success) {
        setCaja(respuesta.data);
        
        // Verificar si se requiere autorización adicional
        if (respuesta.data.requiere_autorizacion) {
          setRequiereAutorizacion(true);
        } else {
          setRequiereAutorizacion(false);
          
          // Calcular desglose por método de pago si hay ventas
          if (respuesta.data.ventas && respuesta.data.ventas.length > 0) {
            console.log("Ventas recibidas:", respuesta.data.ventas);
            calcularDesglosePorMetodo(respuesta.data.ventas);
          } else {
            // Si no hay ventas en la respuesta, intentar cargarlas aparte
            console.log("No hay ventas en la respuesta, intentando cargarlas separadamente");
            cargarVentasSeparadamente(respuesta.data._id);
          }
          
          // Cargar movimientos para este ciclo
          cargarMovimientos(respuesta.data._id);
        }
      }
    } catch (error) {
      if (error.response?.status === 403) {
        setError('No tienes permiso para ver este ciclo de caja');
      } else {
        setError('Error al cargar los detalles de la caja');
      }
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  
  // Nueva función para cargar movimientos
  const cargarMovimientos = async (cicloId) => {
    try {
      const respuesta = await cajaService.obtenerMovimientos(cicloId);
      
      if (respuesta.success) {
        console.log("Movimientos cargados:", respuesta.data);
        setMovimientos(respuesta.data.movimientos || []);
        setResumenMovimientos(respuesta.data.resumen || {
          totalIngresos: 0,
          totalEgresos: 0,
          balance: 0
        });
      }
    } catch (error) {
      console.error("Error al cargar movimientos:", error);
    }
  };
  
  // Función para cargar ventas si no vienen incluidas
  const cargarVentasSeparadamente = async (cicloId) => {
    try {
      const ventasResp = await ventaService.obtenerVentas({
        ciclo_caja: cicloId,
        estado: 'completada'
      });
      
      if (ventasResp.success && ventasResp.data && ventasResp.data.length > 0) {
        // Actualizar el ciclo con las ventas obtenidas
        setCaja(prev => ({
          ...prev,
          ventas: ventasResp.data
        }));
        
        // Procesar las ventas para el desglose
        calcularDesglosePorMetodo(ventasResp.data);
      }
    } catch (error) {
      console.error("Error al cargar ventas separadamente:", error);
    }
  };
  
  // Función para calcular el desglose de ventas por método de pago
  const calcularDesglosePorMetodo = (ventas) => {
    console.log("Calculando desglose para ventas:", ventas);
    
    const desglose = {
      efectivo: 0,
      nequi: 0,
      daviplata: 0,
      transferencia: 0
    };
    
    ventas.forEach(venta => {
      // Si tiene desglose detallado usando la nueva estructura
      if (venta.detalles_pago && venta.detalles_pago.montos_por_metodo) {
        console.log("Venta con montos_por_metodo:", venta.detalles_pago.montos_por_metodo);
        venta.detalles_pago.montos_por_metodo.forEach(metodoPago => {
          const { metodo, monto } = metodoPago;
          if (metodo in desglose) {
            desglose[metodo] += Number(monto);
          }
        });
      } 
      // Para compatibilidad con ventas antiguas
      else if (venta.metodo_pago !== 'mixto') {
        console.log("Venta método simple:", venta.metodo_pago, venta.total);
        desglose[venta.metodo_pago] += Number(venta.total);
      }
    });
    
    console.log("Desglose calculado:", desglose);
    setVentasPorMetodo(desglose);
  };
  
  // Cargar datos al montar el componente
  useEffect(() => {
    // Carga inicial sin código
    cargarDetalleCiclo();
  }, [id]);
  
  // Función para manejar envío de autorización
  const handleSubmitAutorizacion = async (e) => {
    e.preventDefault();
    
    if (!codigoAutorizacion) {
      setErrorAutorizacion('Ingrese un código de autorización');
      return;
    }
    
    try {
      setVerificandoAutorizacion(true);
      setErrorAutorizacion(null);
      
      // Recargar los detalles con el código de autorización
      await cargarDetalleCiclo(codigoAutorizacion);
      
      // Si llegamos aquí y aún requiere autorización, es inválida
      if (requiereAutorizacion) {
        setErrorAutorizacion('Código de autorización inválido');
      }
    } catch (error) {
      setErrorAutorizacion('Error al verificar el código de autorización');
      console.error(error);
    } finally {
      setVerificandoAutorizacion(false);
    }
  };
  
  const handlePrint = useReactToPrint({
    content: () => reporteRef.current,
    documentTitle: `Reporte-Caja-${id}`,
  });
  
  // Calcular totales para el reporte
  const calcularTotales = () => {
    if (!caja) return {};
    
    const totalVentas = caja.ventas?.reduce(
      (sum, venta) => sum + venta.total, 0
    ) || 0;
    
    // Usar los totales de movimientos ya calculados
    const totalIngresos = resumenMovimientos.totalIngresos || 0;
    const totalEgresos = resumenMovimientos.totalEgresos || 0;
    
    return {
      total_ventas: totalVentas,
      total_ingresos: totalIngresos,
      total_egresos: totalEgresos
    };
  };
  
  // Determinar clase CSS según la diferencia
  const getDiferenciaClass = (diferencia) => {
    if (diferencia === 0) return 'text-success';
    if (diferencia > 0) return 'text-primary';
    return 'text-danger';
  };
  
  if (loading && !caja) {
    return <div className="text-center p-5">Cargando detalles de la caja...</div>;
  }
  
  if (error) {
    return (
      <div className="alert alert-danger m-5" role="alert">
        {error}
      </div>
    );
  }
  
  if (!caja) {
    return (
      <div className="alert alert-warning m-5" role="alert">
        No se encontró la información de la caja solicitada.
      </div>
    );
  }
  
  // Mostrar formulario de autorización si se requiere
  if (requiereAutorizacion) {
    return (
      <div className="container py-5">
        <div className="row justify-content-center">
          <div className="col-md-6">
            <div className="card">
              <div className="card-header bg-warning">
                <h5 className="card-title mb-0">Se requiere autorización</h5>
              </div>
              <div className="card-body">
                <p>Para ver los detalles completos de este ciclo de caja, se requiere un código PIN de autorización de administrador.</p>
                
                <form onSubmit={handleSubmitAutorizacion}>
                  <div className="mb-3">
                    <label htmlFor="codigoAutorizacion" className="form-label">Código PIN de Administrador</label>
                    <input 
                      type="password" 
                      className="form-control"
                      id="codigoAutorizacion"
                      value={codigoAutorizacion}
                      onChange={(e) => setCodigoAutorizacion(e.target.value)}
                      disabled={verificandoAutorizacion}
                      maxLength="6"
                      placeholder="Ingrese el PIN del administrador"
                      required
                    />
                  </div>
                  
                  {errorAutorizacion && (
                    <div className="alert alert-danger">{errorAutorizacion}</div>
                  )}
                  
                  <div className="d-grid gap-2">
                    <button 
                      type="submit" 
                      className="btn btn-primary"
                      disabled={verificandoAutorizacion}
                    >
                      {verificandoAutorizacion ? 'Verificando...' : 'Verificar Autorización'}
                    </button>
                    <button
                      type="button"
                      className="btn btn-outline-secondary"
                      onClick={() => navigate('/cajero/caja/historial')}
                    >
                      Volver al Historial
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  // Si no requiere autorización o ya fue autorizado, mostrar detalles
  const totales = calcularTotales();
  const tieneDatosCompletos = caja.monto_final !== undefined;
  
  return (
    <div className="container py-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Detalle de Cierre de Caja</h2>
        <div>
          {/* Solo mostrar botón de impresión si está cerrada y tenemos datos completos */}
          {caja.estado === 'cerrado' && tieneDatosCompletos && (
            <button 
              onClick={handlePrint} 
              className="btn btn-primary me-2"
            >
              <i className="bi bi-printer"></i> Imprimir Reporte
            </button>
          )}
          <button 
            onClick={() => navigate('/cajero/caja/historial')} 
            className="btn btn-secondary"
          >
            Volver al Historial
          </button>
        </div>
      </div>
      
      <div className="card mb-4">
        <div className="card-header bg-primary text-white">
          <h3 className="card-title mb-0">Resumen de Caja #{caja._id.substring(0, 8)}</h3>
        </div>
        <div className="card-body">
          <div className="row mb-4">
            <div className="col-md-6">
              <p className="mb-1">
                <strong>Cajero:</strong> {caja.usuario_apertura?.nombre || 'No disponible'}
              </p>
              <p className="mb-1">
                <strong>Sucursal:</strong> {caja.sucursal?.nombre || 'No disponible'}
              </p>
              <p className="mb-1">
                <strong>Estado:</strong> 
                <span className={`ms-2 badge ${caja.estado === 'activo' ? 'bg-success' : 'bg-secondary'}`}>
                  {caja.estado === 'activo' ? 'Abierta' : 'Cerrada'}
                </span>
              </p>
            </div>
            <div className="col-md-6">
              <p className="mb-1">
                <strong>Fecha de apertura:</strong> {formatearFecha(caja.fecha_apertura)}
              </p>
              <p className="mb-1">
                <strong>Fecha de cierre:</strong> {caja.fecha_cierre ? formatearFecha(caja.fecha_cierre) : 'No cerrada'}
              </p>
              {caja.admin_autorizador && (
                <p className="mb-1">
                  <strong>Autorizado por:</strong> {caja.admin_autorizador.nombre || 'Administrador'}
                </p>
              )}
            </div>
          </div>
          
          {/* NUEVO: Desglose por método de pago */}
          {(caja.estado === 'cerrado' && tieneDatosCompletos) || caja.estado === 'activo' ? (
            <div className="row mb-4">
              <div className="col-md-12">
                <h4>Desglose de Ventas por Método de Pago</h4>
                <div className="table-responsive">
                  <table className="table table-striped">
                    <thead>
                      <tr>
                        <th>Método de Pago</th>
                        <th className="text-end">Monto</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Efectivo</td>
                        <td className="text-end">{formatearMoneda(ventasPorMetodo.efectivo)}</td>
                      </tr>
                      <tr>
                        <td>Nequi</td>
                        <td className="text-end">{formatearMoneda(ventasPorMetodo.nequi)}</td>
                      </tr>
                      <tr>
                        <td>Daviplata</td>
                        <td className="text-end">{formatearMoneda(ventasPorMetodo.daviplata)}</td>
                      </tr>
                      <tr>
                        <td>Transferencia Bancaria</td>
                        <td className="text-end">{formatearMoneda(ventasPorMetodo.transferencia)}</td>
                      </tr>
                      <tr className="table-primary">
                        <th>Total Ventas</th>
                        <th className="text-end">{formatearMoneda(totales.total_ventas)}</th>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : null}
          
          {/* NUEVO: Mostrar movimientos de caja */}
          <div className="row mb-4">
            <div className="col-md-12">
              <h4>Movimientos de Caja</h4>
              {movimientos.length === 0 ? (
                <div className="alert alert-info">
                  No hay movimientos registrados en este ciclo de caja.
                </div>
              ) : (
                <div className="table-responsive">
                  <table className="table table-striped">
                    <thead>
                      <tr>
                        <th>Tipo</th>
                        <th>Concepto</th>
                        <th>Fecha</th>
                        <th className="text-end">Monto</th>
                      </tr>
                    </thead>
                    <tbody>
                      {movimientos.map((mov, index) => (
                        <tr key={index}>
                          <td>
                            <span className={`badge ${mov.tipo === 'ingreso' ? 'bg-success' : 'bg-danger'}`}>
                              {mov.tipo}
                            </span>
                          </td>
                          <td>{mov.concepto}</td>
                          <td>{formatearFecha(mov.fecha)}</td>
                          <td className="text-end">{formatearMoneda(mov.monto)}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="table-info">
                        <td colSpan="3">Total Ingresos:</td>
                        <td className="text-end">{formatearMoneda(resumenMovimientos.totalIngresos)}</td>
                      </tr>
                      <tr className="table-info">
                        <td colSpan="3">Total Egresos:</td>
                        <td className="text-end">{formatearMoneda(resumenMovimientos.totalEgresos)}</td>
                      </tr>
                      <tr className="table-primary">
                        <th colSpan="3">Balance de Movimientos:</th>
                        <th className="text-end">{formatearMoneda(resumenMovimientos.balance)}</th>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              )}
            </div>
          </div>
          
          {/* Solo mostrar tabla detallada si está cerrada y tenemos datos completos */}
          {caja.estado === 'cerrado' && tieneDatosCompletos ? (
            <div className="row">
              <div className="col-md-12">
                <h4>Arqueo de Caja (Solo Efectivo)</h4>
                <div className="table-responsive">
                  <table className="table table-striped">
                    <thead>
                      <tr>
                        <th>Concepto</th>
                        <th className="text-end">Monto</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Monto de apertura</td>
                        <td className="text-end">{formatearMoneda(caja.monto_apertura)}</td>
                      </tr>
                      <tr>
                        <td>Ventas en efectivo</td>
                        <td className="text-end">{formatearMoneda(ventasPorMetodo.efectivo)}</td>
                      </tr>
                      <tr>
                        <td>Total ingresos</td>
                        <td className="text-end">{formatearMoneda(totales.total_ingresos)}</td>
                      </tr>
                      <tr>
                        <td>Total egresos</td>
                        <td className="text-end">- {formatearMoneda(totales.total_egresos)}</td>
                      </tr>
                      <tr className="table-primary">
                        <th>Total en caja (sistema)</th>
                        <th className="text-end">
                          {formatearMoneda(caja.monto_apertura + ventasPorMetodo.efectivo + 
                          totales.total_ingresos - totales.total_egresos)}
                        </th>
                      </tr>
                      <tr>
                        <td>Monto real (conteo físico)</td>
                        <td className="text-end">{formatearMoneda(caja.monto_final)}</td>
                      </tr>
                      <tr className={caja.diferencia === 0 ? 'table-success' : 'table-warning'}>
                        <th>Diferencia</th>
                        <th className={`text-end ${getDiferenciaClass(caja.diferencia)}`}>
                          {formatearMoneda(caja.diferencia)}
                        </th>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            <div className="alert alert-info">
              {caja.estado === 'activo' 
                ? 'Esta caja está actualmente abierta. No hay información de cierre disponible.' 
                : 'Se requiere autorización de administrador para ver los detalles completos.'}
            </div>
          )}
          
          {caja.observaciones && (
            <div className="alert alert-info mt-3">
              <strong>Observaciones:</strong> {caja.observaciones}
            </div>
          )}
        </div>
      </div>
      
      {/* Solo mostrar ventas si es caja cerrada y tenemos datos completos o si está activa */}
      {(caja.estado === 'cerrado' && tieneDatosCompletos) || caja.estado === 'activo' ? (
        <div className="row">
          <div className="col-md-12">
            <div className="card mb-4">
              <div className="card-header bg-info text-white">
                <h4 className="card-title mb-0">Ventas Registradas</h4>
              </div>
              <div className="card-body">
                {!caja.ventas || caja.ventas.length === 0 ? (
                  <div className="alert alert-info">
                    No hay ventas registradas en esta caja.
                  </div>
                ) : (
                  <div className="table-responsive">
                    <table className="table table-sm">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Fecha</th>
                          <th>Método</th>
                          <th className="text-end">Monto</th>
                        </tr>
                      </thead>
                      <tbody>
                        {caja.ventas.map((venta) => (
                          <tr key={venta._id}>
                            <td>{venta._id.substring(0, 8)}</td>
                            <td>{formatearFecha(venta.fecha)}</td>
                            <td>{venta.metodo_pago}</td>
                            <td className="text-end">{formatearMoneda(venta.total)}</td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="table-primary">
                          <th colSpan="3">Total</th>
                          <th className="text-end">{formatearMoneda(totales.total_ventas)}</th>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      ) : null}
      
      {/* Componente para impresión - actualizado para incluir desglose por método y movimientos */}
      <div className="d-none">
        <div ref={reporteRef} className="p-4">
          <div style={{ maxWidth: '800px', margin: '0 auto' }}>
            <div style={{ textAlign: 'center', marginBottom: '20px' }}>
              <h2 style={{ margin: '0', color: '#0d6efd' }}>
                Resumen de Caja #{caja._id.substring(0, 8)}
              </h2>
              <hr style={{ border: '1px solid #0d6efd', marginTop: '8px' }} />
            </div>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
              <div>
                <p style={{ margin: '5px 0' }}>
                  <strong>Cajero:</strong> {caja.usuario_apertura?.nombre || 'No disponible'}
                </p>
                <p style={{ margin: '5px 0' }}>
                  <strong>Sucursal:</strong> {caja.sucursal?.nombre || 'No disponible'}
                </p>
                <p style={{ margin: '5px 0' }}>
                  <strong>Estado:</strong> {caja.estado === 'activo' ? 'Abierta' : 'Cerrada'}
                </p>
              </div>
              <div>
                <p style={{ margin: '5px 0' }}>
                  <strong>Fecha de apertura:</strong> {formatearFecha(caja.fecha_apertura)}
                </p>
                <p style={{ margin: '5px 0' }}>
                  <strong>Fecha de cierre:</strong> {caja.fecha_cierre ? formatearFecha(caja.fecha_cierre) : 'No cerrada'}
                </p>
                {caja.admin_autorizador && (
                  <p style={{ margin: '5px 0' }}>
                    <strong>Autorizado por:</strong> {caja.admin_autorizador.nombre || 'Administrador'}
                  </p>
                )}
              </div>
            </div>
            
            {/* Desglose por Método de Pago */}
            <div style={{ marginBottom: '20px' }}>
              <h3 style={{ backgroundColor: '#0d6efd', color: 'white', padding: '8px', borderRadius: '4px' }}>
                Desglose de Ventas por Método de Pago
              </h3>
              <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '10px' }}>
                <thead>
                  <tr style={{ backgroundColor: '#f8f9fa' }}>
                    <th style={{ textAlign: 'left', padding: '8px', borderBottom: '2px solid #dee2e6' }}>Método de Pago</th>
                    <th style={{ textAlign: 'right', padding: '8px', borderBottom: '2px solid #dee2e6' }}>Monto</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style={{ padding: '8px', borderBottom: '1px solid #dee2e6' }}>Efectivo</td>
                    <td style={{ textAlign: 'right', padding: '8px', borderBottom: '1px solid #dee2e6' }}>
                      {formatearMoneda(ventasPorMetodo.efectivo)}
                    </td>
                  </tr>
                  <tr>
                    <td style={{ padding: '8px', borderBottom: '1px solid #dee2e6' }}>Nequi</td>
                    <td style={{ textAlign: 'right', padding: '8px', borderBottom: '1px solid #dee2e6' }}>
                      {formatearMoneda(ventasPorMetodo.nequi)}
                    </td>
                  </tr>
                  <tr>
                    <td style={{ padding: '8px', borderBottom: '1px solid #dee2e6' }}>Daviplata</td>
                    <td style={{ textAlign: 'right', padding: '8px', borderBottom: '1px solid #dee2e6' }}>
                      {formatearMoneda(ventasPorMetodo.daviplata)}
                    </td>
                  </tr>
                  <tr>
                    <td style={{ padding: '8px', borderBottom: '1px solid #dee2e6' }}>Transferencia Bancaria</td>
                    <td style={{ textAlign: 'right', padding: '8px', borderBottom: '1px solid #dee2e6' }}>
                      {formatearMoneda(ventasPorMetodo.transferencia)}
                    </td>
                  </tr>
                  <tr style={{ backgroundColor: '#cfe2ff' }}>
                    <td style={{ padding: '8px', fontWeight: 'bold', borderBottom: '2px solid #0d6efd' }}>
                      Total Ventas
                    </td>
                    <td style={{ textAlign: 'right', padding: '8px', fontWeight: 'bold', borderBottom: '2px solid #0d6efd' }}>
                      {formatearMoneda(totales.total_ventas)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            {/* Movimientos de Caja para impresión */}
            <div style={{ marginBottom: '20px' }}>
              <h3 style={{ backgroundColor: '#0dcaf0', color: 'white', padding: '8px', borderRadius: '4px' }}>
                Movimientos de Caja
              </h3>
              {movimientos.length === 0 ? (
                <div style={{ 
                  backgroundColor: '#d1ecf1', 
                  color: '#0c5460', 
                  padding: '10px', 
                  borderRadius: '4px',
                  marginTop: '10px'
                }}>
                  No hay movimientos registrados en esta caja.
                </div>
              ) : (
                <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '10px' }}>
                  <thead>
                    <tr style={{ backgroundColor: '#f8f9fa' }}>
                      <th style={{ textAlign: 'left', padding: '8px', borderBottom: '2px solid #dee2e6' }}>Tipo</th>
                      <th style={{ textAlign: 'left', padding: '8px', borderBottom: '2px solid #dee2e6' }}>Concepto</th>
                      <th style={{ textAlign: 'left', padding: '8px', borderBottom: '2px solid #dee2e6' }}>Fecha</th>
                      <th style={{ textAlign: 'right', padding: '8px', borderBottom: '2px solid #dee2e6' }}>Monto</th>
                    </tr>
                  </thead>
                  <tbody>
                    {movimientos.map((mov, index) => (
                      <tr key={index}>
                        <td style={{ padding: '6px', borderBottom: '1px solid #dee2e6' }}>
                          <span style={{ 
                            backgroundColor: mov.tipo === 'ingreso' ? '#198754' : '#dc3545',
                            color: 'white',
                            padding: '2px 6px',
                            borderRadius: '4px',
                            fontSize: '0.85em'
                          }}>
                            {mov.tipo}
                          </span>
                        </td>
                        <td style={{ padding: '6px', borderBottom: '1px solid #dee2e6' }}>
                          {mov.concepto}
                        </td>
                        <td style={{ padding: '6px', borderBottom: '1px solid #dee2e6' }}>
                          {formatearFecha(mov.fecha)}
                        </td>
                        <td style={{ textAlign: 'right', padding: '6px', borderBottom: '1px solid #dee2e6' }}>
                          {formatearMoneda(mov.monto)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr style={{ backgroundColor: '#d1ecf1' }}>
                      <td colSpan="3" style={{ padding: '8px', borderBottom: '1px solid #0dcaf0' }}>Total Ingresos:</td>
                      <td style={{ textAlign: 'right', padding: '8px', borderBottom: '1px solid #0dcaf0' }}>
                        {formatearMoneda(resumenMovimientos.totalIngresos)}
                      </td>
                    </tr>
                    <tr style={{ backgroundColor: '#d1ecf1' }}>
                      <td colSpan="3" style={{ padding: '8px', borderBottom: '1px solid #0dcaf0' }}>Total Egresos:</td>
                      <td style={{ textAlign: 'right', padding: '8px', borderBottom: '1px solid #0dcaf0' }}>
                        {formatearMoneda(resumenMovimientos.totalEgresos)}
                      </td>
                    </tr>
                    <tr style={{ backgroundColor: '#cfe2ff' }}>
                      <td colSpan="3" style={{ padding: '8px', fontWeight: 'bold', borderBottom: '2px solid #0d6efd' }}>
                        Balance de Movimientos:
                      </td>
                      <td style={{ textAlign: 'right', padding: '8px', fontWeight: 'bold', borderBottom: '2px solid #0d6efd' }}>
                        {formatearMoneda(resumenMovimientos.balance)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              )}
            </div>
            
            {/* Arqueo de Caja (Solo Efectivo) */}
            {caja.estado === 'cerrado' && tieneDatosCompletos && (
              <div style={{ marginBottom: '20px' }}>
                <h3 style={{ backgroundColor: '#0d6efd', color: 'white', padding: '8px', borderRadius: '4px' }}>
                  Arqueo de Caja (Solo Efectivo)
                </h3>
                <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '10px' }}>
                  <thead>
                    <tr style={{ backgroundColor: '#f8f9fa' }}>
                      <th style={{ textAlign: 'left', padding: '8px', borderBottom: '2px solid #dee2e6' }}>Concepto</th>
                      <th style={{ textAlign: 'right', padding: '8px', borderBottom: '2px solid #dee2e6' }}>Monto</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td style={{ padding: '8px', borderBottom: '1px solid #dee2e6' }}>Monto de apertura</td>
                      <td style={{ textAlign: 'right', padding: '8px', borderBottom: '1px solid #dee2e6' }}>
                        {formatearMoneda(caja.monto_apertura)}
                      </td>
                    </tr>
                    <tr>
                      <td style={{ padding: '8px', borderBottom: '1px solid #dee2e6' }}>Ventas en efectivo</td>
                      <td style={{ textAlign: 'right', padding: '8px', borderBottom: '1px solid #dee2e6' }}>
                        {formatearMoneda(ventasPorMetodo.efectivo)}
                      </td>
                    </tr>
                    <tr>
                      <td style={{ padding: '8px', borderBottom: '1px solid #dee2e6' }}>Total ingresos</td>
                      <td style={{ textAlign: 'right', padding: '8px', borderBottom: '1px solid #dee2e6' }}>
                        {formatearMoneda(totales.total_ingresos)}
                      </td>
                    </tr>
                    <tr>
                      <td style={{ padding: '8px', borderBottom: '1px solid #dee2e6' }}>Total egresos</td>
                      <td style={{ textAlign: 'right', padding: '8px', borderBottom: '1px solid #dee2e6' }}>
                        - {formatearMoneda(totales.total_egresos)}
                      </td>
                    </tr>
                    <tr style={{ backgroundColor: '#cfe2ff' }}>
                      <td style={{ padding: '8px', fontWeight: 'bold', borderBottom: '2px solid #0d6efd' }}>
                        Total en caja (sistema)
                      </td>
                      <td style={{ textAlign: 'right', padding: '8px', fontWeight: 'bold', borderBottom: '2px solid #0d6efd' }}>
                        {formatearMoneda(caja.monto_apertura + ventasPorMetodo.efectivo + 
                          totales.total_ingresos - totales.total_egresos)}
                      </td>
                    </tr>
                    <tr>
                      <td style={{ padding: '8px', borderBottom: '1px solid #dee2e6' }}>Monto real (conteo físico)</td>
                      <td style={{ textAlign: 'right', padding: '8px', borderBottom: '1px solid #dee2e6' }}>
                        {formatearMoneda(caja.monto_final)}
                      </td>
                    </tr>
                    <tr style={{ backgroundColor: caja.diferencia === 0 ? '#d1e7dd' : '#fff3cd' }}>
                      <td style={{ padding: '8px', fontWeight: 'bold', borderBottom: '2px solid #dee2e6' }}>
                        Diferencia
                      </td>
                      <td style={{ 
                        textAlign: 'right', 
                        padding: '8px', 
                        fontWeight: 'bold',
                        color: caja.diferencia === 0 ? 'green' : (caja.diferencia > 0 ? 'blue' : 'red'),
                        borderBottom: '2px solid #dee2e6'
                      }}>
                        {formatearMoneda(caja.diferencia)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}
            
            {/* Ventas Registradas */}
            {caja.ventas && caja.ventas.length > 0 && (
              <div style={{ marginBottom: '20px' }}>
                <h3 style={{ backgroundColor: '#0dcaf0', color: 'white', padding: '8px', borderRadius: '4px' }}>
                  Ventas Registradas
                </h3>
                <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '10px' }}>
                  <thead>
                    <tr style={{ backgroundColor: '#f8f9fa' }}>
                      <th style={{ textAlign: 'left', padding: '8px', borderBottom: '2px solid #dee2e6' }}>ID</th>
                      <th style={{ textAlign: 'left', padding: '8px', borderBottom: '2px solid #dee2e6' }}>Fecha</th>
                      <th style={{ textAlign: 'left', padding: '8px', borderBottom: '2px solid #dee2e6' }}>Método</th>
                      <th style={{ textAlign: 'right', padding: '8px', borderBottom: '2px solid #dee2e6' }}>Monto</th>
                    </tr>
                  </thead>
                  <tbody>
                    {caja.ventas.map((venta) => (
                      <tr key={venta._id}>
                        <td style={{ padding: '6px', borderBottom: '1px solid #dee2e6' }}>
                          {venta._id.substring(0, 8)}
                        </td>
                        <td style={{ padding: '6px', borderBottom: '1px solid #dee2e6' }}>
                          {formatearFecha(venta.fecha)}
                        </td>
                        <td style={{ padding: '6px', borderBottom: '1px solid #dee2e6' }}>
                          {venta.metodo_pago}
                        </td>
                        <td style={{ textAlign: 'right', padding: '6px', borderBottom: '1px solid #dee2e6' }}>
                          {formatearMoneda(venta.total)}
                        </td>
                      </tr>
                    ))}
                    <tr style={{ backgroundColor: '#cfe2ff' }}>
                      <td colSpan="3" style={{ padding: '8px', fontWeight: 'bold', borderBottom: '2px solid #0d6efd' }}>
                        Total
                      </td>
                      <td style={{ textAlign: 'right', padding: '8px', fontWeight: 'bold', borderBottom: '2px solid #0d6efd' }}>
                        {formatearMoneda(totales.total_ventas)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}
            
            {/* Observaciones */}
            {caja.observaciones && (
              <div style={{ 
                backgroundColor: '#d1ecf1', 
                color: '#0c5460', 
                padding: '10px', 
                borderRadius: '4px',
                marginTop: '10px'
              }}>
                <strong>Observaciones:</strong> {caja.observaciones}
              </div>
            )}
            
            {/* Pie de página */}
            <div style={{ 
              marginTop: '20px', 
              textAlign: 'center',
              borderTop: '1px solid #dee2e6',
              paddingTop: '10px',
              fontSize: '0.9em',
              color: '#6c757d'
            }}>
              <p style={{ margin: '5px 0' }}>
                Generado el {formatearFecha(new Date())} por el sistema JQ Q Berraquera
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DetalleCaja;