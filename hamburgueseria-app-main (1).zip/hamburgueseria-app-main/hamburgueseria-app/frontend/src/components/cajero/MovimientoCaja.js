import React, { useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import cajaService from '../../services/cajaService';
import ventaService from '../../services/ventaService';
import { formatearMoneda, formatearFecha } from '../../utils/formatters';

const MovimientoCaja = () => {
  const [formData, setFormData] = useState({
    tipo: 'ingreso',
    concepto: '',
    monto: '',
    codigo_autorizacion: ''
  });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [cicloActual, setCicloActual] = useState(null);
  const [verificandoCiclo, setVerificandoCiclo] = useState(true);
  // Nuevo: Estado para desglose por método
  const [ventasPorMetodo, setVentasPorMetodo] = useState({
    efectivo: 0,
    nequi: 0,
    daviplata: 0,
    transferencia: 0
  });
  
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);
  
  // Verificar si hay un ciclo abierto
  useEffect(() => {
    const verificarCicloAbierto = async () => {
      try {
        setVerificandoCiclo(true);
        const respuesta = await cajaService.obtenerCajaActual();
        
        if (respuesta.success) {
          setCicloActual(respuesta.data);
          console.log("Ciclo actual cargado:", respuesta.data);
          
          // Verificar si ya tenemos el desglose de ventas
          if (respuesta.data.desglose_ventas) {
            setVentasPorMetodo(respuesta.data.desglose_ventas);
          } else {
            // Si no existe el desglose en respuesta, intentar calcularlo
            cargarVentasPorMetodo(respuesta.data._id);
          }
        }
      } catch (error) {
        console.error("Error al verificar ciclo:", error);
        
        // Si el error es 404, significa que no hay ciclo abierto
        if (error.response && error.response.status === 404) {
          // Redirigir a apertura de ciclo
          navigate('/cajero/caja/apertura');
        } else {
          setError('Error al verificar estado del ciclo de caja');
        }
      } finally {
        setVerificandoCiclo(false);
      }
    };
    
    verificarCicloAbierto();
  }, [navigate]);
  
  // Nuevo: Función para cargar ventas y calcular desglose por método
  const cargarVentasPorMetodo = async (cicloId) => {
    try {
      const ventasResp = await ventaService.obtenerVentas({
        ciclo_caja: cicloId,
        estado: 'completada'
      });
      
      if (ventasResp.success && ventasResp.data) {
        // Inicializar desglose
        const desglose = {
          efectivo: 0,
          nequi: 0,
          daviplata: 0,
          transferencia: 0
        };
        
        ventasResp.data.forEach(venta => {
          // Si tiene desglose detallado
          if (venta.detalles_pago && venta.detalles_pago.montos_por_metodo) {
            venta.detalles_pago.montos_por_metodo.forEach(metodoPago => {
              const { metodo, monto } = metodoPago;
              if (metodo in desglose) {
                desglose[metodo] += Number(monto);
              }
            });
          } 
          // Para compatibilidad con ventas antiguas
          else if (venta.metodo_pago !== 'mixto') {
            desglose[venta.metodo_pago] += Number(venta.total);
          }
        });
        
        setVentasPorMetodo(desglose);
      }
    } catch (error) {
      console.error("Error al cargar ventas para desglose:", error);
    }
  };
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Resetear mensajes
    setError(null);
    setSuccess(false);
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.concepto.trim()) {
      setError('El concepto es obligatorio');
      return;
    }
    
    if (!formData.monto || isNaN(parseFloat(formData.monto)) || parseFloat(formData.monto) <= 0) {
      setError('Ingresa un monto válido mayor a cero');
      return;
    }
    
    // Validar autorización para egresos si no es administrador
    if (formData.tipo === 'egreso' && user?.rol !== 'administrador' && !formData.codigo_autorizacion) {
      setError('Se requiere un código PIN para registrar un egreso');
      return;
    }
    
    try {
      setLoading(true);
      setError(null);
      
      // Asegurarse de que tenemos un ID de ciclo
      if (!cicloActual || !cicloActual._id) {
        setError('No se puede agregar movimiento: ciclo de caja no identificado');
        setLoading(false);
        return;
      }
      
      // Preparar datos del movimiento
      const datos = {
        ciclo_id: cicloActual._id, // ID del ciclo (fundamental para la nueva API)
        tipo: formData.tipo,
        concepto: formData.concepto,
        monto: parseFloat(formData.monto),
        codigo_autorizacion: formData.codigo_autorizacion || undefined
      };
      
      const respuesta = await cajaService.agregarMovimiento(datos);
      
      if (respuesta.success) {
        setSuccess(true);
        // Actualizar el ciclo
        setCicloActual(respuesta.data);
        // Actualizar desglose si está disponible
        if (respuesta.data.desglose_ventas) {
          setVentasPorMetodo(respuesta.data.desglose_ventas);
        }
        // Limpiar formulario
        setFormData({
          tipo: 'ingreso',
          concepto: '',
          monto: '',
          codigo_autorizacion: ''
        });
      }
    } catch (error) {
      console.error("Error al registrar movimiento:", error);
      setError(error.response?.data?.message || 'Error al registrar el movimiento');
    } finally {
      setLoading(false);
    }
  };
  
  // Calcular totales para mostrar en la tarjeta de información
  const calcularTotales = () => {
    if (!cicloActual) return { totalIngresos: 0, totalEgresos: 0 };
    
    const totalIngresos = cicloActual.movimientos?.reduce(
      (sum, mov) => mov.tipo === 'ingreso' ? sum + mov.monto : sum, 0
    ) || 0;
    
    const totalEgresos = cicloActual.movimientos?.reduce(
      (sum, mov) => mov.tipo === 'egreso' ? sum + mov.monto : sum, 0
    ) || 0;
    
    return { totalIngresos, totalEgresos };
  };
  
  if (verificandoCiclo) {
    return <div className="text-center p-5">Verificando estado del ciclo de caja...</div>;
  }
  
  if (!cicloActual) {
    return <div className="text-center p-5">No hay un ciclo de caja abierto. Redirigiendo...</div>;
  }
  
  // Verificar si el objeto cicloActual tiene movimientos, si no, inicializar como array vacío
  const movimientos = cicloActual.movimientos || [];
  const totales = calcularTotales();
  
  return (
    <div className="container py-4">
      <div className="row">
        <div className="col-lg-6">
          <div className="card mb-4">
            <div className="card-header bg-primary text-white">
              <h3 className="card-title mb-0">Registrar Movimiento de Caja</h3>
            </div>
            <div className="card-body">
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label className="form-label">Tipo de Movimiento</label>
                  <div>
                    <div className="form-check form-check-inline">
                      <input
                        className="form-check-input"
                        type="radio"
                        name="tipo"
                        id="tipoIngreso"
                        value="ingreso"
                        checked={formData.tipo === 'ingreso'}
                        onChange={handleChange}
                      />
                      <label className="form-check-label text-success" htmlFor="tipoIngreso">
                        Ingreso
                      </label>
                    </div>
                    <div className="form-check form-check-inline">
                      <input
                        className="form-check-input"
                        type="radio"
                        name="tipo"
                        id="tipoEgreso"
                        value="egreso"
                        checked={formData.tipo === 'egreso'}
                        onChange={handleChange}
                      />
                      <label className="form-check-label text-danger" htmlFor="tipoEgreso">
                        Egreso
                      </label>
                    </div>
                  </div>
                </div>
                
                <div className="mb-3">
                  <label htmlFor="concepto" className="form-label">Concepto</label>
                  <input
                    type="text"
                    className="form-control"
                    id="concepto"
                    name="concepto"
                    value={formData.concepto}
                    onChange={handleChange}
                    placeholder="Ej. Pago a proveedor, Ingreso por venta externa, etc."
                    required
                  />
                </div>
                
                <div className="mb-3">
                  <label htmlFor="monto" className="form-label">Monto</label>
                  <div className="input-group">
                    <span className="input-group-text">$</span>
                    <input
                      type="number"
                      className="form-control"
                      id="monto"
                      name="monto"
                      value={formData.monto}
                      onChange={handleChange}
                      required
                      min="0.01"
                      step="0.01"
                      placeholder="0.00"
                    />
                  </div>
                </div>
                
                {formData.tipo === 'egreso' && user?.rol !== 'administrador' && (
                  <div className="mb-3">
                    <label htmlFor="codigo_autorizacion" className="form-label">
                      Código PIN de Autorización
                    </label>
                    <input
                      type="password"
                      className="form-control"
                      id="codigo_autorizacion"
                      name="codigo_autorizacion"
                      value={formData.codigo_autorizacion}
                      onChange={handleChange}
                      required
                      maxLength="6"
                      placeholder="Ingrese el PIN de administrador"
                    />
                    <div className="form-text">
                      Se requiere el PIN de un administrador para autorizar egresos.
                    </div>
                  </div>
                )}
                
                {error && (
                  <div className="alert alert-danger" role="alert">
                    {error}
                  </div>
                )}
                
                {success && (
                  <div className="alert alert-success" role="alert">
                    Movimiento registrado correctamente.
                  </div>
                )}
                
                <div className="d-grid gap-2">
                  <button 
                    type="submit" 
                    className="btn btn-primary"
                    disabled={loading}
                  >
                    {loading ? 'Registrando...' : 'Registrar Movimiento'}
                  </button>
                  <button 
                    type="button" 
                    className="btn btn-secondary"
                    onClick={() => navigate('/cajero/ventas')}
                  >
                    Volver al Punto de Venta
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        
        <div className="col-lg-6">
          {/* Nuevo: Tarjeta con desglose de ventas por método */}
          <div className="card mb-4">
            <div className="card-header bg-success text-white">
              <h4 className="card-title mb-0">Desglose de Ventas</h4>
            </div>
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-sm">
                  <thead>
                    <tr>
                      <th>Método de Pago</th>
                      <th className="text-end">Monto</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Efectivo</td>
                      <td className="text-end">{formatearMoneda(ventasPorMetodo.efectivo)}</td>
                    </tr>
                    <tr>
                      <td>Nequi</td>
                      <td className="text-end">{formatearMoneda(ventasPorMetodo.nequi)}</td>
                    </tr>
                    <tr>
                      <td>Daviplata</td>
                      <td className="text-end">{formatearMoneda(ventasPorMetodo.daviplata)}</td>
                    </tr>
                    <tr>
                      <td>Transferencia</td>
                      <td className="text-end">{formatearMoneda(ventasPorMetodo.transferencia)}</td>
                    </tr>
                    <tr className="table-primary">
                      <th>Total Ventas</th>
                      <th className="text-end">
                        {formatearMoneda(
                          ventasPorMetodo.efectivo +
                          ventasPorMetodo.nequi +
                          ventasPorMetodo.daviplata +
                          ventasPorMetodo.transferencia
                        )}
                      </th>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          
          <div className="card mb-4">
            <div className="card-header bg-info text-white">
              <h4 className="card-title mb-0">Movimientos Registrados</h4>
            </div>
            <div className="card-body">
              {movimientos.length === 0 ? (
                <div className="alert alert-info">
                  No hay movimientos registrados en este ciclo de caja.
                </div>
              ) : (
                <div className="table-responsive">
                  <table className="table table-sm">
                    <thead>
                      <tr>
                        <th>Tipo</th>
                        <th>Concepto</th>
                        <th>Fecha</th>
                        <th className="text-end">Monto</th>
                      </tr>
                    </thead>
                    <tbody>
                      {movimientos.map((mov, index) => (
                        <tr key={index}>
                          <td>
                            <span className={`badge ${mov.tipo === 'ingreso' ? 'bg-success' : 'bg-danger'}`}>
                              {mov.tipo}
                            </span>
                          </td>
                          <td>{mov.concepto}</td>
                          <td>{formatearFecha(mov.fecha)}</td>
                          <td className="text-end">{formatearMoneda(mov.monto)}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="table-info">
                        <td colSpan="3">Total Ingresos:</td>
                        <td className="text-end">{formatearMoneda(totales.totalIngresos)}</td>
                      </tr>
                      <tr className="table-info">
                        <td colSpan="3">Total Egresos:</td>
                        <td className="text-end">{formatearMoneda(totales.totalEgresos)}</td>
                      </tr>
                      <tr className="table-primary">
                        <th colSpan="3">Balance de Movimientos:</th>
                        <th className="text-end">{formatearMoneda(totales.totalIngresos - totales.totalEgresos)}</th>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              )}
            </div>
          </div>
          
          <div className="card">
            <div className="card-header bg-secondary text-white">
              <h4 className="card-title mb-0">Información del Ciclo</h4>
            </div>
            <div className="card-body">
              <ul className="list-group">
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <span>Cajero:</span>
                  <span className="fw-bold">{cicloActual.usuario_apertura?.nombre || user?.nombre}</span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <span>Sucursal:</span>
                  <span className="fw-bold">{cicloActual.sucursal?.nombre || user?.sucursal?.nombre}</span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <span>Monto de apertura:</span>
                  <span className="fw-bold">{formatearMoneda(cicloActual.monto_apertura)}</span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <span>Fecha de apertura:</span>
                  <span className="fw-bold">{formatearFecha(cicloActual.fecha_apertura)}</span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <span>Saldo actual (efectivo):</span>
                  <span className="fw-bold text-success">
                    {formatearMoneda(
                      cicloActual.monto_apertura + 
                      ventasPorMetodo.efectivo + 
                      totales.totalIngresos - 
                      totales.totalEgresos
                    )}
                  </span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <span>ID del ciclo:</span>
                  <span className="fw-bold text-muted">{cicloActual._id.substring(0, 8)}</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovimientoCaja;