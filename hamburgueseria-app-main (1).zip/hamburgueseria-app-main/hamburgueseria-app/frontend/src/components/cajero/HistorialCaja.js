import React, { useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import cajaService from '../../services/cajaService';
import { formatearMoneda, formatearFecha } from '../../utils/formatters';

const HistorialCaja = () => {
  const [cajas, setCajas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filtros, setFiltros] = useState({
    fechaInicio: '',
    fechaFin: '',
    sucursal: '',
    estado: '', // Nuevo: filtrado por estado
    pagina: 1,   // Nuevo: soporte de paginación
    limite: 10   // Nuevo: límite por página
  });
  const [paginacion, setPaginacion] = useState({
    total: 0,
    paginas: 1
  });
  
  const { user } = useContext(AuthContext);
  
  useEffect(() => {
    const cargarHistorial = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const respuesta = await cajaService.obtenerHistorial(filtros);
        
        if (respuesta.success) {
          // Revisar si la respuesta tiene un formato diferente (meta vs pagination)
          if (respuesta.data && Array.isArray(respuesta.data)) {
            setCajas(respuesta.data);
            
            // Actualizar información de paginación si está disponible
            if (respuesta.meta) {
              setPaginacion({
                total: respuesta.meta.total || 0,
                paginas: respuesta.meta.paginas || 1,
                pagina: respuesta.meta.pagina || 1,
                limite: respuesta.meta.limite || 10
              });
            }
          } else {
            // Fallback para formato antiguo
            setCajas(respuesta.data || []);
          }
        }
      } catch (error) {
        setError('Error al cargar el historial de cajas');
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    
    cargarHistorial();
  }, [filtros]);
  
  const handleFiltroChange = (e) => {
    const { name, value } = e.target;
    
    // Si cambiamos cualquier filtro que no sea la página, resetear a página 1
    if (name !== 'pagina') {
      setFiltros(prev => ({
        ...prev,
        [name]: value,
        pagina: 1 // Resetear a primera página
      }));
    } else {
      setFiltros(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };
  
  const handleSubmitFiltro = (e) => {
    e.preventDefault();
    // Los filtros ya se están aplicando mediante el efecto
  };
  
  const handleResetFiltro = () => {
    setFiltros({
      fechaInicio: '',
      fechaFin: '',
      sucursal: '',
      estado: '',
      pagina: 1,
      limite: 10
    });
  };
  
  const handleChangePagina = (nuevaPagina) => {
    if (nuevaPagina > 0 && nuevaPagina <= paginacion.paginas) {
      setFiltros(prev => ({
        ...prev,
        pagina: nuevaPagina
      }));
    }
  };
  
  // Determinar clase CSS según la diferencia
  const getDiferenciaClass = (diferencia) => {
    if (diferencia === 0) return 'text-success';
    if (diferencia > 0) return 'text-primary';
    return 'text-danger';
  };
  
  if (loading && cajas.length === 0) {
    return <div className="text-center p-5">Cargando historial de cajas...</div>;
  }
  
  return (
    <div className="container py-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Historial de Cajas</h2>
        <Link to="/cajero/ventas" className="btn btn-primary">
          Volver al Punto de Venta
        </Link>
      </div>
      
      <div className="card mb-4">
        <div className="card-header bg-primary text-white">
          <h4 className="card-title mb-0">Filtros</h4>
        </div>
        <div className="card-body">
          <form onSubmit={handleSubmitFiltro}>
            <div className="row">
              <div className="col-md-3 mb-3">
                <label htmlFor="fechaInicio" className="form-label">Fecha Inicio</label>
                <input
                  type="date"
                  className="form-control"
                  id="fechaInicio"
                  name="fechaInicio"
                  value={filtros.fechaInicio}
                  onChange={handleFiltroChange}
                />
              </div>
              <div className="col-md-3 mb-3">
                <label htmlFor="fechaFin" className="form-label">Fecha Fin</label>
                <input
                  type="date"
                  className="form-control"
                  id="fechaFin"
                  name="fechaFin"
                  value={filtros.fechaFin}
                  onChange={handleFiltroChange}
                />
              </div>
              {/* Nuevo: Filtro por estado */}
              <div className="col-md-3 mb-3">
                <label htmlFor="estado" className="form-label">Estado</label>
                <select
                  className="form-select"
                  id="estado"
                  name="estado"
                  value={filtros.estado}
                  onChange={handleFiltroChange}
                >
                  <option value="">Todos</option>
                  <option value="activo">Activo</option>
                  <option value="cerrado">Cerrado</option>
                </select>
              </div>
              {user?.rol === 'administrador' && (
                <div className="col-md-3 mb-3">
                  <label htmlFor="sucursal" className="form-label">Sucursal</label>
                  <select
                    className="form-select"
                    id="sucursal"
                    name="sucursal"
                    value={filtros.sucursal}
                    onChange={handleFiltroChange}
                  >
                    <option value="">Todas las sucursales</option>
                    {/* Aquí deberías mapear las sucursales disponibles */}
                    {/* Por ahora dejamos solo la opción placeholder */}
                  </select>
                </div>
              )}
              <div className="col-12">
                <div className="d-flex justify-content-end">
                  <button 
                    type="button" 
                    className="btn btn-secondary me-2"
                    onClick={handleResetFiltro}
                  >
                    Limpiar Filtros
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Aplicar Filtros
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
      
      {error && (
        <div className="alert alert-danger" role="alert">
          {error}
        </div>
      )}
      
      {!loading && cajas.length === 0 ? (
        <div className="alert alert-info">
          No se encontraron registros de caja con los filtros seleccionados.
        </div>
      ) : (
        <>
          <div className="table-responsive">
            <table className="table table-striped table-hover">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Cajero</th>
                  <th>Sucursal</th>
                  <th>Fecha Apertura</th>
                  <th>Fecha Cierre</th>
                  <th>Estado</th>
                  <th className="text-end">Monto Apertura</th>
                  {/* Solo mostrar estas columnas para ciclos cerrados */}
                  <th className="text-end">Monto Final</th>
                  <th className="text-end">Diferencia</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {cajas.map((caja) => (
                  <tr key={caja._id}>
                    <td>{caja._id.substring(0, 8)}</td>
                    <td>{caja.usuario_apertura?.nombre || 'No disponible'}</td>
                    <td>{caja.sucursal?.nombre || 'No disponible'}</td>
                    <td>{formatearFecha(caja.fecha_apertura)}</td>
                    <td>{caja.fecha_cierre ? formatearFecha(caja.fecha_cierre) : '-'}</td>
                    <td>
                      <span className={`badge ${caja.estado === 'activo' ? 'bg-success' : 'bg-secondary'}`}>
                        {caja.estado === 'activo' ? 'Activo' : 'Cerrado'}
                      </span>
                    </td>
                    <td className="text-end">{formatearMoneda(caja.monto_apertura)}</td>
                    <td className="text-end">
                      {caja.estado === 'cerrado' && caja.monto_final !== undefined ? 
                        formatearMoneda(caja.monto_final) : '-'}
                    </td>
                    <td className={`text-end ${caja.estado === 'cerrado' && caja.diferencia !== undefined ? 
                      getDiferenciaClass(caja.diferencia) : ''}`}>
                      {caja.estado === 'cerrado' && caja.diferencia !== undefined ? 
                        formatearMoneda(caja.diferencia) : '-'}
                    </td>
                    <td>
                      <Link 
                        to={`/cajero/caja/detalle/${caja._id}`} 
                        className="btn btn-sm btn-info"
                      >
                        Detalles
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {/* Paginación */}
          {paginacion.paginas > 1 && (
            <nav aria-label="Navegación de páginas">
              <ul className="pagination justify-content-center">
                <li className={`page-item ${filtros.pagina <= 1 ? 'disabled' : ''}`}>
                  <button 
                    className="page-link" 
                    onClick={() => handleChangePagina(filtros.pagina - 1)}
                    disabled={filtros.pagina <= 1}
                  >
                    Anterior
                  </button>
                </li>
                
                {/* Mostrar números de página */}
                {[...Array(paginacion.paginas).keys()].map(i => {
                  const num = i + 1;
                  return (
                    <li key={num} className={`page-item ${filtros.pagina === num ? 'active' : ''}`}>
                      <button 
                        className="page-link" 
                        onClick={() => handleChangePagina(num)}
                      >
                        {num}
                      </button>
                    </li>
                  );
                })}
                
                <li className={`page-item ${filtros.pagina >= paginacion.paginas ? 'disabled' : ''}`}>
                  <button 
                    className="page-link" 
                    onClick={() => handleChangePagina(Number(filtros.pagina) + 1)}
                    disabled={filtros.pagina >= paginacion.paginas}
                  >
                    Siguiente
                  </button>
                </li>
              </ul>
            </nav>
          )}
        </>
      )}
    </div>
  );
};

export default HistorialCaja;