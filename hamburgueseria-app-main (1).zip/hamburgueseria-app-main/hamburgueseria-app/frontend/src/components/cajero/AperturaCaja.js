import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import cajaService from '../../services/cajaService';
import CajeroLayout from '../../components/layout/CajeroLayout';
import { formatearMoneda } from '../../utils/formatters';

const AperturaCaja = () => {
  const [montoApertura, setMontoApertura] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [cicloActual, setCicloActual] = useState(null);
  const [verificandoCiclo, setVerificandoCiclo] = useState(true);

  const { user } = useContext(AuthContext);
  const navigate = useNavigate();

  // Verificar si ya hay un ciclo abierto
  useEffect(() => {
    const verificarCicloAbierto = async () => {
      try {
        setVerificandoCiclo(true);
        const respuesta = await cajaService.obtenerCajaActual();
        
        if (respuesta.success && respuesta.data) {
          setCicloActual(respuesta.data);
        }
      } catch (error) {
        // Si el error es 404, significa que no hay ciclo abierto (lo cual es normal)
        if (error.response && error.response.status === 404) {
          setCicloActual(null);
        } else {
          console.error('Error al verificar ciclo abierto:', error);
          setError('Error al verificar si ya existe un ciclo de caja abierto');
        }
      } finally {
        setVerificandoCiclo(false);
      }
    };

    verificarCicloAbierto();
  }, []);

  const handleMontoChange = (e) => {
    // Permitir solo números y puntos
    const valor = e.target.value.replace(/[^0-9.]/g, '');
    setMontoApertura(valor);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validar monto
    const monto = parseFloat(montoApertura);
    if (isNaN(monto) || monto < 0) {
      setError('Por favor ingrese un monto válido');
      return;
    }
    
    try {
      setLoading(true);
      setError(null);
      
      const respuesta = await cajaService.abrirCaja({ monto_apertura: monto });
      
      if (respuesta.success) {
        setSuccess('Ciclo de caja abierto correctamente');
        setCicloActual(respuesta.data);
        
        // Redireccionar después de 2 segundos
        setTimeout(() => {
          navigate('/cajero/ventas');
        }, 2000);
      }
    } catch (error) {
      console.error('Error al abrir ciclo de caja:', error);
      
      // Manejo mejorado de errores específicos
      if (error.response?.status === 400 && error.response?.data?.message.includes('Ya existe')) {
        setError('Ya existe un ciclo de caja abierto en esta sucursal');
      } else {
        setError(error.response?.data?.message || 'Error al abrir el ciclo de caja');
      }
    } finally {
      setLoading(false);
    }
  };

  if (verificandoCiclo) {
    return (
      <CajeroLayout>
        <div className="text-center p-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Verificando ciclo...</span>
          </div>
          <p className="mt-3">Verificando estado del ciclo de caja...</p>
        </div>
      </CajeroLayout>
    );
  }

  if (cicloActual) {
    return (
      <CajeroLayout>
        <div className="container py-4">
          <div className="card border-success">
            <div className="card-header bg-success text-white">
              <h3 className="card-title mb-0">Ciclo de caja ya abierto</h3>
            </div>
            <div className="card-body">
              <p className="lead">Ya tienes un ciclo de caja abierto con los siguientes datos:</p>
              <ul className="list-group mb-4">
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <strong>ID de Ciclo:</strong>
                  <span>{cicloActual._id}</span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <strong>Fecha de Apertura:</strong>
                  <span>{new Date(cicloActual.fecha_apertura).toLocaleString()}</span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <strong>Monto de Apertura:</strong>
                  <span>{formatearMoneda(cicloActual.monto_apertura)}</span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <strong>Cajero:</strong>
                  <span>{cicloActual.usuario_apertura?.nombre || user?.nombre || 'No especificado'}</span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <strong>Sucursal:</strong>
                  <span>{cicloActual.sucursal?.nombre || 'No especificada'}</span>
                </li>
              </ul>
              
              <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                <button
                  className="btn btn-primary"
                  onClick={() => navigate('/cajero/ventas')}
                >
                  Ir a Punto de Venta
                </button>
                <button
                  className="btn btn-info"
                  onClick={() => navigate('/cajero/caja/cierre')}
                >
                  Cerrar este Ciclo
                </button>
              </div>
            </div>
          </div>
        </div>
      </CajeroLayout>
    );
  }

  return (
    <CajeroLayout>
      <div className="container py-4">
        <div className="card">
          <div className="card-header bg-primary text-white">
            <h3 className="card-title mb-0">Apertura de Ciclo de Caja</h3>
          </div>
          <div className="card-body">
            {error && (
              <div className="alert alert-danger" role="alert">
                {error}
              </div>
            )}
            
            {success && (
              <div className="alert alert-success" role="alert">
                {success}
              </div>
            )}
            
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label htmlFor="montoApertura" className="form-label">Monto de Apertura (efectivo inicial en caja)</label>
                <div className="input-group">
                  <span className="input-group-text">$</span>
                  <input
                    type="text"
                    className="form-control"
                    id="montoApertura"
                    value={montoApertura}
                    onChange={handleMontoChange}
                    required
                    disabled={loading}
                    placeholder="0.00"
                  />
                </div>
                <div className="form-text">
                  Ingrese la cantidad de dinero en efectivo con la que inicia este ciclo de caja.
                </div>
              </div>
              
              <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => navigate('/cajero/ventas')}
                  disabled={loading}
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Abriendo Ciclo...
                    </>
                  ) : (
                    'Abrir Ciclo de Caja'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </CajeroLayout>
  );
};

export default AperturaCaja;