import React, { useState } from 'react';

const AutorizacionVentaModal = ({ show, onClose, onConfirm }) => {
  const [codigo, setCodigo] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!codigo) {
      setError('Por favor ingrese el código de autorización');
      return;
    }

    setLoading(true);
    try {
      // Pasar el código ingresado al componente padre
      await onConfirm(codigo);
      // Resetear los campos después de una confirmación exitosa
      setCodigo('');
      setError('');
    } catch (err) {
      setError('Código de autorización incorrecto');
    } finally {
      setLoading(false);
    }
  };

  if (!show) return null;

  return (
    <div className="modal d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Código de Autorización</h5>
            <button type="button" className="btn-close" onClick={onClose}></button>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="modal-body">
              <p>Para esta operación, se requiere un código PIN de autorización de administrador.</p>
              <div className="mb-3">
                <label htmlFor="codigo" className="form-label">Código PIN:</label>
                <input
                  type="password"
                  className={`form-control ${error ? 'is-invalid' : ''}`}
                  id="codigo"
                  value={codigo}
                  onChange={(e) => setCodigo(e.target.value)}
                  required
                  placeholder="Ingrese el PIN de administrador"
                />
                {error && <div className="invalid-feedback">{error}</div>}
              </div>
            </div>
            <div className="modal-footer">
              <button 
                type="button" 
                className="btn btn-secondary" 
                onClick={onClose}
              >
                Cancelar
              </button>
              <button 
                type="submit" 
                className="btn btn-primary" 
                disabled={loading}
              >
                {loading ? 'Verificando...' : 'Verificar'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AutorizacionVentaModal;