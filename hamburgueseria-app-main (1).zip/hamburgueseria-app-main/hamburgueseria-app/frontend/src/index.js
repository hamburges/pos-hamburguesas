import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

// Importar Bootstrap completo - CRÍTICO para la apariencia
import 'bootstrap/dist/css/bootstrap.min.css';

// Cargar bootstrap-icons de forma optimizada pero no tan agresiva
const loadBootstrapIcons = () => {
  // Si ya existen los iconos en la página, no los cargues de nuevo
  if (document.querySelector('link[href*="bootstrap-icons"]')) return;
  
  const link = document.createElement('link');
  link.href = 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css';
  link.rel = 'stylesheet';
  link.type = 'text/css';
  document.head.appendChild(link);
};

// Cargar iconos con pequeño retraso para no bloquear pero asegurar que aparecen pronto
setTimeout(loadBootstrapIcons, 100);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

reportWebVitals();