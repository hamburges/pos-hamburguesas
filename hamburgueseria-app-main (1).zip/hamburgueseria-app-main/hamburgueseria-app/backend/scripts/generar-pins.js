// scripts/generar-pins.js
require('dotenv').config();
const mongoose = require('mongoose');
const Usuario = require('../models/Usuario');

// Configurar conexión a MongoDB
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/hamburgueseria';

// Función para generar PIN aleatorio de 4 dígitos
const generarPIN = () => Math.floor(1000 + Math.random() * 9000).toString();

// Función principal
const generarPINsParaAdministradores = async () => {
  try {
    // Conectar a MongoDB
    await mongoose.connect(MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('Conectado a MongoDB');
    
    // Encontrar administradores sin código de autorización
    const administradores = await Usuario.find({
      rol: 'administrador',
      $or: [
        { codigo_autorizacion: { $exists: false } },
        { codigo_autorizacion: null },
        { codigo_autorizacion: '' }
      ]
    });
    
    console.log(`Se encontraron ${administradores.length} administradores sin PIN`);
    
    // Generar y guardar PINs
    for (const admin of administradores) {
      const pin = generarPIN();
      admin.codigo_autorizacion = pin;
      await admin.save();
      console.log(`PIN generado para ${admin.nombre} (${admin.usuario}): ${pin}`);
    }
    
    console.log('Proceso completado exitosamente');
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    // Cerrar conexión a MongoDB
    await mongoose.connection.close();
    console.log('Conexión a MongoDB cerrada');
  }
};

// Ejecutar la función principal
generarPINsParaAdministradores();