// backend/scripts/fix-ventas.js
require('dotenv').config();
const mongoose = require('mongoose');
const Venta = require('../models/Venta');

// Obtener la URI de MongoDB desde las variables de entorno
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/hamburgueseria';

const fixVentas = async () => {
  try {
    // Conectar a la base de datos directamente
    await mongoose.connect(MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('Conectado a MongoDB');

    // Obtener todas las ventas
    const ventas = await Venta.find({});
    console.log(`Se encontraron ${ventas.length} ventas para revisar`);

    // Contador de ventas corregidas
    let ventasCorregidas = 0;

    // Procesar cada venta
    for (const venta of ventas) {
      // Mostrar información original
      console.log(`\nVenta ${venta.numero_venta}:`);
      console.log(`- Total original: ${venta.total}`);
      console.log(`- Subtotal original: ${venta.subtotal}`);
      
      // Calcular el subtotal sumando los subtotales de los productos
      let nuevoSubtotal = 0;
      
      // Procesar los productos y sus personalizaciones
      for (const producto of venta.productos) {
        // Valores originales
        console.log(`  Producto ${producto.producto}: cantidad=${producto.cantidad}, precio=${producto.precio_unitario}, subtotal=${producto.subtotal}`);
        
        // Calcular el precio base
        const precioBase = Number(producto.precio_unitario) * Number(producto.cantidad);
        
        // Calcular el total de personalizaciones
        let personalizacionesTotal = 0;
        if (producto.personalizaciones && producto.personalizaciones.length > 0) {
          for (const p of producto.personalizaciones) {
            if (p.accion === 'agregar') {
              const precioPersonalizacion = Number(p.precio) * Number(p.cantidad);
              personalizacionesTotal += precioPersonalizacion;
              console.log(`    Personalización ${p.ingrediente}: acción=${p.accion}, cantidad=${p.cantidad}, precio=${p.precio}, total=${precioPersonalizacion}`);
            }
          }
        }
        
        // Calcular el nuevo subtotal del producto
        const nuevoSubtotalProducto = Math.round((precioBase + personalizacionesTotal) * 100) / 100;
        console.log(`  Nuevo subtotal producto: ${nuevoSubtotalProducto} (precioBase: ${precioBase}, personalizaciones: ${personalizacionesTotal})`);
        
        // Actualizar el subtotal del producto
        producto.subtotal = nuevoSubtotalProducto;
        
        // Sumar al subtotal general
        nuevoSubtotal += nuevoSubtotalProducto;
      }
      
      // Redondear el subtotal
      nuevoSubtotal = Math.round(nuevoSubtotal * 100) / 100;
      
      // Calcular el nuevo total
      const descuento = Number(venta.descuento || 0);
      const nuevoTotal = Math.round((nuevoSubtotal - descuento) * 100) / 100;
      
      // Mostrar información calculada
      console.log(`- Nuevo subtotal calculado: ${nuevoSubtotal}`);
      console.log(`- Descuento: ${descuento}`);
      console.log(`- Nuevo total calculado: ${nuevoTotal}`);
      
      // Verificar si hay cambios
      if (venta.subtotal !== nuevoSubtotal || venta.total !== nuevoTotal) {
        // Actualizar valores
        venta.subtotal = nuevoSubtotal;
        venta.total = nuevoTotal;
        
        // Guardar cambios
        await venta.save();
        console.log(`✓ Venta ${venta.numero_venta} corregida y guardada`);
        ventasCorregidas++;
      } else {
        console.log(`✓ Venta ${venta.numero_venta} ya tiene valores correctos`);
      }
    }
    
    console.log(`\nProceso completado. ${ventasCorregidas} ventas fueron corregidas.`);
  } catch (error) {
    console.error('Error:', error);
  } finally {
    // Cerrar conexión
    mongoose.connection.close();
    console.log('Conexión a MongoDB cerrada');
  }
};

// Ejecutar la función
fixVentas();