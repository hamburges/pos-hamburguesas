// routes/venta.routes.js
const express = require('express');
const router = express.Router();
const ventaController = require('../controllers/venta.controller');
const { verificarToken, verificarRol } = require('../middleware/auth.middleware');

// Obtener todas las ventas (con filtros)
router.get('/', verificarToken, ventaController.obtenerVentas);

// Obtener ventas del día actual (nueva ruta)
router.get('/obtener-dia', verificarToken, ventaController.obtenerVentasDelDia);

// Crear una nueva venta
router.post('/', verificarToken, ventaController.crearVenta);

// Obtener detalles de una venta específica
router.get('/:id', verificarToken, ventaController.obtenerVentaPorId);

// Anular una venta
router.put('/:id/anular', verificarToken, ventaController.anularVenta);

module.exports = router;