// Ruta nueva para backend/routes/config.routes.js
const express = require('express');
const router = express.Router();
const inventarioService = require('../services/inventario.service');
const { verificarToken, verificarRol } = require('../middleware/auth.middleware');

// Obtener configuración actual de criticidad
router.get('/criticidad', verificarToken, verificarRol(['administrador']), (req, res) => {
  try {
    res.status(200).json({
      success: true,
      data: inventarioService.configuracionCriticidad
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al obtener configuración de criticidad',
      error: error.message
    });
  }
});

// Actualizar configuración de criticidad
router.put('/criticidad', verificarToken, verificarRol(['administrador']), (req, res) => {
  try {
    const { nombresCriticos, unidadesCriticas, nivelMinimoPermitido } = req.body;
    
    // Validación de parámetros
    if ((nombresCriticos && !Array.isArray(nombresCriticos)) || 
        (unidadesCriticas && !Array.isArray(unidadesCriticas)) ||
        (nivelMinimoPermitido !== undefined && typeof nivelMinimoPermitido !== 'number')) {
      return res.status(400).json({
        success: false,
        message: 'Formato de configuración inválido'
      });
    }
    
    // Actualizar solo los parámetros proporcionados
    const actualizacion = {};
    if (nombresCriticos) actualizacion.nombresCriticos = nombresCriticos;
    if (unidadesCriticas) actualizacion.unidadesCriticas = unidadesCriticas;
    if (nivelMinimoPermitido !== undefined) actualizacion.nivelMinimoPermitido = nivelMinimoPermitido;
    
    inventarioService.actualizarConfiguracionCriticidad(actualizacion);
    
    res.status(200).json({
      success: true,
      message: 'Configuración de criticidad actualizada correctamente',
      data: inventarioService.configuracionCriticidad
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error al actualizar configuración de criticidad',
      error: error.message
    });
  }
});

module.exports = router;