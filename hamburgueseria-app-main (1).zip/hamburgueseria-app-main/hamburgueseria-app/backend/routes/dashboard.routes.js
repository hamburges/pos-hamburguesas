const express = require('express');
const router = express.Router();
const Usuario = require('../models/Usuario');
const Sucursal = require('../models/Sucursal');
const Producto = require('../models/Producto');
const Ingrediente = require('../models/Ingrediente');

// Endpoint real para dashboard
router.get('/dashboard', async (req, res) => {
  try {
    // Totales
    const totalUsuarios = await Usuario.countDocuments();
    const totalSucursales = await Sucursal.countDocuments({ estado: 'activa' });
    const totalProductos = await Producto.countDocuments();
    const totalIngredientes = await Ingrediente.countDocuments();

    // Sucursales (nombre y estado)
    const sucursales = await Sucursal.find({}, 'nombre estado');

    // Ingredientes con stock bajo (alerta)
    const alertasInventario = await Ingrediente.find({
      $expr: { $lte: ["$stock", "$stock_minimo"] }
    }, 'nombre stock stock_minimo unidad_medida');

    res.json({
      success: true,
      data: {
        totalUsuarios,
        totalSucursales,
        totalProductos,
        totalIngredientes,
        sucursales,
        alertasInventario
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error al obtener datos del dashboard', error: error.message });
  }
});

module.exports = router;
