const express = require('express');
const router = express.Router();
const cajaController = require('../controllers/caja.controller');
const { verificarToken, verificarRol } = require('../middleware/auth.middleware');

// Ruta de prueba
router.get('/test', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Ruta de caja accesible correctamente'
  });
});

// Middleware para verificar roles específicos
const verificarCajero = verificarRol(['administrador', 'cajero']);
const verificarAdmin = verificarRol(['administrador']);

// Rutas para gestión de caja
router.post('/abrir', verificarToken, verificarCajero, cajaController.abrirCaja);
router.get('/actual', verificarToken, verificarCajero, cajaController.obtenerCajaActual);
router.post('/movimiento', verificarToken, verificarCajero, cajaController.agregarMovimiento);
router.post('/cerrar', verificarToken, verificarCajero, cajaController.cerrarCaja);
router.get('/historial', verificarToken, cajaController.obtenerHistorial);
router.get('/:id', verificarToken, cajaController.obtenerDetalleCaja);

module.exports = router;