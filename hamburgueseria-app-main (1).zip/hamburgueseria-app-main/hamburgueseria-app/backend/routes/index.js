// routes/index.js
const express = require('express');
const router = express.Router();

// Importar rutas de cada controlador - Catálogo completo de subsistemas desacoplados
const authRoutes = require('./auth.routes');
const usuarioRoutes = require('./usuario.routes');
const sucursalRoutes = require('./sucursal.routes');
const categoriaRoutes = require('./categoria.routes');
const ingredienteRoutes = require('./ingrediente.routes');
const productoRoutes = require('./producto.routes');
const opcionProductoRoutes = require('./opcion-producto.routes');
const cajaRoutes = require('./caja.routes');
const configRoutes = require('./config.routes');
const cicloCajaRoutes = require('./cicloCaja.routes'); 
const movimientoRoutes = require('./movimiento.routes'); // NUEVO: Importación de rutas de movimientos
const ventaController = require('../controllers/venta.controller');

// Middleware de autenticación
const { verificarToken, verificarRol } = require('../middleware/auth.middleware');

/**
 * Configuración de rutas principales de la API
 * Arquitectura de routing con desacoplamiento total entre subsistemas
 */

// Ruta de estado del API (pública)
router.get('/status', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'API funcionando correctamente',
    version: '0.6', // Actualizada la versión por incorporación de movimientos de caja
    timestamp: new Date()
  });
});

// Asignar rutas específicas - Cada conjunto mantiene responsabilidad única
router.use('/auth', authRoutes);
router.use('/usuarios', usuarioRoutes);
router.use('/sucursales', sucursalRoutes);
router.use('/categorias', categoriaRoutes);
router.use('/ingredientes', ingredienteRoutes);
router.use('/productos', productoRoutes);
router.use('', opcionProductoRoutes);
router.use('/caja', cajaRoutes);
router.use('/config', configRoutes);
router.use('/ciclos-caja', cicloCajaRoutes);
router.use('/movimientos', movimientoRoutes); // NUEVO: Asociación de rutas de movimientos

// Configurar rutas de ventas directamente
const ventaRouter = express.Router();
ventaRouter.get('/', verificarToken, ventaController.obtenerVentas);
ventaRouter.get('/obtener-dia', verificarToken, ventaController.obtenerVentasDelDia);
ventaRouter.post('/', verificarToken, ventaController.crearVenta);
ventaRouter.get('/:id', verificarToken, ventaController.obtenerVentaPorId);
ventaRouter.put('/:id/anular', verificarToken, ventaController.anularVenta);

router.use('/ventas', ventaRouter);

module.exports = router;