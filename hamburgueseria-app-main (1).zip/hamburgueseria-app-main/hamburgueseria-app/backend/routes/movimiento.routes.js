// routes/movimiento.routes.js
const express = require('express');
const router = express.Router();
const movimientoController = require('../controllers/movimiento.controller');
const authMiddleware = require('../middleware/auth.middleware');

// Aplicar middleware de autenticación a todas las rutas
router.use(authMiddleware.verificarToken);

// Ruta para agregar movimiento
router.post('/', movimientoController.agregarMovimiento);

// Ruta para obtener movimientos del ciclo activo
router.get('/', movimientoController.obtenerMovimientos);

// Ruta para obtener movimientos de un ciclo específico
router.get('/:ciclo_id', movimientoController.obtenerMovimientos);

module.exports = router;