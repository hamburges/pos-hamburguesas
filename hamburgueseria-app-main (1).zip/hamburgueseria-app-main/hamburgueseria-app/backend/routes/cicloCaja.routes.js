// routes/cicloCaja.routes.js
const express = require('express');
const router = express.Router();
const cicloCajaController = require('../controllers/cicloCaja.controller');
const authMiddleware = require('../middleware/auth.middleware');

// Aplicar middleware de autenticación a todas las rutas
router.use(authMiddleware.verificarToken);

// IMPORTANTE: Colocar las rutas específicas ANTES de las rutas con parámetros

// Ruta para verificar caja actual (NO DEBE usar :id)
router.get('/actual', cicloCajaController.verificarCajaActual);

// Ruta para abrir caja
router.post('/abrir', cicloCajaController.abrirCaja);

// Rutas con parámetro id
router.get('/:id', cicloCajaController.obtenerDetalleCiclo);
router.post('/:id/cerrar', cicloCajaController.cerrarCaja);

// Ruta para historial
router.get('/', cicloCajaController.obtenerHistorial);

module.exports = router;