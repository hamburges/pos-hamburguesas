const express = require('express');
const router = express.Router();
const opcionProductoController = require('../controllers/opcion-producto.controller');
const { verificarToken, verificarRol } = require('../middleware/auth.middleware');

// Obtener todas las opciones de un producto
router.get('/productos/:productoId/opciones', [
  verificarToken
], opcionProductoController.obtenerOpcionesPorProducto);

// Crear una nueva opción para un producto
router.post('/productos/:productoId/opciones', [
  verificarToken,
  verificarRol(['administrador'])
], opcionProductoController.crearOpcion);

// Actualizar una opción específica
router.put('/productos/:productoId/opciones/:opcionId', [
  verificarToken,
  verificarRol(['administrador'])
], opcionProductoController.actualizarOpcion);

// Eliminar una opción
router.delete('/productos/:productoId/opciones/:opcionId', [
  verificarToken,
  verificarRol(['administrador'])
], opcionProductoController.eliminarOpcion);

// Actualizar todas las opciones de un producto
router.put('/productos/:productoId/opciones', [
  verificarToken,
  verificarRol(['administrador'])
], opcionProductoController.actualizarOpciones);

module.exports = router;