const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const cajaSchema = new Schema({
  sucursal: {
    type: Schema.Types.ObjectId,
    ref: 'Sucursal',
    required: true
  },
  cajero: {
    type: Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true
  },
  fecha_apertura: {
    type: Date,
    required: true,
    default: Date.now
  },
  fecha_cierre: {
    type: Date,
    default: null
  },
  monto_apertura: {
    type: Number,
    required: true,
    min: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  monto_cierre_sistema: {
    type: Number,
    default: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  monto_cierre_real: {
    type: Number,
    default: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  diferencia: {
    type: Number,
    default: 0,
    get: v => parseFloat(v.toFixed(2)),
    set: v => parseFloat(parseFloat(v).toFixed(2))
  },
  estado: {
    type: String,
    enum: ['abierta', 'cerrada'],
    default: 'abierta'
  },
  ventas: [{
    type: Schema.Types.ObjectId,
    ref: 'Venta'
  }],
  movimientos: [{
    tipo: {
      type: String,
      enum: ['ingreso', 'egreso'],
      required: true
    },
    concepto: {
      type: String,
      required: true
    },
    monto: {
      type: Number,
      required: true,
      min: 0,
      get: v => parseFloat(v.toFixed(2)),
      set: v => parseFloat(parseFloat(v).toFixed(2))
    },
    autorizado_por: {
      type: Schema.Types.ObjectId,
      ref: 'Usuario'
    },
    fecha: {
      type: Date,
      default: Date.now
    }
  }],
  notas_cierre: {
    type: String,
    trim: true
  },
  autorizado_por: {
    type: Schema.Types.ObjectId,
    ref: 'Usuario'
  }
}, {
  timestamps: {
    createdAt: 'fecha_creacion',
    updatedAt: 'fecha_actualizacion'
  }
});

module.exports = mongoose.model('Caja', cajaSchema);