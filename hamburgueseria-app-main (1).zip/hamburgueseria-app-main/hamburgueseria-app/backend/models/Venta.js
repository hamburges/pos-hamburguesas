const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ventaSchema = new Schema({
  numero_venta: {
    type: String,
    required: true,
    unique: true
  },
  fecha: {
    type: Date,
    default: Date.now
  },
  cajero: {
    type: Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true
  },
  sucursal: {
    type: Schema.Types.ObjectId,
    ref: 'Sucursal',
    required: true
  },
  ciclo_caja: {
    type: Schema.Types.ObjectId,
    ref: 'CicloCaja'
  },
  cliente: {
    nombre: String,
    identificacion: String,
    telefono: String
  },
  productos: [
    {
      producto: {
        type: Schema.Types.ObjectId,
        ref: 'Producto',
        required: true
      },
      cantidad: {
        type: Number,
        required: true,
        min: 1
      },
      precio_unitario: {
        type: Number,
        required: true
      },
      personalizaciones: [
        {
          ingrediente: {
            type: Schema.Types.ObjectId,
            ref: 'Ingrediente'
          },
          accion: {
            type: String,
            enum: ['agregar', 'quitar'],
            required: true
          },
          cantidad: {
            type: Number,
            default: 1
          },
          precio: {
            type: Number,
            default: 0
          }
        }
      ],
      subtotal: {
        type: Number,
        required: true
      }
    }
  ],
  subtotal: {
    type: Number,
    required: true
  },
  impuestos: {
    type: Number,
    default: 0
  },
  descuento: {
    type: Number,
    default: 0
  },
  total: {
    type: Number,
    required: true
  },
  metodo_pago: {
    type: String,
    enum: ['efectivo', 'nequi', 'daviplata', 'transferencia', 'mixto'],
    required: true
  },
  detalles_pago: {
    montos_por_metodo: [
      {
        metodo: {
          type: String,
          enum: ['efectivo', 'nequi', 'daviplata', 'transferencia'],
          required: true
        },
        monto: {
          type: Number,
          required: true,
          min: 0
        },
        referencia: {
          type: String,
          trim: true
        }
      }
    ],
    cambio: {
      type: Number,
      default: 0,
      min: 0
    }
  },
  estado: {
    type: String,
    enum: ['completada', 'anulada'],
    default: 'completada'
  },
  para_llevar: {
    type: Boolean,
    default: false
  },
  notas: {
    type: String
  },
  // Campos nuevos para gestión de anulaciones
  fecha_anulacion: {
    type: Date
  },
  motivo_anulacion: {
    type: String,
    trim: true
  },
  usuario_anulo: {
    type: Schema.Types.ObjectId,
    ref: 'Usuario'
  },
  usuario_autorizo: {
    type: Schema.Types.ObjectId,
    ref: 'Usuario'
  }
}, {
  timestamps: {
    createdAt: 'fecha_creacion',
    updatedAt: 'fecha_actualizacion'
  }
});

// Añadir método pre-save para garantizar que los valores numéricos son correctos
ventaSchema.pre('save', function(next) {
  // Asegurarse de que subtotal, descuento y total son números
  this.subtotal = Number(Number(this.subtotal).toFixed(2));
  this.descuento = Number(Number(this.descuento).toFixed(2));
  this.total = Number(Number(this.total).toFixed(2));
  
  // Verificar los productos
  if (this.productos && this.productos.length > 0) {
    this.productos.forEach(producto => {
      producto.precio_unitario = Number(Number(producto.precio_unitario).toFixed(2));
      producto.subtotal = Number(Number(producto.subtotal).toFixed(2));
      
      // Verificar personalizaciones
      if (producto.personalizaciones && producto.personalizaciones.length > 0) {
        producto.personalizaciones.forEach(p => {
          p.precio = Number(Number(p.precio).toFixed(2));
          p.cantidad = Number(p.cantidad);
        });
      }
    });
  }
  
  // Validación para pagos mixtos
  if (this.detalles_pago && this.detalles_pago.montos_por_metodo) {
    const metodos = this.detalles_pago.montos_por_metodo;
    
    // Si hay más de un método de pago, debe ser marcado como mixto
    if (metodos.length > 1 && this.metodo_pago !== 'mixto') {
      this.metodo_pago = 'mixto';
    }
    
    // Si solo hay un método, asegurar que metodo_pago coincida con ese método
    if (metodos.length === 1 && this.metodo_pago !== metodos[0].metodo) {
      this.metodo_pago = metodos[0].metodo;
    }
    
    // Convertir y redondear montos
    metodos.forEach(item => {
      item.monto = Number(Number(item.monto).toFixed(2));
    });
    
    // Asegurar que el cambio es un número
    if (this.detalles_pago.cambio) {
      this.detalles_pago.cambio = Number(Number(this.detalles_pago.cambio).toFixed(2));
    }
  }
  
  next();
});

// Índices para mejorar consultas
ventaSchema.index({ fecha: -1 });
ventaSchema.index({ cajero: 1 });
ventaSchema.index({ sucursal: 1 });
ventaSchema.index({ estado: 1 });
ventaSchema.index({ ciclo_caja: 1 }); // Añadir índice para ciclo_caja
ventaSchema.index({ 'detalles_pago.montos_por_metodo.metodo': 1 }); // Índice para búsquedas por método de pago
ventaSchema.index({ usuario_autorizo: 1 }); // Índice para búsquedas por autorizador
ventaSchema.index({ usuario_anulo: 1 }); // Índice para búsquedas por usuario que anuló

// Asegúrate de que esta línea está correctamente escrita
const Venta = mongoose.model('Venta', ventaSchema);

module.exports = Venta;