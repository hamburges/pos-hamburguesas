// models/CicloCaja.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Esquema interno para movimientos
const movimientoSchema = new Schema({
  tipo: {
    type: String,
    enum: ['ingreso', 'egreso'],
    required: true
  },
  concepto: {
    type: String,
    required: true,
    trim: true
  },
  monto: {
    type: Number,
    required: true,
    min: 0
  },
  fecha: {
    type: Date,
    default: Date.now
  },
  usuario: {
    type: Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true
  }
});

const cicloCajaSchema = new Schema({
  fecha_apertura: {
    type: Date,
    required: true,
    default: Date.now
  },
  fecha_cierre: {
    type: Date
  },
  usuario_apertura: {
    type: Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true
  },
  usuario_cierre: {
    type: Schema.Types.ObjectId,
    ref: 'Usuario'
  },
  sucursal: {
    type: Schema.Types.ObjectId,
    ref: 'Sucursal',
    required: true
  },
  monto_apertura: {
    type: Number,
    required: true,
    min: 0
  },
  monto_final: {
    type: Number,
    min: 0
  },
  // Campo existente para mantener compatibilidad
  monto_ventas: {
    type: Number,
    default: 0,
    min: 0
  },
  // Nuevo campo para desglose por método de pago
  desglose_ventas: {
    efectivo: {
      type: Number,
      default: 0,
      min: 0
    },
    nequi: {
      type: Number,
      default: 0,
      min: 0
    },
    daviplata: {
      type: Number,
      default: 0,
      min: 0
    },
    transferencia: {
      type: Number,
      default: 0,
      min: 0
    }
  },
  // Cambio en diferencia: solo considera efectivo
  diferencia: {
    type: Number,
    default: 0
  },
  estado: {
    type: String,
    enum: ['activo', 'cerrado'],
    default: 'activo'
  },
  codigo_autorizacion_usado: {
    type: Boolean,
    default: false
  },
  admin_autorizador: {
    type: Schema.Types.ObjectId,
    ref: 'Usuario'
  },
  observaciones: {
    type: String,
    trim: true
  },
  // Nuevo campo para movimientos
  movimientos: [movimientoSchema]
}, {
  timestamps: {
    createdAt: 'fecha_creacion',
    updatedAt: 'fecha_actualizacion'
  }
});

// Helper para calcular la diferencia en efectivo
cicloCajaSchema.methods.calcularDiferencia = function() {
  // Solo considera el efectivo: monto final - (monto apertura + ventas en efectivo)
  const efectivoEsperado = this.monto_apertura + (this.desglose_ventas?.efectivo || 0);
  this.diferencia = (this.monto_final || 0) - efectivoEsperado;
  return this.diferencia;
};

module.exports = mongoose.model('CicloCaja', cicloCajaSchema);