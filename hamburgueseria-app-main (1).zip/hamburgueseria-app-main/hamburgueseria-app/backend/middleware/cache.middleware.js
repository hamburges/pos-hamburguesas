// middleware/cache.middleware.js
const setCacheHeaders = (req, res, next) => {
  // No cachear si es método diferente a GET o si el usuario está autenticado
  if (req.method !== 'GET' || req.headers.authorization) {
    res.set('Cache-Control', 'no-store');
    return next();
  }
  
  // Datos estáticos: productos, categorías, etc.
  if (req.originalUrl.includes('/api/productos') || 
      req.originalUrl.includes('/api/categorias')) {
    // Cachear por 1 hora
    res.set('Cache-Control', 'public, max-age=3600');
  } else if (req.originalUrl.includes('/api/ventas/reporte')) {
    // Reportes: cachear por 5 minutos
    res.set('Cache-Control', 'private, max-age=300');
  } else {
    // Por defecto: validar siempre con el servidor pero permitir cacheo
    res.set('Cache-Control', 'no-cache');
  }
  
  next();
};

module.exports = { setCacheHeaders };
