// diagnostico-inventario.js
// Componentes desacoplados con interfaces estrictas y responsabilidad atómica

const mongoose = require('mongoose');
const dotenv = require('dotenv');

// Carga de módulos con inyección de dependencias
const loadModels = () => {
  return {
    Venta: require('./models/Venta'),
    OpcionProducto: require('./models/OpcionProducto'),
    Ingrediente: require('./models/Ingrediente')
  };
};

// Inicialización y configuración desacoplada
const initialize = async () => {
  // Carga de configuración ambiental
  dotenv.config();
  
  // Validación de prerrequisitos
  if (!process.env.MONGODB_URI) {
    console.error('ERROR: Variable de entorno MONGODB_URI no definida');
    process.exit(1);
  }
  
  // Conexión a base de datos con manejo de errores y feedback
  console.log('Conectando a MongoDB...');
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Conexión exitosa a MongoDB');
    return loadModels();
  } catch (error) {
    console.error('Error fatal conectando a MongoDB:', error);
    process.exit(1);
  }
};

// Extractor de datos con interfaces estrictamente definidas
const TransactionExtractor = {
  async getLatestTransaction(Venta) {
    const ultimaVenta = await Venta.findOne().sort({ fecha_creacion: -1 });
    
    if (!ultimaVenta) {
      console.log('No se encontraron ventas para analizar');
      process.exit(0);
    }
    
    return ultimaVenta;
  },
  
  async getProductOptions(OpcionProducto, productoId) {
    return OpcionProducto.find({ producto: productoId })
      .populate('ingrediente');
  }
};

// Analizador con capacidad de resolución de ambigüedades
const OperationAnalyzer = {
  createIngredientTracker() {
    return new Map();
  },
  
  trackBaseIngredient(tracker, id, nombre, cantidad) {
    if (!tracker.has(id)) {
      tracker.set(id, { 
        nombre, 
        cantidadBase: 0, 
        cantidadAdicion: 0, 
        cantidadQuitar: 0 
      });
    }
    
    tracker.get(id).cantidadBase += cantidad;
  },
  
  trackCustomization(tracker, id, nombre, accion, cantidad) {
    if (!tracker.has(id)) {
      tracker.set(id, { 
        nombre: nombre || 'Desconocido', 
        cantidadBase: 0, 
        cantidadAdicion: 0, 
        cantidadQuitar: 0 
      });
    }
    
    if (accion === 'agregar') {
      tracker.get(id).cantidadAdicion += cantidad;
    } else if (accion === 'quitar') {
      tracker.get(id).cantidadQuitar += cantidad;
    }
  },
  
  calculateNetQuantities(tracker) {
    const results = [];
    
    for (const [id, datos] of tracker) {
      const totalBruto = datos.cantidadBase + datos.cantidadAdicion;
      const totalNeto = totalBruto - datos.cantidadQuitar;
      
      results.push({
        id,
        nombre: datos.nombre,
        cantidadBase: datos.cantidadBase,
        cantidadAdicion: datos.cantidadAdicion,
        cantidadQuitar: datos.cantidadQuitar,
        totalBruto,
        totalNeto
      });
    }
    
    return results;
  }
};

// Visualizador con presentación estructurada
const ResultVisualizer = {
  displayTransactionHeader(venta) {
    console.log('\n==================================================');
    console.log(`ANÁLISIS DE VENTA: ${venta.numero_venta} (ID: ${venta._id})`);
    console.log(`Fecha: ${venta.fecha.toLocaleString()}`);
    console.log(`Productos: ${venta.productos.length}`);
    console.log('==================================================\n');
  },
  
  displayProductHeader(item, index) {
    console.log(`\n--- PRODUCTO ${index + 1}: ${item.producto} ---`);
    console.log(`Cantidad: ${item.cantidad}`);
  },
  
  displayBaseIngredient(opcion, cantidad) {
    console.log(`  • Base: ${opcion.ingrediente.nombre} (${opcion.ingrediente._id}) x ${cantidad}`);
  },
  
  displayCustomization(p, cantidad) {
    const accion = p.accion === 'agregar' ? 'Agregar' : 'Quitar';
    console.log(`  • ${accion}: ID ${p.ingrediente} x ${cantidad}`);
  },
  
  displayResults(results) {
    console.log('\n====== RESUMEN DE CONSUMO DE INGREDIENTES ======');
    console.log('ID | Nombre | Base | Adición | Quitar | TOTAL NETO');
    console.log('--------------------------------------------------');
    
    results.forEach(r => {
      console.log(`${r.id.substring(0,8)}... | ${r.nombre.padEnd(15)} | ${r.cantidadBase} | ${r.cantidadAdicion} | ${r.cantidadQuitar} | ${r.totalNeto}`);
    });
    
    console.log('\nProblema potencial: Si Total Neto ≠ lo que se descuenta del inventario');
  }
};

// Orquestador principal con dependencias explícitas inyectadas
const main = async () => {
  try {
    // Inicialización con inyección de dependencias
    const { Venta, OpcionProducto } = await initialize();
    
    // Extracción de datos transaccionales
    const venta = await TransactionExtractor.getLatestTransaction(Venta);
    
    // Visualización de cabecera
    ResultVisualizer.displayTransactionHeader(venta);
    
    // Estructura para análisis acumulativo
    const ingredientTracker = OperationAnalyzer.createIngredientTracker();
    
    // Análisis estructural por producto
    for (let i = 0; i < venta.productos.length; i++) {
      const item = venta.productos[i];
      ResultVisualizer.displayProductHeader(item, i);
      
      // Extracción de opciones predeterminadas
      const opcionesProducto = await TransactionExtractor.getProductOptions(OpcionProducto, item.producto);
      
      // Análisis de ingredientes base
      for (const opcion of opcionesProducto) {
        const cantidad = opcion.cantidad_predeterminada * item.cantidad;
        ResultVisualizer.displayBaseIngredient(opcion, cantidad);
        
        OperationAnalyzer.trackBaseIngredient(
          ingredientTracker, 
          opcion.ingrediente._id.toString(),
          opcion.ingrediente.nombre,
          cantidad
        );
      }
      
      // Análisis de personalizaciones
      if (item.personalizaciones && item.personalizaciones.length > 0) {
        for (const p of item.personalizaciones) {
          const cantidad = p.cantidad * item.cantidad;
          ResultVisualizer.displayCustomization(p, cantidad);
          
          OperationAnalyzer.trackCustomization(
            ingredientTracker,
            p.ingrediente.toString(),
            null, // Nombre desconocido sin población
            p.accion,
            cantidad
          );
        }
      }
    }
    
    // Cálculo de resultados netos
    const results = OperationAnalyzer.calculateNetQuantities(ingredientTracker);
    
    // Visualización de resultados finales
    ResultVisualizer.displayResults(results);
    
  } catch (error) {
    console.error('Error en diagnóstico:', error);
  } finally {
    await mongoose.disconnect();
    console.log('\nConexión a MongoDB cerrada');
  }
};

// Ejecución con manejo de errores a nivel global
main().catch(error => {
  console.error('Error fatal en ejecución:', error);
  process.exit(1);
});