const OpcionProducto = require('../models/OpcionProducto');
const Producto = require('../models/Producto');
const Ingrediente = require('../models/Ingrediente');
const mongoose = require('mongoose');
const logger = require('../utils/logger');

// Obtener todas las opciones de un producto
const obtenerOpcionesPorProducto = async (req, res) => {
  try {
    const { productoId } = req.params;
    
    // Verificar si el producto existe
    const productoExiste = await Producto.findById(productoId);
    if (!productoExiste) {
      return res.status(404).json({
        success: false,
        message: 'Producto no encontrado'
      });
    }
    
    // Buscar opciones del producto y poblar la información del ingrediente
    const opciones = await OpcionProducto.find({ producto: productoId })
      .populate('ingrediente', 'nombre precio_adicional disponible')
      .lean();
      
    return res.status(200).json({
      success: true,
      data: opciones
    });
  } catch (error) {
    logger.error('Error al obtener opciones:', error);
    return res.status(500).json({
      success: false,
      message: 'Error al obtener las opciones del producto',
      error: error.message
    });
  }
};

// Crear una nueva opción para un producto
const crearOpcion = async (req, res) => {
  try {
    const { productoId } = req.params;
    const { ingrediente, es_predeterminado, es_removible, cantidad_predeterminada } = req.body;
    
    // Verificar si el producto existe
    const productoExiste = await Producto.findById(productoId);
    if (!productoExiste) {
      return res.status(404).json({
        success: false,
        message: 'Producto no encontrado'
      });
    }
    
    // Verificar si el ingrediente existe
    const ingredienteExiste = await Ingrediente.findById(ingrediente);
    if (!ingredienteExiste) {
      return res.status(404).json({
        success: false,
        message: 'Ingrediente no encontrado'
      });
    }
    
    // Verificar si ya existe una opción con este producto e ingrediente
    const opcionExistente = await OpcionProducto.findOne({
      producto: productoId,
      ingrediente
    });
    
    if (opcionExistente) {
      return res.status(400).json({
        success: false,
        message: 'Ya existe una opción con este ingrediente para este producto'
      });
    }
    
    // Crear la nueva opción
    const nuevaOpcion = new OpcionProducto({
      producto: productoId,
      ingrediente,
      es_predeterminado: es_predeterminado !== undefined ? es_predeterminado : true,
      es_removible: es_removible !== undefined ? es_removible : true,
      cantidad_predeterminada: cantidad_predeterminada || 1
    });
    
    await nuevaOpcion.save();
    
    // Devolver la opción creada con información del ingrediente
    const opcionCreada = await OpcionProducto.findById(nuevaOpcion._id)
      .populate('ingrediente', 'nombre precio_adicional disponible')
      .lean();
      
    return res.status(201).json({
      success: true,
      message: 'Opción creada exitosamente',
      data: opcionCreada
    });
  } catch (error) {
    logger.error('Error al crear opción:', error);
    return res.status(500).json({
      success: false,
      message: 'Error al crear la opción',
      error: error.message
    });
  }
};

// Actualizar una opción
const actualizarOpcion = async (req, res) => {
  try {
    const { productoId, opcionId } = req.params;
    const { es_predeterminado, es_removible, cantidad_predeterminada } = req.body;
    
    // Verificar si la opción existe
    const opcion = await OpcionProducto.findOne({
      _id: opcionId,
      producto: productoId
    });
    
    if (!opcion) {
      return res.status(404).json({
        success: false,
        message: 'Opción no encontrada'
      });
    }
    
    // Actualizar los campos
    if (es_predeterminado !== undefined) {
      opcion.es_predeterminado = es_predeterminado;
    }
    
    if (es_removible !== undefined) {
      opcion.es_removible = es_removible;
    }
    
    if (cantidad_predeterminada !== undefined) {
      opcion.cantidad_predeterminada = cantidad_predeterminada;
    }
    
    await opcion.save();
    
    // Devolver la opción actualizada
    const opcionActualizada = await OpcionProducto.findById(opcion._id)
      .populate('ingrediente', 'nombre precio_adicional disponible')
      .lean();
      
    return res.status(200).json({
      success: true,
      message: 'Opción actualizada exitosamente',
      data: opcionActualizada
    });
  } catch (error) {
    logger.error('Error al actualizar opción:', error);
    return res.status(500).json({
      success: false,
      message: 'Error al actualizar la opción',
      error: error.message
    });
  }
};

// Eliminar una opción
const eliminarOpcion = async (req, res) => {
  try {
    const { productoId, opcionId } = req.params;
    
    // Verificar si la opción existe
    const opcion = await OpcionProducto.findOne({
      _id: opcionId,
      producto: productoId
    });
    
    if (!opcion) {
      return res.status(404).json({
        success: false,
        message: 'Opción no encontrada'
      });
    }
    
    // Eliminar la opción usando deleteOne en lugar de remove()
    await OpcionProducto.deleteOne({ _id: opcionId });
    
    return res.status(200).json({
      success: true,
      message: 'Opción eliminada exitosamente'
    });
  } catch (error) {
    logger.error('Error al eliminar opción:', error);
    return res.status(500).json({
      success: false,
      message: 'Error al eliminar la opción',
      error: error.message
    });
  }
};

// Actualizar todas las opciones de un producto
const actualizarOpciones = async (req, res) => {
  try {
    const { productoId } = req.params;
    const { opciones } = req.body;
    
    // Verificar si el producto existe
    const productoExiste = await Producto.findById(productoId);
    if (!productoExiste) {
      return res.status(404).json({
        success: false,
        message: 'Producto no encontrado'
      });
    }
    
    // Obtener las opciones actuales
    const opcionesActuales = await OpcionProducto.find({ producto: productoId }).lean();
    
    // Crear un mapa de las opciones actuales
    const opcionesMap = new Map();
    opcionesActuales.forEach(opcion => {
      opcionesMap.set(opcion.ingrediente.toString(), opcion);
    });
    
    // Actualizar o crear las opciones nuevas
    const nuevasOpciones = [];
    for (const opcion of opciones) {
      const opcionActual = opcionesMap.get(opcion.ingrediente);
      
      if (opcionActual) {
        // Actualizar solo si hay cambios
        if (
          opcionActual.es_predeterminado !== opcion.es_predeterminado ||
          opcionActual.es_removible !== opcion.es_removible ||
          opcionActual.cantidad_predeterminada !== opcion.cantidad_predeterminada
        ) {
          await OpcionProducto.updateOne(
            { _id: opcionActual._id },
            {
              es_predeterminado: opcion.es_predeterminado,
              es_removible: opcion.es_removible,
              cantidad_predeterminada: opcion.cantidad_predeterminada
            }
          );
        }
      } else {
        // Crear nueva opción
        const nuevaOpcion = new OpcionProducto({
          producto: productoId,
          ingrediente: opcion.ingrediente,
          es_predeterminado: opcion.es_predeterminado !== undefined ? opcion.es_predeterminado : true,
          es_removible: opcion.es_removible !== undefined ? opcion.es_removible : true,
          cantidad_predeterminada: opcion.cantidad_predeterminada || 1
        });
        
        await nuevaOpcion.save();
        nuevasOpciones.push(nuevaOpcion);
      }
    }
    
    // Devolver las opciones actualizadas con información del ingrediente
    const opcionesActualizadas = await OpcionProducto.find({ producto: productoId })
      .populate('ingrediente', 'nombre precio_adicional disponible')
      .lean();
      
    return res.status(200).json({
      success: true,
      message: 'Opciones actualizadas exitosamente',
      data: opcionesActualizadas
    });
  } catch (error) {
    logger.error('Error al actualizar opciones:', error);
    return res.status(500).json({
      success: false,
      message: 'Error al actualizar las opciones',
      error: error.message
    });
  }
};

module.exports = {
  obtenerOpcionesPorProducto,
  crearOpcion,
  actualizarOpcion,
  eliminarOpcion,
  actualizarOpciones
};