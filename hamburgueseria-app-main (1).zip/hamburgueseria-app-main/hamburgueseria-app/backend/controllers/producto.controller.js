const Producto = require('../models/Producto');
const mongoose = require('mongoose');
const logger = require('../utils/logger'); // Asumiendo que implementarás esto después

// Método principal para obtener productos con filtros
exports.obtenerTodos = async (req, res) => {
  try {
    const startTime = Date.now(); // Para medir rendimiento
    const { 
      pagina = 1, 
      limite = 20, 
      categoria, 
      disponible, 
      buscar,
      ordenar = 'nombre' // Default
    } = req.query;
    
    // Construir filtro con soporte para índices
    const filtro = {};
    
    // Usar los índices compuestos creados
    if (categoria) {
      filtro.categoria = new mongoose.Types.ObjectId(categoria);
    }
    
    if (disponible !== undefined) {
      filtro.disponible = disponible === 'true';
    }
    
    // Búsqueda por texto (usando el índice de texto si existe)
    if (buscar && buscar.trim()) {
      // Determinar si es búsqueda simple o avanzada
      if (buscar.length > 3) {
        filtro.$or = [
          { nombre: { $regex: buscar, $options: 'i' } },
          { descripcion: { $regex: buscar, $options: 'i' } }
        ];
      } else {
        // Para búsquedas cortas, usar solo nombre para rendimiento
        filtro.nombre = { $regex: `^${buscar}`, $options: 'i' };
      }
    }
    
    // Configurar paginación
    const skip = (parseInt(pagina) - 1) * parseInt(limite);
    
    // Configurar ordenamiento
    const sort = {};
    if (ordenar.startsWith('-')) {
      sort[ordenar.substring(1)] = -1;
    } else {
      sort[ordenar] = 1;
    }
    
    // Proyección optimizada - solo campos necesarios
    const productos = await Producto.find(filtro)
      .select('nombre precio_base disponible imagen categoria para_llevar') // Solo campos esenciales
      .populate('categoria', 'nombre') // Limitar campos populados
      .sort(sort)
      .skip(skip)
      .limit(parseInt(limite))
      .lean(); // Mejora rendimiento significativamente
    
    // Contar total en paralelo para mejor rendimiento
    const totalPromise = Producto.countDocuments(filtro);
    
    // Esperar resultado de contador
    const total = await totalPromise;
    
    // Medir tiempo de ejecución para monitoreo
    const executionTime = Date.now() - startTime;
    if (executionTime > 500) { // Alerta si toma más de 500ms
      logger.warn(`Consulta lenta en productos: ${executionTime}ms - Filtros:`, filtro);
    }
    
    logger.performance('producto.obtenerTodos', executionTime, { filtro });
    
    // Respuesta con metadata para paginación
    return res.status(200).json({
      success: true,
      data: productos,
      meta: {
        total,
        pagina: parseInt(pagina),
        limite: parseInt(limite),
        paginas: Math.ceil(total / parseInt(limite))
      }
    });
  } catch (error) {
    logger.error('Error en obtenerTodos', error);
    return res.status(500).json({
      success: false,
      message: 'Error al obtener productos',
      error: error.message
    });
  }
};

// Método optimizado para obtener un producto específico
exports.obtenerPorId = async (req, res) => {
  try {
    const producto = await Producto.findById(req.params.id)
      .select('-__v') // Excluir campo de versión
      .populate('categoria', 'nombre')
      .lean();
    
    if (!producto) {
      return res.status(404).json({
        success: false,
        message: 'Producto no encontrado'
      });
    }
    
    // Cargar opciones en una consulta separada (más eficiente que populate)
    const opciones = await mongoose.model('OpcionProducto').find({
      producto: req.params.id
    })
    .populate('ingrediente', 'nombre precio_adicional disponible')
    .lean();
    
    return res.status(200).json({
      success: true,
      data: {
        ...producto,
        opciones
      }
    });
  } catch (error) {
    logger.error('Error en obtenerPorId', error);
    return res.status(500).json({
      success: false,
      message: 'Error al obtener producto',
      error: error.message
    });
  }
};