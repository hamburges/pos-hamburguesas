// backend/controllers/cicloCaja.controller.js
const CicloCaja = require('../models/CicloCaja');
const Venta = require('../models/Venta');
const { verificarAutorizacion } = require('../utils/autorizacion.utils');
const logger = require('../utils/logger');

/**
 * Controlador de ciclos de caja con verificación de administrador
 */
const cicloCajaController = {
  /**
   * Verifica si hay un ciclo activo en la sucursal del usuario
   */
  verificarCajaActual: async (req, res) => {
    try {
      const sucursalId = req.usuario.sucursal;
      
      const cajaActiva = await CicloCaja.findOne({
        sucursal: sucursalId,
        estado: 'activo'
      })
      .select('fecha_apertura monto_apertura monto_ventas usuario_apertura')
      .populate('usuario_apertura', 'nombre usuario')
      .lean();
      
      if (!cajaActiva) {
        return res.status(404).json({
          success: false,
          message: 'No hay caja abierta actualmente'
        });
      }
      
      return res.status(200).json({
        success: true,
        data: cajaActiva
      });
    } catch (error) {
      logger.error('[CicloCajaController] Error al verificar caja:', error);
      return res.status(500).json({
        success: false,
        message: 'Error al verificar estado de caja'
      });
    }
  },
  
  /**
   * Abre un nuevo ciclo de caja con valores iniciales en cero
   */
  abrirCaja: async (req, res) => {
    try {
      const { monto_apertura } = req.body;
      const usuarioId = req.usuario._id;
      const sucursalId = req.usuario.sucursal;
      
      // Verificar si ya existe caja abierta - usamos lean() para mejor rendimiento
      const cajaExistente = await CicloCaja.findOne({
        sucursal: sucursalId,
        estado: 'activo'
      }).lean();
      
      if (cajaExistente) {
        return res.status(400).json({
          success: false,
          message: 'Ya existe una caja abierta en esta sucursal'
        });
      }
      
      // Crear nuevo ciclo con reinicio de valores
      const nuevoCiclo = new CicloCaja({
        usuario_apertura: usuarioId,
        sucursal: sucursalId,
        monto_apertura: parseFloat(monto_apertura) || 0,
        monto_final: 0,
        monto_ventas: 0,
        diferencia: 0,
        estado: 'activo'
      });
      
      await nuevoCiclo.save();
      logger.info('[CicloCajaController] Ciclo de caja abierto', { cicloId: nuevoCiclo._id, sucursal: sucursalId });
      
      return res.status(201).json({
        success: true,
        message: 'Caja abierta correctamente',
        data: nuevoCiclo
      });
    } catch (error) {
      logger.error('[CicloCajaController] Error al abrir caja:', error);
      return res.status(500).json({
        success: false,
        message: 'Error al abrir caja',
        error: error.message
      });
    }
  },
  
  /**
   * Cierra un ciclo de caja con verificación de código de administrador
   */
  cerrarCaja: async (req, res) => {
    try {
      const { id } = req.params;
      const { monto_final, observaciones, codigo_autorizacion } = req.body;
      const usuarioId = req.usuario._id;
      
      // Validación de datos requeridos
      if (!codigo_autorizacion) {
        return res.status(400).json({
          success: false,
          message: 'El código de autorización de administrador es obligatorio para cerrar la caja'
        });
      }
      
      if (monto_final === undefined) {
        return res.status(400).json({
          success: false,
          message: 'El monto final es obligatorio'
        });
      }
      
      // Buscar ciclo activo
      const ciclo = await CicloCaja.findOne({
        _id: id,
        estado: 'activo'
      }).lean();
      
      if (!ciclo) {
        return res.status(404).json({
          success: false,
          message: 'Ciclo de caja no encontrado o ya cerrado'
        });
      }
      
      // Verificar autorización administrativa
      const autorizado = await verificarAutorizacion(codigo_autorizacion, 'administrador');
      
      if (!autorizado.success) {
        return res.status(401).json({
          success: false,
          message: 'Código de autorización inválido. Se requiere autorización de un administrador.'
        });
      }
      
      // Calcular ventas en este ciclo usando agregación para mejor rendimiento
      const resultadoVentas = await Venta.aggregate([
        {
          $match: {
            fecha: { $gte: ciclo.fecha_apertura, $lte: new Date() },
            sucursal: ciclo.sucursal,
            estado: 'completada'
          }
        },
        {
          $group: {
            _id: null,
            totalVentas: { $sum: "$total" }
          }
        }
      ]);
      
      const montoVentas = resultadoVentas.length > 0 ? resultadoVentas[0].totalVentas : 0;
      
      // Calcular diferencia con precisión monetaria
      const montoEsperado = parseFloat((ciclo.monto_apertura + montoVentas).toFixed(2));
      const montoFinal = parseFloat(parseFloat(monto_final).toFixed(2));
      const diferencia = parseFloat((montoFinal - montoEsperado).toFixed(2));
      
      // Actualizar ciclo - usar updateOne para operación atómica
      await CicloCaja.updateOne(
        { _id: id },
        {
          $set: {
            fecha_cierre: new Date(),
            usuario_cierre: usuarioId,
            monto_final: montoFinal,
            monto_ventas: montoVentas,
            diferencia: diferencia,
            estado: 'cerrado',
            observaciones: observaciones || '',
            codigo_autorizacion_usado: true,
            admin_autorizador: autorizado.usuario._id
          }
        }
      );
      
      logger.info('[CicloCajaController] Ciclo de caja cerrado', { 
        cicloId: id, 
        montoFinal, 
        diferencia, 
        autorizador: autorizado.usuario._id 
      });
      
      return res.status(200).json({
        success: true,
        message: 'Caja cerrada correctamente con autorización administrativa',
        data: {
          ciclo: {
            _id: id,
            fecha_apertura: ciclo.fecha_apertura,
            fecha_cierre: new Date(),
            monto_apertura: ciclo.monto_apertura,
            monto_final: montoFinal,
            monto_ventas: montoVentas,
            diferencia: diferencia
          }
        }
      });
    } catch (error) {
      logger.error('[CicloCajaController] Error al cerrar caja:', error);
      return res.status(500).json({
        success: false,
        message: 'Error al cerrar caja',
        error: error.message
      });
    }
  },
  
  /**
   * Obtiene historial de ciclos con filtrado
   */
  obtenerHistorial: async (req, res) => {
    try {
      const rol = req.usuario.rol;
      const sucursalId = req.usuario.sucursal;
      
      // Parámetros de consulta
      const { fechaInicio, fechaFin, estado, pagina = 1, limite = 10 } = req.query;
      
      // Construir filtro basado en rol
      let filtro = {};
      
      if (rol === 'administrador') {
        if (req.query.sucursal) {
          filtro.sucursal = req.query.sucursal;
        }
      } else {
        filtro.sucursal = sucursalId;
      }
      
      // Aplicar filtros adicionales
      if (fechaInicio) {
        filtro.fecha_apertura = { ...filtro.fecha_apertura || {}, $gte: new Date(fechaInicio) };
      }
      
      if (fechaFin) {
        const fechaFinAjustada = new Date(fechaFin);
        fechaFinAjustada.setHours(23, 59, 59, 999);
        filtro.fecha_apertura = { ...filtro.fecha_apertura || {}, $lte: fechaFinAjustada };
      }
      
      if (estado) {
        filtro.estado = estado;
      }
      
      // Configurar paginación
      const skip = (parseInt(pagina) - 1) * parseInt(limite);
      const limit = parseInt(limite);
      
      // Optimización: proyección específica y lean()
      const ciclos = await CicloCaja.find(filtro)
        .select('fecha_apertura fecha_cierre usuario_apertura usuario_cierre sucursal estado monto_apertura monto_ventas')
        .populate('usuario_apertura', 'nombre usuario')
        .populate('usuario_cierre', 'nombre usuario')
        .populate('sucursal', 'nombre')
        .sort({ fecha_apertura: -1 })
        .skip(skip)
        .limit(limit)
        .lean();
      
      // Obtener total para metadatos
      const total = await CicloCaja.countDocuments(filtro);
      
      // Medición de rendimiento
      logger.performance('cicloCaja.obtenerHistorial', ciclos.length, { filtro });
      
      return res.status(200).json({
        success: true,
        data: ciclos,
        meta: {
          total,
          pagina: parseInt(pagina),
          limite: limit,
          paginas: Math.ceil(total / limit)
        }
      });
    } catch (error) {
      logger.error('[CicloCajaController] Error al obtener historial:', error);
      return res.status(500).json({
        success: false,
        message: 'Error al obtener historial',
        error: error.message
      });
    }
  },
  
  /**
   * Obtiene detalles de un ciclo con visualización condicional basada en autorización
   */
  obtenerDetalleCiclo: async (req, res) => {
    try {
      const { id } = req.params;
      const { codigo_autorizacion } = req.query;
      const rol = req.usuario.rol;
      const sucursalId = req.usuario.sucursal;
      
      // Proyección específica para mejor rendimiento
      const ciclo = await CicloCaja.findById(id)
        .select('fecha_apertura fecha_cierre usuario_apertura usuario_cierre sucursal estado monto_apertura monto_final monto_ventas diferencia observaciones admin_autorizador')
        .populate('usuario_apertura', 'nombre usuario')
        .populate('usuario_cierre', 'nombre usuario')
        .populate('sucursal', 'nombre')
        .populate('admin_autorizador', 'nombre usuario')
        .lean();
      
      if (!ciclo) {
        return res.status(404).json({
          success: false,
          message: 'Ciclo no encontrado'
        });
      }
      
      // Verificar acceso por sucursal
      if (rol !== 'administrador' && ciclo.sucursal._id.toString() !== sucursalId.toString()) {
        return res.status(403).json({
          success: false,
          message: 'No tiene permiso para ver ciclos de otras sucursales'
        });
      }
      
      // Determinar nivel de acceso a datos
      let datosCompletos = rol === 'administrador';
      
      // Verificar autorización con código para no-administradores
      if (!datosCompletos && ciclo.estado === 'cerrado' && codigo_autorizacion) {
        const autorizado = await verificarAutorizacion(codigo_autorizacion, 'administrador');
        datosCompletos = autorizado.success;
        logger.info('[CicloCajaController] Autorización para visualizar ciclo', { 
          cicloId: id, 
          autorizado: autorizado.success 
        });
      }
      
      // Preparar respuesta según nivel de autorización
      let respuesta = {
        _id: ciclo._id,
        fecha_apertura: ciclo.fecha_apertura,
        usuario_apertura: ciclo.usuario_apertura,
        sucursal: ciclo.sucursal,
        estado: ciclo.estado
      };
      
      // Si está activo, solo mostrar información básica
      if (ciclo.estado === 'activo') {
        respuesta.monto_apertura = ciclo.monto_apertura;
      } 
      // Si está cerrado y tiene autorización, mostrar detalles completos
      else if (ciclo.estado === 'cerrado' && datosCompletos) {
        respuesta = {
          ...respuesta,
          fecha_cierre: ciclo.fecha_cierre,
          usuario_cierre: ciclo.usuario_cierre,
          monto_apertura: ciclo.monto_apertura,
          monto_final: ciclo.monto_final,
          monto_ventas: ciclo.monto_ventas,
          diferencia: ciclo.diferencia,
          observaciones: ciclo.observaciones,
          admin_autorizador: ciclo.admin_autorizador
        };
      } 
      // Si está cerrado pero sin autorización, mostrar datos limitados
      else if (ciclo.estado === 'cerrado') {
        respuesta = {
          ...respuesta,
          fecha_cierre: ciclo.fecha_cierre,
          requiere_autorizacion: true,
          mensaje: "Se requiere código de administrador para ver detalles completos"
        };
      }
      
      return res.status(200).json({
        success: true,
        data: respuesta
      });
    } catch (error) {
      logger.error('[CicloCajaController] Error al obtener detalle:', error);
      return res.status(500).json({
        success: false,
        message: 'Error al obtener detalle del ciclo',
        error: error.message
      });
    }
  }
};

module.exports = cicloCajaController;