// controllers/movimiento.controller.js
const CicloCaja = require('../models/CicloCaja');
const { verificarAutorizacion } = require('../utils/autorizacion.utils');
const logger = require('../utils/logger');

/**
 * Controlador para gestionar movimientos de caja (ingresos y egresos)
 */
const movimientoController = {
  /**
   * Registra un nuevo movimiento en el ciclo de caja activo
   */
  agregarMovimiento: async (req, res) => {
    try {
      const { tipo, concepto, monto, codigo_autorizacion } = req.body;
      const usuarioId = req.usuario._id;
      const sucursalId = req.usuario.sucursal;
      
      // Validaciones básicas
      if (!tipo || !concepto || monto === undefined) {
        return res.status(400).json({
          success: false,
          message: 'Todos los campos son obligatorios: tipo, concepto, monto'
        });
      }
      
      if (tipo !== 'ingreso' && tipo !== 'egreso') {
        return res.status(400).json({
          success: false,
          message: 'El tipo debe ser "ingreso" o "egreso"'
        });
      }
      
      const montoNumerico = parseFloat(monto);
      if (isNaN(montoNumerico) || montoNumerico <= 0) {
        return res.status(400).json({
          success: false,
          message: 'El monto debe ser un número positivo'
        });
      }
      
      // Verificar si hay un ciclo activo
      const cicloActivo = await CicloCaja.findOne({
        sucursal: sucursalId,
        estado: 'activo'
      }).select('_id sucursal').lean();
      
      if (!cicloActivo) {
        return res.status(400).json({
          success: false,
          message: 'No hay un ciclo de caja abierto actualmente',
          codigo_error: 'NO_ACTIVE_CYCLE'
        });
      }
      
      // Para egresos, verificar autorización si el usuario no es administrador
      let adminAutorizadorId = null;
      if (tipo === 'egreso' && req.usuario.rol !== 'administrador') {
        if (!codigo_autorizacion) {
          return res.status(400).json({
            success: false,
            message: 'Se requiere código de autorización para registrar egresos'
          });
        }
        
        const autorizado = await verificarAutorizacion(codigo_autorizacion, 'administrador');
        if (!autorizado.success) {
          return res.status(401).json({
            success: false,
            message: 'Código de autorización inválido'
          });
        }
        
        adminAutorizadorId = autorizado.usuario._id;
      }
      
      // Crear el movimiento
      const nuevoMovimiento = {
        tipo,
        concepto,
        monto: montoNumerico,
        fecha: new Date(),
        usuario: usuarioId,
        autorizado_por: adminAutorizadorId
      };
      
      // OPTIMIZACIÓN: Operación atómica para añadir movimiento
      await CicloCaja.updateOne(
        { _id: cicloActivo._id },
        { $push: { movimientos: nuevoMovimiento } }
      );
      
      logger.info('[MovimientoController] Movimiento registrado', {
        tipo, 
        monto: montoNumerico, 
        cicloId: cicloActivo._id,
        autorizado: !!adminAutorizadorId
      });
      
      return res.status(201).json({
        success: true,
        message: 'Movimiento registrado correctamente',
        data: {
          cicloId: cicloActivo._id,
          movimiento: {
            tipo,
            concepto,
            monto: montoNumerico,
            fecha: new Date(),
            autorizado: !!adminAutorizadorId
          }
        }
      });
    } catch (error) {
      logger.error('[MovimientoController] Error al registrar movimiento:', error);
      return res.status(500).json({
        success: false,
        message: 'Error al registrar movimiento',
        error: error.message
      });
    }
  },
  
  /**
   * Obtiene los movimientos de un ciclo específico o del ciclo activo
   */
  obtenerMovimientos: async (req, res) => {
    try {
      const { ciclo_id } = req.params;
      const sucursalId = req.usuario.sucursal;
      
      let ciclo;
      
      // Si se proporciona ID, buscar ese ciclo específico
      if (ciclo_id) {
        // Proyección específica para mejor rendimiento
        ciclo = await CicloCaja.findById(ciclo_id)
          .select('movimientos sucursal')
          .lean();
        
        // Verificar permisos para ver el ciclo
        if (req.usuario.rol !== 'administrador' && ciclo.sucursal.toString() !== sucursalId.toString()) {
          return res.status(403).json({
            success: false,
            message: 'No tiene permiso para ver este ciclo'
          });
        }
      } else {
        // Buscar el ciclo activo con proyección optimizada
        ciclo = await CicloCaja.findOne({
          sucursal: sucursalId,
          estado: 'activo'
        })
        .select('movimientos')
        .lean();
        
        if (!ciclo) {
          return res.status(404).json({
            success: false,
            message: 'No hay un ciclo activo actualmente'
          });
        }
      }
      
      // Verificar si el ciclo tiene la propiedad movimientos
      const movimientos = ciclo.movimientos || [];
      
      // OPTIMIZACIÓN: Cálculos más eficientes
      // Agrupar y calcular totales en una sola pasada
      let totalIngresos = 0;
      let totalEgresos = 0;
      
      movimientos.forEach(m => {
        if (m.tipo === 'ingreso') {
          totalIngresos += m.monto;
        } else {
          totalEgresos += m.monto;
        }
      });
      
      // Medición de rendimiento
      logger.performance('movimiento.obtenerMovimientos', movimientos.length, { 
        cicloId: ciclo_id || 'activo' 
      });
      
      return res.status(200).json({
        success: true,
        data: {
          movimientos,
          resumen: {
            totalIngresos,
            totalEgresos,
            balance: totalIngresos - totalEgresos
          }
        }
      });
    } catch (error) {
      logger.error('[MovimientoController] Error al obtener movimientos:', error);
      return res.status(500).json({
        success: false,
        message: 'Error al obtener movimientos',
        error: error.message
      });
    }
  }
};

module.exports = movimientoController;