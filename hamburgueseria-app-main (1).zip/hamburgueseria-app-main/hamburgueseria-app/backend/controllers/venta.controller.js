/**
 * Controlador de Ventas con responsabilidad única de orquestación transaccional
 * Implementa patrón Repository para modelos y patrón Strategy para validación de inventario
 */
const Venta = require('../models/Venta');
const Producto = require('../models/Producto');
const Ingrediente = require('../models/Ingrediente');
const CicloCaja = require('../models/CicloCaja');
const mongoose = require('mongoose');
const inventarioService = require('../services/inventario.service');
const logger = require('../utils/logger');

/**
 * Crea una venta nueva con validación previa de restricciones de negocio
 * @async
 * @param {Object} req - Solicitud HTTP con datos transaccionales
 * @param {Object} res - Respuesta HTTP para cliente
 * @returns {Promise<Object>} - Respuesta JSON con resultado de la operación
 */
const crearVenta = async (req, res) => {
  try {
    const {
      cajero,
      sucursal,
      productos,
      cliente,
      metodo_pago,
      detalles_pago,
      para_llevar,
      notas,
      descuento = 0
    } = req.body;

    // Verificar si hay un ciclo de caja activo para esta sucursal
    const cicloActivo = await CicloCaja.findOne({
      sucursal: sucursal,
      estado: 'activo'
    });
    
    if (!cicloActivo) {
      return res.status(400).json({
        success: false,
        message: 'No hay un ciclo de caja activo. Debes abrir un ciclo antes de realizar ventas.',
        codigo_error: 'ERR_NO_ACTIVE_CASH_CYCLE'
      });
    }

    // VALIDACIÓN DE INVENTARIO: Verificar disponibilidad de ingredientes con bloqueo en cero
    const validacionInventario = await inventarioService.validarDisponibilidadParaVenta(req.body);
    
    if (!validacionInventario.permitirVenta) {
      // Construir mensaje detallado con información específica por ingrediente
      const ingredientesFaltantes = validacionInventario.ingredientesCriticosInsuficientes
        .map(i => `${i.nombre}: stock actual ${i.stockActual} ${i.unidadMedida || 'unidades'}, requerido ${i.stockRequerido} ${i.unidadMedida || 'unidades'}`)
        .join('; ');
      
      // Extraer productos afectados para recomendaciones accionables
      const productosAfectados = new Set();
      validacionInventario.ingredientesCriticosInsuficientes.forEach(ingrediente => {
        req.body.productos.forEach(producto => {
          const tieneIngrediente = producto.personalizaciones?.some(p => 
            p.ingrediente.toString() === ingrediente.ingredienteId.toString());
          
          if (tieneIngrediente) {
            productosAfectados.add(producto.nombre || 'Producto sin nombre');
          }
        });
      });
      
      return res.status(400).json({
        success: false,
        message: 'No es posible completar la venta por falta de ingredientes críticos',
        detalle: ingredientesFaltantes ? 
          `Ingredientes críticos insuficientes: ${ingredientesFaltantes}` : 
          'No hay suficientes ingredientes críticos disponibles',
        ingredientes_criticos: validacionInventario.ingredientesCriticosInsuficientes,
        codigo_error: 'ERR_INSUFFICIENT_CRITICAL_INGREDIENTS',
        productos_afectados: Array.from(productosAfectados),
        acciones_sugeridas: [
          'Verificar y actualizar el inventario',
          'Ofrecer productos alternativos',
          'Contactar al administrador para resolver el problema de inventario'
        ]
      });
    }

    // Verificar productos y calcular subtotales
    let subtotal = 0;
    
    // Validar que haya productos en la venta
    if (!productos || productos.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'La venta debe contener al menos un producto',
        codigo_error: 'ERR_NO_PRODUCTS'
      });
    }

    // Verificar que detalles_pago tenga la estructura correcta
    if (!detalles_pago || !detalles_pago.montos_por_metodo || !Array.isArray(detalles_pago.montos_por_metodo)) {
      return res.status(400).json({
        success: false,
        message: 'Los detalles de pago no tienen el formato correcto',
        codigo_error: 'ERR_INVALID_PAYMENT_DETAILS'
      });
    }

    // Generar número de venta con garantía de unicidad
    const fechaHoy = new Date();
    const anio = fechaHoy.getFullYear().toString().slice(-2);
    const mes = (fechaHoy.getMonth() + 1).toString().padStart(2, '0');
    const dia = fechaHoy.getDate().toString().padStart(2, '0');
    const prefijo = `V${anio}${mes}${dia}`;
    
    // Consulta para encontrar la última venta manualmente con manejo de errores
    let ultimaVenta;
    try {
      ultimaVenta = await mongoose.model('Venta').findOne({ 
        numero_venta: { $regex: new RegExp(`^${prefijo}`) } 
      }).sort({ numero_venta: -1 });
    } catch (error) {
      logger.error('[VentaController] Error buscando última venta:', error);
      ultimaVenta = null;
    }
    
    let contador = 1;
    if (ultimaVenta && ultimaVenta.numero_venta) {
      try {
        const ultimoContador = parseInt(ultimaVenta.numero_venta.slice(-4));
        if (!isNaN(ultimoContador)) {
          contador = ultimoContador + 1;
        }
      } catch (error) {
        logger.error('[VentaController] Error parseando último contador:', error);
        // Si hay error, dejamos contador = 1
      }
    }
    
    const numero_venta = `${prefijo}-${contador.toString().padStart(4, '0')}`;

    // Procesar productos para garantizar tipos numéricos correctos
    const productosProcessed = [];

    for (const item of productos) {
      // Asegurar valores numéricos correctos con conversión explícita
      const precio_unitario = Number(item.precio_unitario);
      const cantidad = Number(item.cantidad || 1);
      
      // Calcular precio base del producto
      const precioBase = precio_unitario * cantidad;
      
      // Procesar personalizaciones con manejo de nulos
      let personalizacionesTotal = 0;
      const personalizacionesProcessed = [];
      
      if (item.personalizaciones && item.personalizaciones.length > 0) {
        for (const p of item.personalizaciones) {
          // Asegurar valores numéricos con conversiones explícitas
          const personalizacion = {
            ingrediente: p.ingrediente,
            accion: p.accion,
            cantidad: Number(p.cantidad || 1),
            precio: Number(p.precio || 0)
          };
          
          // CORRECCIÓN: Usar el precio ya calculado en el frontend
          if (p.accion === 'agregar') {
            personalizacionesTotal += personalizacion.precio;
          }
          
          personalizacionesProcessed.push(personalizacion);
        }
      }
      
      // Calcular subtotal del producto incluyendo personalizaciones
      const itemSubtotal = precioBase + personalizacionesTotal;
      
      // Añadir al subtotal general acumulativo
      subtotal += itemSubtotal;
      
      // Guardar producto procesado con todos sus metadatos
      productosProcessed.push({
        producto: item.producto,
        cantidad: cantidad,
        precio_unitario: precio_unitario,
        personalizaciones: personalizacionesProcessed,
        subtotal: itemSubtotal
      });
      
      // Log para depuración y trazabilidad
      logger.info(`[VentaController] Producto procesado`, {
        producto: item.producto,
        precio_unitario,
        cantidad,
        precioBase,
        personalizacionesTotal,
        itemSubtotal
      });
    }
    
    // Redondear subtotal con precisión monetaria
    subtotal = Math.round(subtotal * 100) / 100;
    
    // Asegurar descuento como número con normalización
    const descuentoFinal = Math.round(Number(descuento) * 100) / 100;
    
    // Calcular total final con precisión monetaria
    const totalFinal = Math.round((subtotal - descuentoFinal) * 100) / 100;
    
    logger.info(`[VentaController] Totales calculados`, {
      subtotal,
      descuentoFinal,
      totalFinal
    });

    // Validar que la suma de los montos coincida con el total
    const totalPagos = detalles_pago.montos_por_metodo.reduce(
      (sum, item) => sum + Number(item.monto || 0), 0
    );
    
    // Verificar con margen de error para evitar problemas de redondeo
    if (Math.abs(totalPagos - totalFinal) > 0.01) {
      return res.status(400).json({
        success: false,
        message: `La suma de los pagos (${totalPagos}) no coincide con el total de la venta (${totalFinal})`,
        codigo_error: 'ERR_PAYMENT_AMOUNT_MISMATCH'
      });
    }

    // Crear la venta con los datos procesados y normalizados
    const nuevaVenta = new Venta({
      numero_venta,
      cajero,
      sucursal,
      ciclo_caja: cicloActivo._id, // Añadir referencia al ciclo de caja
      productos: productosProcessed,
      subtotal: subtotal,
      impuestos: 0, // Configurable según requerimientos fiscales
      descuento: descuentoFinal,
      total: totalFinal,
      metodo_pago,
      detalles_pago,
      para_llevar,
      cliente,
      notas
    });

    // Guardar la venta en base de datos con integridad transaccional
    await nuevaVenta.save();

    // Actualizar totales del ciclo activo
    const ventaTotal = nuevaVenta.total || 0;
    cicloActivo.monto_ventas = (cicloActivo.monto_ventas || 0) + ventaTotal;
    
    // Actualizar el ciclo activo con el desglose por método de pago
    if (!cicloActivo.desglose_ventas) {
      cicloActivo.desglose_ventas = {
        efectivo: 0,
        nequi: 0,
        daviplata: 0,
        transferencia: 0
      };
    }

    // Actualizar cada método de pago en el desglose
    for (const metodoPago of detalles_pago.montos_por_metodo) {
      const metodo = metodoPago.metodo;
      const monto = Number(metodoPago.monto || 0);
      
      // Verificar que el método existe en el esquema
      if (metodo in cicloActivo.desglose_ventas) {
        cicloActivo.desglose_ventas[metodo] += monto;
      }
    }
    
    await cicloActivo.save();

    // NUEVO: Procesar descuentos de inventario con operación atómica
    const resultadoInventario = await inventarioService.procesarDescuentosPorVenta(nuevaVenta);
    
    if (!resultadoInventario.success) {
      logger.error('[VentaController] Error procesando descuentos de inventario:', resultadoInventario.error);
    }

    // Devolver la venta creada con datos enriquecidos mediante population
    const ventaCreada = await mongoose.model('Venta').findById(nuevaVenta._id)
      .populate('cajero', 'nombre usuario')
      .populate('sucursal', 'nombre direccion')
      .populate('productos.producto', 'nombre precio_base')
      .populate('productos.personalizaciones.ingrediente', 'nombre precio_adicional');

    return res.status(201).json({
      success: true,
      message: 'Venta creada exitosamente',
      data: ventaCreada,
      advertencias: validacionInventario.ingredientesOpcionalesInsuficientes.length > 0 ? {
        ingredientes_opcionales_insuficientes: 
          validacionInventario.ingredientesOpcionalesInsuficientes.map(i => i.nombre)
      } : undefined,
      alertas_inventario: resultadoInventario.alertas || []
    });
  } catch (error) {
    logger.error('[VentaController] Error al crear venta:', error);
    return res.status(500).json({
      success: false,
      message: 'Error al crear la venta',
      error: error.message,
      stack: process.env.NODE_ENV !== 'production' ? error.stack : undefined
    });
  }
};

// Método optimizado para obtener ventas con filtros
exports.obtenerTodas = async (req, res) => {
  try {
    const { 
      pagina = 1, 
      limite = 10, 
      fechaInicio, 
      fechaFin, 
      metodoPago, 
      estado,
      ciclo_caja,
      cajero,
      sucursal
    } = req.query;
    
    // Construir filtro para aprovechar índices creados
    const filtro = {};
    
    // Filtro por fechas - usar índice compuesto fecha_ciclo_sucursal
    if (fechaInicio || fechaFin) {
      filtro.fecha = {};
      if (fechaInicio) {
        filtro.fecha.$gte = new Date(fechaInicio);
      }
      if (fechaFin) {
        const fechaFinObj = new Date(fechaFin);
        fechaFinObj.setHours(23, 59, 59, 999);
        filtro.fecha.$lte = fechaFinObj;
      }
    }
    
    // Aprovechar índice compuesto fecha_ciclo_sucursal_metodo_pago
    if (metodoPago) {
      filtro.metodo_pago = metodoPago;
    }
    
    if (estado) {
      filtro.estado = estado;
    }
    
    if (ciclo_caja) {
      filtro.ciclo_caja = new mongoose.Types.ObjectId(ciclo_caja);
    }
    
    if (cajero) {
      filtro.cajero = new mongoose.Types.ObjectId(cajero);
    }
    
    // Restricción por sucursal si no es admin
    if (sucursal || (req.usuario && req.usuario.rol !== 'administrador')) {
      filtro.sucursal = sucursal ? 
        new mongoose.Types.ObjectId(sucursal) : 
        new mongoose.Types.ObjectId(req.usuario.sucursal);
    }
    
    // Paginación
    const skip = (parseInt(pagina) - 1) * parseInt(limite);
    
    // Proyección optimizada - seleccionar solo campos necesarios
    const ventas = await Venta.find(filtro)
      .select('fecha cajero sucursal metodo_pago total estado ciclo_caja')
      .populate('cajero', 'nombre') // Solo traer nombre, no toda la info
      .populate('sucursal', 'nombre')
      .populate('ciclo_caja', 'fecha_apertura fecha_cierre')
      .sort({ fecha: -1 }) // Ordenar por fecha descendente
      .skip(skip)
      .limit(parseInt(limite))
      .lean();
    
    // Contar total en paralelo
    const total = await Venta.countDocuments(filtro);
    
    logger.performance('venta.obtenerTodas', ventas.length, { filtro });
    return res.status(200).json({
      success: true,
      data: ventas,
      meta: {
        total,
        pagina: parseInt(pagina),
        limite: parseInt(limite),
        paginas: Math.ceil(total / parseInt(limite))
      }
    });
  } catch (error) {
    logger.error('Error en obtenerTodas', error);
    return res.status(500).json({
      success: false,
      message: 'Error al obtener ventas',
      error: error.message
    });
  }
};

// Método optimizado para obtener detalle de venta
exports.obtenerPorId = async (req, res) => {
  try {
    const { id } = req.params;
    
    // Uso de índice _id y proyección para excluir campos innecesarios
    const venta = await Venta.findById(id)
      .select('-__v')
      .populate('cajero', 'nombre')
      .populate('sucursal', 'nombre direccion')
      .populate('ciclo_caja', 'fecha_apertura fecha_cierre')
      .lean();
    
    if (!venta) {
      return res.status(404).json({
        success: false,
        message: 'Venta no encontrada'
      });
    }
    
    // Verificar permisos - solo admin o cajero de la misma sucursal
    if (req.usuario.rol !== 'administrador' && 
        venta.sucursal._id.toString() !== req.usuario.sucursal.toString()) {
      return res.status(403).json({
        success: false,
        message: 'No tiene permisos para ver esta venta'
      });
    }
    
    return res.status(200).json({
      success: true,
      data: venta
    });
  } catch (error) {
    logger.error('Error en obtenerPorId', error);
    return res.status(500).json({ 
      success: false, 
      message: 'Error al obtener venta',
      error: error.message
    });
  }
};

// Método optimizado para obtener ventas por ciclo de caja (aprovecha índice creado)
exports.obtenerPorCiclo = async (req, res) => {
  try {
    const { id } = req.params;
    
    // Verificar que el ciclo existe
    const ciclo = await CicloCaja.findById(id).lean();
    if (!ciclo) {
      return res.status(404).json({
        success: false,
        message: 'Ciclo de caja no encontrado'
      });
    }
    
    // Usar índice compuesto ciclo_caja
    const ventas = await Venta.find({ ciclo_caja: id, estado: 'completada' })
      .select('fecha total metodo_pago cajero')
      .populate('cajero', 'nombre')
      .sort({ fecha: -1 })
      .lean();
    
    // Calcular totales por método de pago
    const totalesPorMetodo = {};
    let totalGeneral = 0;
    
    ventas.forEach(venta => {
      if (!totalesPorMetodo[venta.metodo_pago]) {
        totalesPorMetodo[venta.metodo_pago] = 0;
      }
      totalesPorMetodo[venta.metodo_pago] += venta.total;
      totalGeneral += venta.total;
    });
    
    logger.info('Ventas por ciclo obtenidas', { cicloId: id, totalVentas: ventas.length });
    return res.status(200).json({
      success: true,
      data: {
        ventas,
        totales: {
          por_metodo: totalesPorMetodo,
          general: totalGeneral
        },
        ciclo
      }
    });
  } catch (error) {
    logger.error('Error en obtenerPorCiclo', error);
    return res.status(500).json({ 
      success: false, 
      message: 'Error al obtener ventas por ciclo',
      error: error.message
    });
  }
};

module.exports = {
  crearVenta,
  obtenerTodas,
  obtenerPorId,
  obtenerPorCiclo
};