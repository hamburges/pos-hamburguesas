const Caja = require('../models/Caja');
const Venta = require('../models/Venta');
const Usuario = require('../models/Usuario');
const { extractUserData, hasValidUserData } = require('../utils/userAdapter');
const logger = require('../utils/logger');

const cajaController = {
  // Abrir una nueva caja
  abrirCaja: async (req, res) => {
    try {
      // Validación de contrato mediante el adaptador
      if (!hasValidUserData(req)) {
        return res.status(400).json({
          success: false,
          message: 'Información de usuario no disponible'
        });
      }
      
      // Obtener datos normalizados del usuario
      const userData = extractUserData(req);
      console.log("Usuario en abrirCaja:", userData);
      
      const { monto_apertura } = req.body;
      
      // Verificar si ya hay una caja abierta para este cajero y sucursal
      const cajaAbierta = await Caja.findOne({
        cajero: userData.id,
        sucursal: userData.sucursal,
        estado: 'abierta'
      });
      
      if (cajaAbierta) {
        return res.status(400).json({
          success: false,
          message: 'Ya tienes una caja abierta. Debes cerrarla antes de abrir una nueva.'
        });
      }
      
      // Crear nueva caja
      const nuevaCaja = new Caja({
        sucursal: userData.sucursal,
        cajero: userData.id,
        monto_apertura,
        fecha_apertura: new Date(),
        estado: 'abierta'
      });
      
      await nuevaCaja.save();
      
      return res.status(201).json({
        success: true,
        message: 'Caja abierta correctamente',
        data: nuevaCaja
      });
    } catch (error) {
      console.error('Error al abrir caja:', error);
      return res.status(500).json({
        success: false,
        message: 'Error al abrir la caja',
        error: error.message
      });
    }
  },
  
  // Obtener caja actual del cajero
  obtenerCajaActual: async (req, res) => {
    try {
      // Validación de contrato mediante el adaptador
      if (!hasValidUserData(req)) {
        return res.status(400).json({
          success: false,
          message: 'Información de usuario no disponible'
        });
      }
      
      // Obtener datos normalizados del usuario
      const userData = extractUserData(req);
      console.log("Usuario en obtenerCajaActual:", userData);
      
      const cajaActual = await Caja.findOne({
        cajero: userData.id,
        sucursal: userData.sucursal,
        estado: 'abierta'
      }).populate('ventas').lean();
      
      if (!cajaActual) {
        return res.status(404).json({
          success: false,
          message: 'No tienes una caja abierta actualmente.'
        });
      }
      
      return res.status(200).json({
        success: true,
        data: cajaActual
      });
    } catch (error) {
      console.error('Error al obtener caja actual:', error);
      return res.status(500).json({
        success: false,
        message: 'Error al obtener la caja actual',
        error: error.message
      });
    }
  },
  
  // Añadir movimiento a caja
  agregarMovimiento: async (req, res) => {
    try {
      // Validación de contrato mediante el adaptador
      if (!hasValidUserData(req)) {
        return res.status(400).json({
          success: false,
          message: 'Información de usuario no disponible'
        });
      }
      
      // Obtener datos normalizados del usuario
      const userData = extractUserData(req);
      
      const { tipo, concepto, monto } = req.body;
      
      // Validar datos
      if (!tipo || !concepto || monto === undefined) {
        return res.status(400).json({
          success: false,
          message: 'Faltan datos requeridos: tipo, concepto y monto son obligatorios'
        });
      }
      
      // Verificar que la caja esté abierta
      const cajaActual = await Caja.findOne({
        cajero: userData.id,
        sucursal: userData.sucursal,
        estado: 'abierta'
      });
      
      if (!cajaActual) {
        return res.status(404).json({
          success: false,
          message: 'No tienes una caja abierta actualmente.'
        });
      }
      
      // Añadir movimiento
      const nuevoMovimiento = {
        tipo,
        concepto,
        monto,
        fecha: new Date()
      };
      
      // Si es un egreso y el usuario no es administrador, requerir autorización
      if (tipo === 'egreso' && userData.rol !== 'administrador') {
        const { codigo_autorizacion } = req.body;
        
        if (!codigo_autorizacion) {
          return res.status(400).json({
            success: false,
            message: 'Se requiere código PIN para autorizar este egreso.'
          });
        }
        
        // Buscar administrador por código de autorización
        const administrador = await Usuario.findOne({ 
          codigo_autorizacion: codigo_autorizacion,
          rol: 'administrador',
          estado: 'activo'
        });
        
        if (!administrador) {
          return res.status(403).json({
            success: false,
            message: 'Código PIN de autorización inválido.'
          });
        }
        
        nuevoMovimiento.autorizado_por = administrador._id;
      }
      
      await Caja.updateOne(
        { _id: cajaActual._id },
        { $push: { movimientos: nuevoMovimiento } }
      );
      
      return res.status(200).json({
        success: true,
        message: 'Movimiento registrado correctamente',
        data: cajaActual
      });
    } catch (error) {
      console.error('Error al agregar movimiento:', error);
      return res.status(500).json({
        success: false,
        message: 'Error al registrar el movimiento',
        error: error.message
      });
    }
  },
  
  // Realizar cierre de caja
  cerrarCaja: async (req, res) => {
    try {
      // Validación de contrato mediante el adaptador
      if (!hasValidUserData(req)) {
        return res.status(400).json({
          success: false,
          message: 'Información de usuario no disponible'
        });
      }
      
      // Obtener datos normalizados del usuario
      const userData = extractUserData(req);
      
      const { monto_cierre_real, notas_cierre } = req.body;
      
      // Validar datos
      if (monto_cierre_real === undefined) {
        return res.status(400).json({
          success: false,
          message: 'El monto de cierre real es obligatorio'
        });
      }
      
      // Verificar que la caja esté abierta
      const cajaActual = await Caja.findOne({
        cajero: userData.id,
        sucursal: userData.sucursal,
        estado: 'abierta'
      });
      
      if (!cajaActual) {
        return res.status(404).json({
          success: false,
          message: 'No tienes una caja abierta actualmente.'
        });
      }
      
      // Calcular monto en sistema (monto apertura + ventas en efectivo - egresos + ingresos)
      // Obtener todas las ventas asociadas a esta caja
      const resultado = await Venta.aggregate([
        { $match: { cajero: userData.id, fecha: { $gte: cajaActual.fecha_apertura } } },
        { $group: { _id: null, total: { $sum: "$total" } } }
      ]);
      const totalVentas = resultado.length > 0 ? resultado[0].total : 0;
      
      // Calcular total de movimientos
      const totalMovimientos = cajaActual.movimientos.reduce((sum, mov) => {
        if (mov.tipo === 'ingreso') {
          return sum + mov.monto;
        } else {
          return sum - mov.monto;
        }
      }, 0);
      
      // Calcular monto teórico según sistema
      const monto_cierre_sistema = cajaActual.monto_apertura + totalVentas + totalMovimientos;
      
      // Calcular diferencia
      const diferencia = monto_cierre_real - monto_cierre_sistema;
      
      // Actualizar caja
      cajaActual.monto_cierre_sistema = monto_cierre_sistema;
      cajaActual.monto_cierre_real = monto_cierre_real;
      cajaActual.diferencia = diferencia;
      cajaActual.estado = 'cerrada';
      cajaActual.fecha_cierre = new Date();
      cajaActual.notas_cierre = notas_cierre || '';
      cajaActual.ventas = resultado.map(venta => venta._id);
      
      await cajaActual.save();
      
      return res.status(200).json({
        success: true,
        message: 'Caja cerrada correctamente',
        data: {
          caja: cajaActual,
          resumen: {
            monto_apertura: cajaActual.monto_apertura,
            ventas_efectivo: totalVentas,
            movimientos: totalMovimientos,
            monto_cierre_sistema,
            monto_cierre_real,
            diferencia
          }
        }
      });
    } catch (error) {
      console.error('Error al cerrar caja:', error);
      return res.status(500).json({
        success: false,
        message: 'Error al cerrar la caja',
        error: error.message
      });
    }
  },
  
  // Obtener historial de cajas
  obtenerHistorial: async (req, res) => {
    try {
      // Validación de contrato mediante el adaptador
      if (!hasValidUserData(req)) {
        return res.status(400).json({
          success: false,
          message: 'Información de usuario no disponible'
        });
      }
      
      // Obtener datos normalizados del usuario
      const userData = extractUserData(req);
      
      const { fechaInicio, fechaFin, sucursal } = req.query;
      
      // Construir filtro
      const filtro = {};
      
      // Si el usuario no es administrador, solo puede ver sus cajas
      if (userData.rol !== 'administrador') {
        filtro.cajero = userData.id;
      }
      
      // Filtrar por sucursal si se especifica y el usuario es admin
      if (sucursal && userData.rol === 'administrador') {
        filtro.sucursal = sucursal;
      } else if (userData.rol !== 'administrador') {
        // Si no es admin, solo ve su sucursal
        filtro.sucursal = userData.sucursal;
      }
      
      // Filtrar por fechas si se especifican
      if (fechaInicio || fechaFin) {
        filtro.fecha_apertura = {};
        
        if (fechaInicio) {
          filtro.fecha_apertura.$gte = new Date(fechaInicio);
        }
        
        if (fechaFin) {
          const fechaFinAjustada = new Date(fechaFin);
          fechaFinAjustada.setHours(23, 59, 59, 999);
          filtro.fecha_apertura.$lte = fechaFinAjustada;
        }
      }
      
      // Obtener registros de caja
      const cajas = await Caja.find(filtro)
        .select('fecha_apertura monto_apertura monto_cierre_real estado cajero sucursal')
        .sort({ fecha_apertura: -1 })
        .populate('cajero', 'nombre usuario')
        .populate('sucursal', 'nombre')
        .lean();
      
      return res.status(200).json({
        success: true,
        data: cajas
      });
    } catch (error) {
      console.error('Error al obtener historial de cajas:', error);
      return res.status(500).json({
        success: false,
        message: 'Error al obtener el historial de cajas',
        error: error.message
      });
    }
  },
  
  // Obtener detalles de una caja específica
  obtenerDetalleCaja: async (req, res) => {
    try {
      // Validación de contrato mediante el adaptador
      if (!hasValidUserData(req)) {
        return res.status(400).json({
          success: false,
          message: 'Información de usuario no disponible'
        });
      }
      
      // Obtener datos normalizados del usuario
      const userData = extractUserData(req);
      
      const { id } = req.params;
      
      const caja = await Caja.findById(id)
        .populate('cajero', 'nombre usuario')
        .populate('sucursal', 'nombre direccion')
        .populate('ventas')
        .populate('movimientos.autorizado_por', 'nombre')
        .lean();
      
      if (!caja) {
        return res.status(404).json({
          success: false,
          message: 'Caja no encontrada'
        });
      }
      
      // Verificar permisos: solo admin o el cajero propietario
      if (userData.rol !== 'administrador' && caja.cajero._id.toString() !== userData.id) {
        return res.status(403).json({
          success: false,
          message: 'No tienes permiso para ver esta caja'
        });
      }
      
      return res.status(200).json({
        success: true,
        data: caja
      });
    } catch (error) {
      console.error('Error al obtener detalle de caja:', error);
      return res.status(500).json({
        success: false,
        message: 'Error al obtener el detalle de la caja',
        error: error.message
      });
    }
  }
};

module.exports = cajaController;