// controllers/auth.controller.js
const Usuario = require('../models/Usuario');
const { generarToken } = require('../utils/auth.utils');
const logger = require('../utils/logger');

/**
 * Controlador para manejar la autenticación de usuarios
 */
const AuthController = {
  /**
   * Iniciar sesión
   * @param {Object} req - Request con usuario y contraseña
   * @param {Object} res - Response
   */
  login: async (req, res) => {
    try {
      const { usuario, contrasena } = req.body;
      logger.info('[AuthController] Intento de login', { usuario });

      // Comprobar campos requeridos
      if (!usuario || !contrasena) {
        logger.warn('[AuthController] Falta usuario o contraseña');
        return res.status(400).json({ 
          success: false, 
          message: 'Usuario y contraseña son requeridos' 
        });
      }

      // Buscar usuario en la base de datos
      const usuarioEncontrado = await Usuario.findOne({ usuario })
        .select('nombre usuario rol estado sucursal contrasena')
        .populate('sucursal', 'nombre direccion');
      
      logger.info('[AuthController] Usuario encontrado', { encontrado: !!usuarioEncontrado });
      
      if (!usuarioEncontrado) {
        logger.warn('[AuthController] Usuario no encontrado en la base de datos');
        return res.status(401).json({ 
          success: false, 
          message: 'Credenciales inválidas' 
        });
      }

      logger.debug('[AuthController] Detalles del usuario', {
        id: usuarioEncontrado._id,
        nombre: usuarioEncontrado.nombre,
        rol: usuarioEncontrado.rol,
        estado: usuarioEncontrado.estado
      });

      // Verificar si el usuario está activo
      if (usuarioEncontrado.estado !== 'activo') {
        logger.warn('[AuthController] Usuario desactivado');
        return res.status(401).json({ 
          success: false, 
          message: 'Este usuario ha sido desactivado' 
        });
      }

      // Verificar contraseña
      const contrasenaValida = await usuarioEncontrado.verificarContrasena(contrasena);
      
      logger.info('[AuthController] Resultado de verificación de contraseña', { valida: contrasenaValida });
      
      if (!contrasenaValida) {
        logger.warn('[AuthController] Contraseña inválida');
        return res.status(401).json({ 
          success: false, 
          message: 'Credenciales inválidas' 
        });
      }

      logger.info('[AuthController] Autenticación exitosa, generando token');

      // Generar token de autenticación
      const token = generarToken({
        id: usuarioEncontrado._id,
        usuario: usuarioEncontrado.usuario,
        nombre: usuarioEncontrado.nombre,
        rol: usuarioEncontrado.rol,
        sucursal: usuarioEncontrado.sucursal._id
      });

      logger.info('[AuthController] Token generado exitosamente');

      // Devolver información del usuario y token
      return res.status(200).json({
        success: true,
        message: 'Inicio de sesión exitoso',
        data: {
          usuario: {
            id: usuarioEncontrado._id,
            nombre: usuarioEncontrado.nombre,
            usuario: usuarioEncontrado.usuario,
            rol: usuarioEncontrado.rol,
            sucursal: {
              id: usuarioEncontrado.sucursal._id,
              nombre: usuarioEncontrado.sucursal.nombre
            }
          },
          token
        }
      });
    } catch (error) {
      logger.error('[AuthController] Error en login', error);
      return res.status(500).json({ 
        success: false, 
        message: 'Error al iniciar sesión', 
        error: error.message 
      });
    }
  },

  /**
   * Verificar token de autenticación
   * @param {Object} req - Request con token en headers
   * @param {Object} res - Response
   */
  verificarToken: async (req, res) => {
    try {
      // El middleware de autenticación ya verificó el token
      // Usamos req.usuarioId en lugar de req.usuario.id
      const usuarioEncontrado = await Usuario.findById(req.usuarioId)
        .populate('sucursal', 'nombre direccion')
        .select('nombre usuario rol sucursal')
        .lean();

      if (!usuarioEncontrado) {
        logger.warn('[AuthController] Usuario no encontrado');
        return res.status(404).json({ 
          success: false, 
          message: 'Usuario no encontrado' 
        });
      }

      return res.status(200).json({
        success: true,
        data: {
          usuario: {
            id: usuarioEncontrado._id,
            nombre: usuarioEncontrado.nombre,
            usuario: usuarioEncontrado.usuario,
            rol: usuarioEncontrado.rol,
            sucursal: {
              id: usuarioEncontrado.sucursal._id,
              nombre: usuarioEncontrado.sucursal.nombre
            }
          }
        }
      });
    } catch (error) {
      logger.error('[AuthController] Error en verificarToken', error);
      return res.status(500).json({ 
        success: false, 
        message: 'Error al verificar token', 
        error: error.message 
      });
    }
  }
};

module.exports = AuthController;