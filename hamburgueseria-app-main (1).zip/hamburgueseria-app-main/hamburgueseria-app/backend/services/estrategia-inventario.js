/**
 * Define estrategias de medición para diferentes tipos de ingredientes
 */
class EstrategiaIngrediente {
    calcularCantidadADescontar(cantidad, ingrediente) {
      throw new Error('Método abstracto debe implementarse');
    }
  }
  
  class EstrategiaIngredienteContable extends EstrategiaIngrediente {
    calcularCantidadADescontar(cantidad, ingrediente) {
      return Math.round(cantidad); // Asegura valores enteros
    }
  }
  
  class EstrategiaIngredienteNoContable extends EstrategiaIngrediente {
    calcularCantidadADescontar(cantidad, ingrediente) {
      const factores = {
        'ml': 1, 'gr': 1, 'oz': 30, 'lt': 1000, 'kg': 1000, 'default': 1
      };
      const factor = factores[ingrediente.unidad_medida?.toLowerCase()] || factores.default;
      return cantidad * factor;
    }
  }
  
  class EstrategiaIngredienteFactory {
    obtenerEstrategia(ingrediente) {
      const unidadesContables = ['unidad', 'pieza', 'slice', 'unit', 'und'];
      if (unidadesContables.includes(ingrediente.unidad_medida?.toLowerCase())) {
        return new EstrategiaIngredienteContable();
      }
      return new EstrategiaIngredienteNoContable();
    }
  }
  
  module.exports = {
    EstrategiaIngrediente,
    EstrategiaIngredienteContable,
    EstrategiaIngredienteNoContable,
    estrategiaIngredienteFactory: new EstrategiaIngredienteFactory()
  };