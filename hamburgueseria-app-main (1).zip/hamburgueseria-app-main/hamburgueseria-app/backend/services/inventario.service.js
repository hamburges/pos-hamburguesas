/**
 * Servicio de Inventario con arquitectura de múltiples capas
 * 
 * Implementa patrón Strategy para discriminación contextual,
 * patrón Repository para acceso a datos,
 * patrón Interceptor para garantía de unicidad, y
 * patrón Observer para notificaciones en umbrales críticos.
 * 
 * @module services/inventario.service
 */
const Ingrediente = require('../models/Ingrediente');
const OpcionProducto = require('../models/OpcionProducto');
const mongoose = require('mongoose');

/**
 * Servicio de gestión transaccional de inventario con responsabilidad única
 * y mecanismos de prevención de duplicación
 */
class InventarioService {
  constructor() {
    /**
     * Estrategia de tracking para operaciones ya procesadas
     * @private
     * @type {Map<string,Object>}
     */
    this._operacionesRegistradas = new Map();
    
    /**
     * Configuración de criticidad con valores predeterminados
     * @type {Object}
     */
    this.configuracionCriticidad = {
      // Ingredientes considerados críticos por nombre
      nombresCriticos: ['pan', 'carne', 'salchicha', 'chorizo'],
      
      // Unidades de medida que implican ingredientes críticos contables
      unidadesCriticas: ['unidad', 'pieza'],
      
      // CRUCIAL: Nivel mínimo para bloqueo (0 = permitir hasta agotar stock completamente)
      nivelMinimoPermitido: 0
    };
    
    // Inicializar estado interno para rastreo de sesión
    this._resetEstadoSesion();
  }

  /**
   * Valida disponibilidad de inventario para una venta propuesta
   * @param {Object} datosVenta - Datos transaccionales para validación preventiva
   * @returns {Promise<Object>} - Resultado detallado de validación con insights accionables
   */
  async validarDisponibilidadParaVenta(datosVenta) {
    try {
      // Reset estado para esta validación (previene interferencia entre transacciones)
      this._resetEstadoSesion();
      
      // Traducir venta a operaciones de inventario con deduplicación
      const operaciones = await this._traducirVentaAOperaciones(datosVenta);
      
      // Validar cada ingrediente con estrategia contextual
      const resultadosValidacion = await Promise.all(
        operaciones.map(op => this._validarDisponibilidadIngrediente(op))
      );
      
      // Clasificar resultados según criticidad para decisiones diferenciadas
      const ingredientesCriticosInsuficientes = resultadosValidacion.filter(
        r => !r.disponible && r.esCritico
      );
      
      const ingredientesOpcionalesInsuficientes = resultadosValidacion.filter(
        r => !r.disponible && !r.esCritico
      );

      // Construir resultado agregado con máxima información accionable
      return {
        disponibilidadCompleta: ingredientesCriticosInsuficientes.length === 0 && 
                                ingredientesOpcionalesInsuficientes.length === 0,
        permitirVenta: ingredientesCriticosInsuficientes.length === 0,
        ingredientesCriticosInsuficientes,
        ingredientesOpcionalesInsuficientes,
        detalleValidacion: resultadosValidacion,
        timestamp: new Date()
      };
    } catch (error) {
      console.error('[InventarioService] Error validando disponibilidad:', error);
      return {
        disponibilidadCompleta: false,
        permitirVenta: false,
        error: error.message,
        stack: process.env.NODE_ENV !== 'production' ? error.stack : undefined
      };
    }
  }

  /**
   * Procesa descuentos de inventario con garantía transaccional para una venta completada
   * @param {Object} venta - Entidad venta completa con productos y personalizaciones
   * @returns {Promise<Object>} - Resultado detallado de operación con alertas generadas
   */
  async procesarDescuentosPorVenta(venta) {
    // Validación de precondición para evitar procesamiento innecesario
    if (venta.estado !== 'completada') {
      return { 
        success: true, 
        message: 'Venta no completada, no se aplican descuentos',
        timestamp: new Date()
      };
    }

    // Reset estado para esta transacción (previene interferencia entre transacciones)
    this._resetEstadoSesion();

    try {
      // Traducir venta a operaciones de inventario con garantía de unicidad
      const operaciones = await this._traducirVentaAOperaciones(venta);
      
      // Log para diagnóstico y auditoría
      console.log(`[InventarioService] Procesando ${operaciones.length} operaciones de inventario para venta ${venta._id || venta.numero_venta}`);
      
      // Contenedores para resultados y alertas
      const resultados = [];
      const alertas = [];

      // Procesar cada operación como unidad atómica e independiente
      for (const operacion of operaciones) {
        try {
          // Identificador único para esta operación (previene duplicación)
          const operacionId = `${operacion.ingredienteId}-${operacion.tipo}-${Date.now()}`;
          
          // Verificar si ya fue procesada en esta sesión
          if (this._operacionesRegistradas.has(operacionId)) {
            console.warn(`[InventarioService] Operación duplicada detectada y omitida: ${operacionId}`);
            resultados.push(this._operacionesRegistradas.get(operacionId));
            continue;
          }
          
          // Procesar esta operación única
          const resultado = await this._procesarOperacionInventario(operacion);
          resultados.push(resultado);
          
          // Registrar para evitar duplicación
          this._operacionesRegistradas.set(operacionId, resultado);
          
          // Detección proactiva de umbrales críticos para alertas
          if (resultado.alertaStockBajo) {
            alertas.push({
              tipo: 'stock_bajo',
              ingrediente: resultado.ingrediente.nombre,
              stock_actual: resultado.ingrediente.stock,
              stock_minimo: resultado.ingrediente.stock_minimo,
              unidad_medida: resultado.ingrediente.unidad_medida || 'unidad',
              timestamp: new Date()
            });
          }
        } catch (error) {
          console.error(`[InventarioService] Error procesando operación para ${operacion.ingredienteId}:`, error);
          resultados.push({ 
            success: false, 
            ingredienteId: operacion.ingredienteId,
            error: error.message,
            timestamp: new Date()
          });
        }
      }

      return {
        success: true,
        resultados,
        alertas,
        timestamp: new Date()
      };
    } catch (error) {
      console.error('[InventarioService] Error procesando descuentos:', error);
      return {
        success: false,
        error: error.message,
        stack: process.env.NODE_ENV !== 'production' ? error.stack : undefined
      };
    }
  }

  /**
   * Traduce venta a operaciones de inventario con algoritmo anti-duplicación mejorado
   * @private
   * @param {Object} venta - Venta o datos de venta para traducción
   * @returns {Promise<Array<Object>>} - Operaciones de inventario sin duplicidades
   */
  async _traducirVentaAOperaciones(venta) {
    console.log(`[InventarioService] Iniciando traducción de venta ${venta._id || 'nueva'}`);
    
    // Validación defensiva contra datos malformados
    if (!venta.productos || !Array.isArray(venta.productos)) {
      return [];
    }

    // Estructura de datos para garantizar unicidad absoluta
    const operacionesUnicas = new Map();

    // Procesar cada producto con tracking contextual
    for (const item of venta.productos) {
      // Normalización obligatoria del identificador
      const idProducto = typeof item.producto === 'object' ? 
                        (item.producto._id || item.producto).toString() : 
                        item.producto.toString();
      
      const cantidad = Number(item.cantidad || 1);
      
      try {
        // 1. Obtener opciones predeterminadas del producto
        const opcionesProducto = await OpcionProducto.find({ producto: idProducto })
          .populate('ingrediente');
        
        // 2. Identificar ingredientes explícitamente quitados con normalización de identidad
        const ingredientesQuitados = new Set();
        
        // 3. Rastrear ingredientes predeterminados y sus cantidades para evitar duplicación
        const ingredientesPredeterminados = new Map();
        
        if (item.personalizaciones && Array.isArray(item.personalizaciones)) {
          item.personalizaciones
            .filter(p => p.accion === 'quitar')
            .forEach(p => {
              // Normalización robusta de identificador
              const idIngrediente = typeof p.ingrediente === 'object' ?
                                   (p.ingrediente._id || p.ingrediente).toString() :
                                   p.ingrediente.toString();
              
              ingredientesQuitados.add(idIngrediente);
            });
        }
        
        // 4. Procesar ingredientes predeterminados que NO fueron quitados
        for (const opcion of opcionesProducto) {
          // Normalización garantizada del identificador
          const idIngrediente = opcion.ingrediente._id.toString();
          
          // Omitir si este ingrediente fue quitado explícitamente
          if (ingredientesQuitados.has(idIngrediente)) {
            continue;
          }
          
          // Registrar este ingrediente y su cantidad para referencia al procesar personalizaciones
          const cantidadBase = Number(opcion.cantidad_predeterminada || 1) * cantidad;
          ingredientesPredeterminados.set(idIngrediente, cantidadBase);
          
          // Registrar operación con contexto de origen para diagnóstico
          this._registrarOperacionUnica(
            operacionesUnicas, 
            idIngrediente, 
            cantidadBase, 
            'descontar',
            {
              tipo: 'predeterminado',
              producto: idProducto,
              nombre_ingrediente: opcion.ingrediente.nombre || 'Desconocido'
            }
          );
        }
        
        // 5. Procesar ingredientes adicionales (explícitamente agregados)
        if (item.personalizaciones && Array.isArray(item.personalizaciones)) {
          // CRUCIAL: Solo procesar los de tipo "agregar", no los "quitar"
          item.personalizaciones
            .filter(p => p.accion === 'agregar')
            .forEach(p => {
              // Normalización garantizada del identificador
              const idIngrediente = typeof p.ingrediente === 'object' ?
                                   (p.ingrediente._id || p.ingrediente).toString() :
                                   p.ingrediente.toString();
              
              // Calcular cantidad adicional necesaria
              const cantidadPersonalizada = Number(p.cantidad || 1) * cantidad;
              
              // Si este ingrediente ya está en ingredientes predeterminados,
              // solo registramos la diferencia adicional (si es positiva)
              if (ingredientesPredeterminados.has(idIngrediente)) {
                const cantidadPredeterminada = ingredientesPredeterminados.get(idIngrediente);
                
                // Si la cantidad personalizada es mayor que la predeterminada,
                // solo registramos la diferencia
                if (cantidadPersonalizada > cantidadPredeterminada) {
                  const cantidadAdicional = cantidadPersonalizada - cantidadPredeterminada;
                  console.log(`[InventarioService] Ingrediente ${idIngrediente} ya procesado como predeterminado. Procesando solo cantidad adicional: ${cantidadAdicional}`);
                  
                  // Obtener nombre para diagnóstico
                  const nombreIngrediente = p.ingrediente.nombre || 
                                          (typeof p.ingrediente === 'object' ? p.ingrediente.nombre : 'Desconocido');
                  
                  // Registrar la diferencia adicional
                  this._registrarOperacionUnica(
                    operacionesUnicas, 
                    idIngrediente, 
                    cantidadAdicional, 
                    'descontar',
                    {
                      tipo: 'personalizado_adicional',
                      producto: idProducto,
                      nombre_ingrediente: nombreIngrediente,
                      cantidadPredeterminada: cantidadPredeterminada,
                      cantidadTotal: cantidadPersonalizada
                    }
                  );
                } else {
                  console.log(`[InventarioService] Ignorando personalización redundante para ingrediente ${idIngrediente}: cantidad personalizada ${cantidadPersonalizada} <= predeterminada ${cantidadPredeterminada}`);
                }
              } else {
                // Si no es un ingrediente predeterminado, procesamos la cantidad completa
                // Obtener nombre para diagnóstico
                const nombreIngrediente = p.ingrediente.nombre || 
                                        (typeof p.ingrediente === 'object' ? p.ingrediente.nombre : 'Desconocido');
                
                // Registrar operación completa
                this._registrarOperacionUnica(
                  operacionesUnicas, 
                  idIngrediente, 
                  cantidadPersonalizada, 
                  'descontar',
                  {
                    tipo: 'personalizado_nuevo',
                    producto: idProducto,
                    nombre_ingrediente: nombreIngrediente
                  }
                );
              }
            });
        }
      } catch (error) {
        console.error(`[InventarioService] Error procesando producto ${idProducto}:`, error);
      }
    }
    
    // Diagnóstico de operaciones consolidadas
    console.log('[InventarioService] Operaciones consolidadas:');
    operacionesUnicas.forEach((op, key) => {
      console.log(`- ${key}: ${op.ingredienteId} (${op.origenes?.[0]?.nombre_ingrediente || op.origen?.nombre_ingrediente || 'Desconocido'}), cantidad: ${op.cantidad}`);
    });
    
    return Array.from(operacionesUnicas.values());
  }

  /**
   * Registra operación en mapa con garantía absoluta de unicidad y trazabilidad completa
   * @private
   * @param {Map} mapa - Mapa de operaciones únicas
   * @param {string} idIngrediente - ID del ingrediente
   * @param {number} cantidad - Cantidad a procesar
   * @param {string} tipo - Tipo de operación (descontar/agregar)
   * @param {Object} origen - Información contextual sobre el origen de la operación
   */
  _registrarOperacionUnica(mapa, idIngrediente, cantidad, tipo, origen) {
    // Clave única por combinación ingrediente-operación (independiente del origen)
    const key = `${idIngrediente}-${tipo}`;
    
    if (mapa.has(key)) {
      // Consolidación de operación existente
      const operacionExistente = mapa.get(key);
      
      // Actualizar cantidad acumulada (previene duplicación)
      operacionExistente.cantidad += cantidad;
      
      // Tracking completo de orígenes para diagnóstico
      if (!operacionExistente.origenes) {
        operacionExistente.origenes = [operacionExistente.origen];
        delete operacionExistente.origen; // Migrar a estructura multioriginal
      }
      
      // Registrar origen adicional con timestamp para trazabilidad
      origen.timestamp = new Date();
      operacionExistente.origenes.push(origen);
      
      // Log para diagnóstico de patrones de duplicación
      console.log(`[InventarioService] Operación consolidada: ${key}, nueva cantidad: ${operacionExistente.cantidad}, orígenes: ${operacionExistente.origenes.length}`);
    } else {
      // Crear operación con trazabilidad inicial
      origen.timestamp = new Date();
      
      mapa.set(key, {
        ingredienteId: idIngrediente,
        cantidad: cantidad,
        tipo: tipo,
        origen: origen
      });
    }
  }

  /**
   * Valida disponibilidad de un ingrediente específico
   * @private
   * @param {Object} operacion - Operación para validación
   * @returns {Promise<Object>} - Resultado detallado de validación
   */
  async _validarDisponibilidadIngrediente(operacion) {
    try {
      const { ingredienteId, cantidad } = operacion;
      
      // Obtener ingrediente desde repositorio
      const ingrediente = await Ingrediente.findById(ingredienteId);
      
      // Manejo defensivo de entidad no encontrada
      if (!ingrediente) {
        return {
          ingredienteId,
          nombre: 'Desconocido',
          disponible: false,
          esCritico: true,
          razonCriticidad: 'Ingrediente no encontrado o eliminado'
        };
      }

      // Aplicar estrategia de clasificación de criticidad
      const esCritico = this._esCritico(ingrediente);
      
      // Aplicar estrategia de medición según tipo de ingrediente
      const cantidadAjustada = this._calcularCantidadRequerida(cantidad, ingrediente);
      
      // PUNTO CRÍTICO: Validación con umbral cero
      // Permitir venta mientras haya stock positivo (stock > 0)
      const disponible = ingrediente.stock > this.configuracionCriticidad.nivelMinimoPermitido;
      
      return {
        ingredienteId,
        nombre: ingrediente.nombre,
        disponible,
        stockActual: ingrediente.stock,
        stockRequerido: cantidadAjustada,
        cantidadPosible: Math.min(ingrediente.stock, cantidadAjustada),
        unidadMedida: ingrediente.unidad_medida || 'unidad',
        esCritico,
        razonCriticidad: esCritico ? 
          'Ingrediente crítico para el producto' : 
          'Ingrediente opcional para el producto'
      };
    } catch (error) {
      console.error(`[InventarioService] Error validando ingrediente ${operacion.ingredienteId}:`, error);
      return {
        ingredienteId: operacion.ingredienteId,
        disponible: false,
        esCritico: true,
        error: error.message
      };
    }
  }

  /**
   * Procesa una operación individual de inventario
   * @private
   * @param {Object} operacion - Operación individual a procesar
   * @returns {Promise<Object>} - Resultado de la operación
   */
  async _procesarOperacionInventario(operacion) {
    const { ingredienteId, cantidad, tipo } = operacion;
    
    // Obtener ingrediente desde repositorio
    const ingrediente = await Ingrediente.findById(ingredienteId);
    if (!ingrediente) {
      throw new Error(`Ingrediente no encontrado: ${ingredienteId}`);
    }

    // Calcular cantidad ajustada según tipo
    const cantidadAjustada = this._calcularCantidadRequerida(cantidad, ingrediente);

    // Calcular nuevo stock con protección contra negativos
    const stockActual = ingrediente.stock;
    let cantidadProcesada;
    let nuevoStock;

    if (tipo === 'descontar') {
      // CRUCIAL: Limitar descuento al stock disponible para evitar negativos
      cantidadProcesada = Math.min(stockActual, cantidadAjustada);
      nuevoStock = Math.max(0, stockActual - cantidadProcesada);
    } else {
      cantidadProcesada = cantidadAjustada;
      nuevoStock = stockActual + cantidadProcesada;
    }

    // Actualizar en base de datos con transacción atómica
    const ingredienteActualizado = await Ingrediente.findByIdAndUpdate(
      ingredienteId,
      {
        stock: nuevoStock,
        disponible: nuevoStock > 0
      },
      { new: true }
    );

    // Verificar umbral crítico para alertas proactivas
    const alertaStockBajo = ingredienteActualizado.stock < ingredienteActualizado.stock_minimo;

    return {
      success: true,
      ingredienteId,
      ingrediente: ingredienteActualizado,
      stockAnterior: stockActual,
      cantidadProcesada, // Cantidad realmente procesada (puede ser limitada por stock)
      stockActual: ingredienteActualizado.stock,
      alertaStockBajo,
      timestamp: new Date()
    };
  }

  /**
   * Determina si un ingrediente es crítico según configuración
   * @private
   * @param {Object} ingrediente - Entidad ingrediente
   * @returns {boolean} - true si es crítico, false si es opcional
   */
  _esCritico(ingrediente) {
    // Obtener nombre en minúsculas para comparación case-insensitive
    const nombreLower = ingrediente.nombre.toLowerCase();
    
    // Verificar coincidencia por nombre
    for (const nombreCritico of this.configuracionCriticidad.nombresCriticos) {
      if (nombreLower.includes(nombreCritico.toLowerCase())) {
        return true;
      }
    }
    
    // Verificar por unidad de medida (contable vs. no contable)
    if (this.configuracionCriticidad.unidadesCriticas.includes(
        ingrediente.unidad_medida?.toLowerCase())) {
      return true;
    }
    
    // Por defecto, considerar opcional
    return false;
  }

  /**
   * Calcula cantidad exacta según tipo de ingrediente
   * @private
   * @param {number} cantidad - Cantidad nominal solicitada
   * @param {Object} ingrediente - Entidad ingrediente
   * @returns {number} - Cantidad ajustada según estrategia
   */
  _calcularCantidadRequerida(cantidad, ingrediente) {
    // Validación defensiva contra datos no numéricos
    const cantidadNumerica = Number(cantidad);
    if (isNaN(cantidadNumerica)) {
      console.warn(`[InventarioService] Cantidad no numérica detectada: ${cantidad}`);
      return 0;
    }
    
    // Para ingredientes con unidades contables (discretas)
    const unidadesContables = ['unidad', 'pieza'];
    if (unidadesContables.includes(ingrediente.unidad_medida?.toLowerCase())) {
      return Math.round(cantidadNumerica); // Asegurar valor entero
    }
    
    // Para otros tipos de unidades (continuas)
    return cantidadNumerica;
  }

  /**
   * Actualiza la configuración de criticidad dinámicamente
   * @param {Object} nuevaConfig - Nueva configuración parcial o completa
   * @returns {Object} - Configuración resultante
   */
  actualizarConfiguracionCriticidad(nuevaConfig) {
    this.configuracionCriticidad = {
      ...this.configuracionCriticidad,
      ...nuevaConfig
    };
    console.log('[InventarioService] Configuración de criticidad actualizada:', this.configuracionCriticidad);
    return { ...this.configuracionCriticidad };
  }
  
  /**
   * Reinicia el estado interno para una nueva sesión transaccional
   * @private
   */
  _resetEstadoSesion() {
    this._operacionesRegistradas = new Map();
  }
}

module.exports = new InventarioService();