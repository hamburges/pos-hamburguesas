/**
 * Servicio para clasificación de criticidad de ingredientes
 */
const Ingrediente = require('../models/Ingrediente');

class CriticidadInventarioService {
  constructor() {
    // Configuración predeterminada de ingredientes críticos
    this.configuracion = {
      nombresCriticos: new Set(['pan', 'carne', 'salchicha', 'chorizo']),
      unidadesCriticas: new Set(['unidad', 'pieza']),
      palabrasClave: ['burger', 'bread', 'meat']
    };
  }

  /**
   * Evalúa si un ingrediente es crítico para la venta
   */
  async evaluarCriticidad(ingredienteId) {
    try {
      const ingrediente = await Ingrediente.findById(ingredienteId);
      if (!ingrediente) {
        return { esCritico: true, razon: 'Ingrediente no encontrado' };
      }

      const nombreLower = ingrediente.nombre.toLowerCase();
      
      // Verificar por nombre exacto
      if (this.configuracion.nombresCriticos.has(nombreLower)) {
        return { esCritico: true, razon: 'Nombre configurado como crítico' };
      }
      
      // Verificar por unidad de medida
      if (this.configuracion.unidadesCriticas.has(ingrediente.unidad_medida?.toLowerCase())) {
        return { esCritico: true, razon: 'Unidad de medida indica ingrediente contable crítico' };
      }
      
      // Verificar por palabras clave
      for (const palabra of this.configuracion.palabrasClave) {
        if (nombreLower.includes(palabra)) {
          return { esCritico: true, razon: `Contiene palabra clave crítica: ${palabra}` };
        }
      }
      
      return { esCritico: false, razon: 'Ingrediente considerado opcional' };
    } catch (error) {
      console.error('Error evaluando criticidad:', error);
      return { esCritico: true, razon: 'Error en evaluación, considerado crítico por seguridad' };
    }
  }
  
  actualizarConfiguracion(nuevaConfig) {
    this.configuracion = {
      ...this.configuracion,
      ...nuevaConfig
    };
  }
}

module.exports = new CriticidadInventarioService();