// server.js
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const morgan = require('morgan');
const http = require('http');
const { Server } = require('socket.io');
const { connectToDatabase } = require('./config/database');
const apiRoutes = require('./routes/index');
const dashboardRoutes = require('./routes/dashboard.routes');
const compression = require('compression');
const { setCacheHeaders } = require('./middleware/cache.middleware');

// Configurar express
const app = express();
const PORT = process.env.PORT || 3001;

// Crear servidor HTTP
const server = http.createServer(app);

// Configuración mejorada de Socket.io para entornos de nube
const io = new Server(server, {
  cors: {
    origin: process.env.CORS_ORIGIN || '*', 
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    credentials: true
  },
  transports: ['websocket', 'polling'],
  pingTimeout: 60000,
  pingInterval: 25000,
  reconnectionAttempts: 5,
  reconnectionDelay: 1000
});

// Middleware CORS
const allowedOrigins = [
  'http://localhost:3000',
  'https://queberraquera.netlify.app'
];
app.use(cors({
  origin: function(origin, callback) {
    // Permitir peticiones sin origen (como Postman)
    if (!origin) return callback(null, true);
    if (allowedOrigins.includes(origin)) {
      return callback(null, true);
    } else {
      return callback(new Error('No permitido por CORS'));
    }
  },
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));

// Agregar compresión después de CORS y antes de las rutas
app.use(compression({
  threshold: 1024,
  level: process.env.NODE_ENV === 'production' ? 6 : 1,
  filter: (req, res) => {
    return req.headers['x-no-compression'] ? false : compression.filter(req, res);
  }
}));

app.use(setCacheHeaders);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Middleware para exponer io a los controladores
app.use((req, res, next) => {
  req.io = io;
  next();
});

// Logging
app.use(morgan('dev'));

// Rutas API
app.use('/api', apiRoutes);
app.use('/api', dashboardRoutes);

// Ruta de salud
app.get('/health', (req, res) => {
  res.status(200).json({ 
    success: true, 
    message: 'Servidor funcionando correctamente',
    env: process.env.NODE_ENV,
    cors_origin: process.env.CORS_ORIGIN || 'No configurado'
  });
});

// Manejo de rutas no encontradas
app.use((req, res) => {
  res.status(404).json({ 
    success: false, 
    message: 'Ruta no encontrada' 
  });
});

// Manejo de errores
app.use((err, req, res, next) => {
  console.error('Error no controlado:', err);
  res.status(500).json({ 
    success: false, 
    message: 'Error interno del servidor', 
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// Iniciar el servidor
async function startServer() {
  try {
    await connectToDatabase();
    console.log('Conexión a MongoDB establecida exitosamente');
    
    server.listen(PORT, () => {
      console.log(`Servidor ejecutándose en el puerto ${PORT}`);
      console.log(`Ambiente: ${process.env.NODE_ENV || 'development'}`);
      console.log(`CORS configurado para: ${process.env.CORS_ORIGIN || '*'}`);
    });
    
    io.on('connection', (socket) => {
      console.log('Cliente conectado vía WebSocket:', socket.id);
      
      socket.on('cocinero:conectado', () => {
        console.log('Cocinero conectado:', socket.id);
      });
      
      socket.on('error', (error) => {
        console.error('Error de socket:', error);
      });
      
      socket.on('disconnect', (reason) => {
        console.log('Cliente desconectado:', socket.id, 'Razón:', reason);
      });
    });
  } catch (error) {
    console.error('Error al iniciar el servidor:', error);
    process.exit(1);
  }
}

startServer();