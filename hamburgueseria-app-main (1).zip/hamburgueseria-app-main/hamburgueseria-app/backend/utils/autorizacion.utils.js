// backend/utils/autorizacion.utils.js
const Usuario = require('../models/Usuario');

/**
 * Servicio para verificación de credenciales administrativas
 */
const autorizacionUtils = {
  /**
   * Verifica código PIN contra credenciales administrativas
   * @param {string} codigo - Código PIN de autorización
   * @param {string} rolRequerido - Rol necesario para la operación
   * @returns {Promise<Object>} Resultado de validación
   */
  verificarAutorizacion: async (codigo, rolRequerido = 'administrador') => {
    if (!codigo) {
      return {
        success: false,
        mensaje: 'Código de autorización requerido'
      };
    }

    // Buscar administrador con el código proporcionado
    const administrador = await Usuario.findOne({
      codigo_autorizacion: codigo,
      rol: rolRequerido,
      estado: 'activo'
    }).select('_id nombre usuario');

    if (!administrador) {
      return {
        success: false,
        mensaje: 'Código de autorización inválido'
      };
    }

    return {
      success: true,
      mensaje: 'Autorización verificada',
      usuario: administrador
    };
  }
};

module.exports = autorizacionUtils;