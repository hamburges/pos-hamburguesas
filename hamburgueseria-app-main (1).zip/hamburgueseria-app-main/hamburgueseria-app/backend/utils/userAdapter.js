/**
 * Adaptador que normaliza la información del usuario entre capas del sistema
 * Implementa el patrón Adaptador para unificar interfaces inconsistentes
 */

/**
 * Extrae y normaliza los datos del usuario del objeto request
 * @param {Object} req - Objeto request de Express
 * @returns {Object} Datos normalizados del usuario
 * @throws {Error} Si no hay información de usuario disponible
 */
const extractUserData = (req) => {
    if (!req || (!req.usuario && !req.usuarioId)) {
      throw new Error('Información de usuario no disponible en el request');
    }
    
    // Priorizar el objeto usuario estructurado si existe
    if (req.usuario) {
      return {
        id: req.usuario.id || (req.usuario._id ? req.usuario._id.toString() : null),
        _id: req.usuario._id || req.usuario.id,
        usuario: req.usuario.usuario,
        rol: req.usuario.rol,
        sucursal: req.usuario.sucursal ? (typeof req.usuario.sucursal === 'object' ? req.usuario.sucursal.toString() : req.usuario.sucursal) : null,
        sucursalObj: typeof req.usuario.sucursal === 'object' ? req.usuario.sucursal : req.usuario.sucursal
      };
    }
    
    // Compatibilidad con interfaz legacy (propiedades individuales)
    return {
      id: req.usuarioId ? req.usuarioId.toString() : null,
      _id: req.usuarioId,
      usuario: null,
      rol: req.rol,
      sucursal: req.sucursalId ? req.sucursalId.toString() : null,
      sucursalObj: req.sucursalId
    };
  };
  
  /**
   * Verifica si el request contiene información válida de usuario
   * @param {Object} req - Objeto request de Express
   * @returns {Boolean} True si contiene información válida, false en caso contrario
   */
  const hasValidUserData = (req) => {
    if (!req) return false;
    
    // Verificar interfaz principal (objeto usuario)
    if (req.usuario && (req.usuario.id || req.usuario._id)) {
      return true;
    }
    
    // Verificar interfaz secundaria (propiedades individuales)
    if (req.usuarioId) {
      return true;
    }
    
    return false;
  };
  
  module.exports = {
    extractUserData,
    hasValidUserData
  };