const logger = {
  info: (message, data = {}) => {
    console.log(`[INFO] ${new Date().toISOString()} - ${message}`, data);
  },
  
  error: (message, error) => {
    console.error(`[ERROR] ${new Date().toISOString()} - ${message}`, error);
  },
  
  warn: (message, data = {}) => {
    console.warn(`[WARN] ${new Date().toISOString()} - ${message}`, data);
  },
  
  // Agregue para registrar operaciones críticas
  critical: (message, data = {}) => {
    console.error(`[CRITICAL] ${new Date().toISOString()} - ${message}`, data);
    // Aquí podría enviar correo o notificación si es crítico
  },
  
  // Para métricas de rendimiento
  performance: (operation, timeMs, metadata = {}) => {
    const logData = {
      operation,
      timeMs,
      ...metadata
    };
    
    // Alertar de operaciones lentas
    if (timeMs > 500) {
      console.warn(`[PERFORMANCE] ${new Date().toISOString()} - Operación lenta: ${operation} - ${timeMs}ms`, logData);
    } else {
      console.log(`[PERFORMANCE] ${new Date().toISOString()} - ${operation} - ${timeMs}ms`, logData);
    }
  }
};

module.exports = logger;
