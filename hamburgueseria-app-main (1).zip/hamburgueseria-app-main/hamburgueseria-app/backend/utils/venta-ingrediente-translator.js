/**
 * Traductor de ventas a operaciones de inventario
 */
const OpcionProducto = require('../models/OpcionProducto');

const ventaIngredienteTranslator = {
  /**
   * Traduce venta completa a operaciones de inventario
   */
  async traducirVentaAOperaciones(venta) {
    const operaciones = [];
    
    if (!venta.productos || !Array.isArray(venta.productos)) {
      return operaciones;
    }

    // Procesar cada producto
    for (const item of venta.productos) {
      try {
        // Obtener operaciones del producto base
        await this._procesarProductoBase(item, operaciones);
        
        // Procesar personalizaciones
        this._procesarPersonalizaciones(item, operaciones);
      } catch (error) {
        console.error('Error procesando producto:', error);
      }
    }

    return this._consolidarOperaciones(operaciones);
  },

  /**
   * Procesa ingredientes predeterminados del producto
   */
  async _procesarProductoBase(item, operaciones) {
    // Obtener opciones predeterminadas desde BD
    const opcionesProducto = await OpcionProducto.find({ 
      producto: item.producto 
    }).populate('ingrediente');
    
    // Identificar ingredientes que fueron quitados
    const ingredientesQuitados = new Set(
      item.personalizaciones
        ?.filter(p => p.accion === 'quitar')
        .map(p => p.ingrediente.toString()) || []
    );

    // Crear operaciones para ingredientes predeterminados no quitados
    opcionesProducto
      .filter(opcion => opcion.es_predeterminado && 
              !ingredientesQuitados.has(opcion.ingrediente._id.toString()))
      .forEach(opcion => {
        operaciones.push({
          ingredienteId: opcion.ingrediente._id,
          cantidad: opcion.cantidad_predeterminada * item.cantidad,
          tipo: 'descontar'
        });
      });
  },

  /**
   * Procesa ingredientes añadidos
   */
  _procesarPersonalizaciones(item, operaciones) {
    if (!item.personalizaciones) return;

    item.personalizaciones
      .filter(p => p.accion === 'agregar')
      .forEach(p => {
        operaciones.push({
          ingredienteId: p.ingrediente,
          cantidad: p.cantidad * item.cantidad,
          tipo: 'descontar'
        });
      });
  },

  /**
   * Consolida operaciones del mismo ingrediente
   */
  _consolidarOperaciones(operaciones) {
    const mapa = new Map();
    
    operaciones.forEach(op => {
      const key = `${op.ingredienteId}-${op.tipo}`;
      if (!mapa.has(key)) {
        mapa.set(key, {...op});
      } else {
        const existente = mapa.get(key);
        existente.cantidad += op.cantidad;
      }
    });
    
    return Array.from(mapa.values());
  }
};

module.exports = ventaIngredienteTranslator;